import * as React from "react"
import { Pencil, Trash2, Plus, CircleCheck, CircleAlert, ChevronDown, RefreshCw } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Switch } from "@/components/ui/switch"
import { Badge } from "@/components/ui/badge"
import { Card, CardContent } from "@/components/ui/card"
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert"
import { Skeleton } from "@/components/ui/skeleton"
import { Spinner } from "@/components/ui/spinner"
import { Field, FieldDescription, FieldError, FieldGroup, FieldLabel } from "@/components/ui/field"
import { Sheet, SheetContent, SheetDescription, SheetFooter, SheetHeader, SheetTitle } from "@/components/ui/sheet"
import { AlertDialog, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle } from "@/components/ui/alert-dialog"
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from "@/components/ui/collapsible"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Breadcrumb, BreadcrumbItem, BreadcrumbList, BreadcrumbPage, BreadcrumbSeparator, BreadcrumbLink } from "@/components/ui/breadcrumb"
import { SidebarGroup, SidebarGroupContent, SidebarGroupLabel, SidebarMenu, SidebarMenuButton, SidebarMenuItem } from "@/components/ui/sidebar"
import { useIsMobile } from "@/hooks/use-mobile"
import { Shell } from "./layouts"
import { UtensilsCrossed, Wine, CupSoda, Martini, BookOpen, ConciergeBell, CalendarHeart, Megaphone, Clock, CalendarDays, Settings } from "lucide-react"

/* ---------- navigazione a otto voci (D1) ---------- */
const GRUPPI: { label: string; voci: { label: string; icon: React.ComponentType<any> }[] }[] = [
  { label: "Menù", voci: [{ label: "Piatti", icon: UtensilsCrossed }, { label: "Vini", icon: Wine }, { label: "Bevande", icon: CupSoda }, { label: "Distillati", icon: Martini }, { label: "Menù fissi", icon: BookOpen }, { label: "Servizi", icon: ConciergeBell }, { label: "Giorni speciali", icon: CalendarHeart }, { label: "Messaggio globale", icon: Megaphone }] },
  { label: "Orari", voci: [{ label: "Orari", icon: Clock }] },
  { label: "Prenotazioni", voci: [{ label: "Elenco", icon: CalendarDays }, { label: "Eccezioni giorno", icon: CalendarDays }, { label: "Impostazioni", icon: Settings }] },
]
function MenuOtto({ active }: { active: string }) {
  return (
    <>
      {GRUPPI.map((g) => (
        <SidebarGroup key={g.label}>
          <SidebarGroupLabel>{g.label}</SidebarGroupLabel>
          <SidebarGroupContent>
            <SidebarMenu>
              {g.voci.map((v) => (
                <SidebarMenuItem key={v.label}>
                  <SidebarMenuButton render={<a href="#" />} isActive={g.label === "Menù" && v.label === active} tooltip={v.label}><v.icon /><span>{v.label}</span></SidebarMenuButton>
                </SidebarMenuItem>
              ))}
            </SidebarMenu>
          </SidebarGroupContent>
        </SidebarGroup>
      ))}
    </>
  )
}

/* ---------- dati di esempio (nel progetto: collection menu-services; l'uso nei menù fissi è un'interrogazione) ---------- */
type Serv = { id: number; name: string; nameEn: string; price: string; disabled: boolean }
const initialData: Serv[] = [
  { id: 1, name: "Coperto", nameEn: "Cover charge", price: "2,00", disabled: false },
  { id: 2, name: "Diritto di dolce", nameEn: "", price: "3,00", disabled: false },
  { id: 3, name: "Diritto di tappo", nameEn: "Corkage fee", price: "10,00", disabled: true },
]
// menù fissi che usano il servizio (esempio): serve alla conferma di eliminazione, che dichiara il cascade (D14)
const USO: Record<string, string[]> = { Coperto: ["Business lunch Vegetariano", "Business lunch Vietnam"], "Diritto di tappo": ["Degustazione classica"] }
const pl = (n: number, one: string, many: string) => (n === 1 ? `1 ${one}` : `${n} ${many}`)
const euro = (p: string) => `${p} €`
const SERR = "Non è stato modificato nulla. Controlla la connessione e riprova; se il problema continua, avvisa l’amministratore."
const PRICE_RE = /^\d+([.,]\d{1,2})?$/
type Form = Omit<Serv, "id">
const emptyForm = (): Form => ({ name: "", nameEn: "", price: "", disabled: false })
let nextId = 100

function ServiziPage() {
  const narrow = useIsMobile()
  const [data, setData] = React.useState<Serv[]>(initialData)
  const [selId, setSelId] = React.useState<number | null>(null)
  const [form, setForm] = React.useState<Form>(emptyForm())
  const [showErr, setShowErr] = React.useState(false)
  const [enOpen, setEnOpen] = React.useState(false)
  const [busy, setBusy] = React.useState(false)
  const [opError, setOpError] = React.useState<string | null>(null)
  const [notice, setNotice] = React.useState<{ kind: "ok" | "err"; title: string; text?: string } | null>(null)
  const [loadState, setLoadState] = React.useState<"ok" | "loading" | "error" | "empty">("ok")
  const [failNext, setFailNext] = React.useState(false)
  const [delTarget, setDelTarget] = React.useState<Serv | null>(null)
  const [delBusy, setDelBusy] = React.useState(false)
  const [rebuildOpen, setRebuildOpen] = React.useState(false)
  const [rebuildBusy, setRebuildBusy] = React.useState(false)

  const list = [...data].sort((a, b) => a.name.localeCompare(b.name, "it", { sensitivity: "base" }))
  const patch = (id: number, p: Partial<Serv>) => setData((x) => x.map((v) => (v.id === id ? { ...v, ...p } : v)))
  async function toggle(v: Serv) {
    setNotice(null); await new Promise((r) => setTimeout(r, 250))
    if (failNext) { setFailNext(false); setNotice({ kind: "err", title: "Operazione non riuscita", text: SERR }); return }
    patch(v.id, { disabled: !v.disabled }); setNotice({ kind: "ok", title: v.disabled ? "Servizio abilitato" : "Servizio disabilitato", text: "Il menù pubblico si aggiorna entro pochi secondi." })
  }
  function openEdit(v: Serv) { const { id, ...rest } = v; setForm(rest); setEnOpen(!!v.nameEn); setShowErr(false); setOpError(null); setSelId(id) }
  function openNew() { setForm(emptyForm()); setEnOpen(false); setShowErr(false); setOpError(null); setSelId(-1) }
  const errs = {
    name: form.name.trim() ? null : "Campo obbligatorio.",
    price: !form.price.trim() ? "Campo obbligatorio." : PRICE_RE.test(form.price.trim()) ? null : "Inserisci un prezzo valido (es. 2,50).",
  }
  const hasErr = Object.values(errs).some(Boolean)
  const fe = (k: keyof typeof errs) => (showErr ? errs[k] : null)
  const setF = <K extends keyof Form>(k: K, v: Form[K]) => setForm((f) => ({ ...f, [k]: v }))
  async function save() {
    if (hasErr) { setShowErr(true); requestAnimationFrame(() => document.querySelector<HTMLElement>('[data-slot="sheet-content"] [aria-invalid="true"]')?.focus()); return }
    setBusy(true); setOpError(null); await new Promise((r) => setTimeout(r, 700)); setBusy(false)
    if (failNext) { setFailNext(false); setOpError("Operazione non riuscita. " + SERR); return }
    const isNew = selId === -1
    if (isNew) setData((x) => [...x, { id: nextId++, ...form, name: form.name.trim() }]); else patch(selId!, { ...form, name: form.name.trim() })
    setSelId(null); setNotice({ kind: "ok", title: isNew ? "Servizio aggiunto" : "Servizio salvato", text: "Per vederlo sul menù pubblico serve «Ricompila il menù pubblico»." })
  }
  async function doDelete() {
    if (!delTarget) return
    setDelBusy(true); await new Promise((r) => setTimeout(r, 600)); setDelBusy(false)
    const id = delTarget.id; setData((x) => x.filter((v) => v.id !== id)); setDelTarget(null)
    setNotice({ kind: "ok", title: "Servizio eliminato", text: "Per toglierlo dal menù pubblico serve «Ricompila il menù pubblico»." })
  }
  async function rebuild() { setRebuildBusy(true); await new Promise((r) => setTimeout(r, 800)); setRebuildBusy(false); setRebuildOpen(false); setNotice({ kind: "ok", title: "Ricompilazione avviata", text: "Il menù pubblico si aggiorna tra alcuni minuti." }) }
  function demo(v: string) {
    setNotice(null); setLoadState("ok"); setFailNext(false)
    if (v === "caricamento") setLoadState("loading"); if (v === "errore-caricamento") setLoadState("error"); if (v === "vuoto") setLoadState("empty"); if (v === "errore-azione") setFailNext(true)
  }
  const uso = delTarget ? USO[delTarget.name] ?? [] : [] // nel progetto: i menù fissi che contengono il servizio, letti con la sessione dell'utente

  const Actions = ({ v }: { v: Serv }) => (
    <div className="flex items-center">
      <Button variant="ghost" size="icon" aria-label={`Modifica ${v.name}`} data-component="Button" onClick={() => openEdit(v)}><Pencil /></Button>
      <Button variant="ghost" size="icon" aria-label={`Elimina ${v.name}`} data-component="Button" onClick={() => setDelTarget(v)}><Trash2 /></Button>
    </div>
  )
  const Avail = ({ v }: { v: Serv }) => <Switch data-component="Switch" aria-label={`Disponibile: ${v.name}`} checked={!v.disabled} onCheckedChange={() => toggle(v)} />

  return (
    <Shell themeSwitch adminInUserMenu menu={<MenuOtto active="Servizi" />}
      topbar={<Breadcrumb><BreadcrumbList><BreadcrumbItem><BreadcrumbLink href="#">Menù</BreadcrumbLink></BreadcrumbItem><BreadcrumbSeparator /><BreadcrumbItem><BreadcrumbPage>Servizi</BreadcrumbPage></BreadcrumbItem></BreadcrumbList></Breadcrumb>}>
      <div className="mx-auto flex w-full max-w-5xl flex-col gap-5" data-block="contenitore-elenco">
        <div className="flex flex-col gap-3 sm:flex-row sm:items-start sm:justify-between" data-block="intestazione-pagina">
          <div><h1 className="text-xl font-semibold tracking-tight">Servizi</h1><p className="text-sm text-muted-foreground">Voci accessorie: coperto, diritto di dolce, diritto di tappo.</p></div>
          <div className="flex flex-col-reverse gap-2 sm:flex-row">
            <Button variant="outline" size="lg" data-component="Button" onClick={() => setRebuildOpen(true)}><RefreshCw data-icon="inline-start" /> Ricompila il menù pubblico</Button>
            <Button size="lg" data-component="Button" onClick={openNew}><Plus data-icon="inline-start" /> Nuovo servizio</Button>
          </div>
        </div>

        {notice && <Alert role="status" data-component="Alert" variant={notice.kind === "err" ? "destructive" : "default"}>{notice.kind === "err" ? <CircleAlert /> : <CircleCheck />}<AlertTitle>{notice.title}</AlertTitle>{notice.text && <AlertDescription>{notice.text}</AlertDescription>}</Alert>}

        {loadState === "loading" && <div className="flex flex-col gap-2" aria-busy="true" data-block="caricamento">{[0, 1, 2].map((i) => <Skeleton key={i} className="h-16 w-full rounded-xl" />)}</div>}
        {loadState === "error" && <Alert variant="destructive" role="alert" data-component="Alert"><CircleAlert /><AlertTitle>Impossibile caricare i servizi</AlertTitle><AlertDescription><p>Riprova tra qualche istante; se il problema continua, avvisa l’amministratore.</p><Button variant="outline" className="mt-3" data-component="Button" onClick={() => setLoadState("ok")}>Riprova</Button></AlertDescription></Alert>}
        {(loadState === "empty" || (loadState === "ok" && list.length === 0)) && <div className="flex flex-col items-start gap-3 rounded-lg border border-dashed p-6" data-block="vuoto"><p className="text-sm text-muted-foreground">Nessun servizio.</p><Button variant="outline" data-component="Button" onClick={openNew}>Nuovo servizio</Button></div>}
        {loadState === "ok" && list.length > 0 && (
          <section className="flex flex-col gap-2" data-block="elenco">
            <p className="text-sm text-muted-foreground">{pl(list.length, "servizio", "servizi")}</p>
            <div className="hidden rounded-lg border md:block" data-block="elenco-tabella">
              <Table data-component="Table" className="table-fixed">
                <TableHeader><TableRow><TableHead>Nome</TableHead><TableHead className="w-28">Prezzo</TableHead><TableHead className="w-28">Disponibile</TableHead><TableHead className="w-24"><span className="sr-only">Azioni</span></TableHead></TableRow></TableHeader>
                <TableBody>
                  {list.map((v) => (
                    <TableRow key={v.id} className={v.disabled ? "text-muted-foreground" : ""}>
                      <TableCell><div className="flex items-center gap-2"><span className="truncate text-sm font-medium">{v.name}</span>{v.disabled && <Badge data-component="Badge" variant="outline">Disabilitato</Badge>}</div></TableCell>
                      <TableCell className="tabular-nums">{euro(v.price)}</TableCell>
                      <TableCell><Avail v={v} /></TableCell>
                      <TableCell className="text-right"><Actions v={v} /></TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
            <div className="flex flex-col gap-2 md:hidden" data-block="elenco-schede">
              {list.map((v) => (
                <Card key={v.id} size="sm" data-component="Card" className={v.disabled ? "text-muted-foreground" : ""}>
                  <CardContent className="flex items-center gap-2">
                    <div className="min-w-0 flex-1 py-1">
                      <div className="truncate text-sm font-medium">{v.name}</div>
                      <div className="mt-0.5 flex items-center gap-2 text-xs text-muted-foreground"><span className="tabular-nums">{euro(v.price)}</span>{v.disabled && <Badge data-component="Badge" variant="outline">Disabilitato</Badge>}</div>
                    </div>
                    <label className="flex flex-col items-center gap-1 text-[11px] text-muted-foreground"><Avail v={v} />Disponibile</label>
                    <Actions v={v} />
                  </CardContent>
                </Card>
              ))}
            </div>
          </section>
        )}
      </div>

      {/* Modulo servizio */}
      <Sheet open={selId !== null} onOpenChange={(o) => { if (!o && !busy) setSelId(null) }}>
        <SheetContent side={narrow ? "bottom" : "right"} data-component="Sheet" data-state={selId === -1 ? "new" : "edit"}>
          <SheetHeader><SheetTitle>{selId === -1 ? "Nuovo servizio" : "Modifica servizio"}</SheetTitle><SheetDescription>{selId === -1 ? "Il servizio compare nel menù pubblico dopo la ricompilazione." : form.name}</SheetDescription></SheetHeader>
          <FieldGroup className="px-4" data-block="modulo-servizio">
            {opError && <Alert variant="destructive" role="alert" data-component="Alert"><CircleAlert /><AlertTitle>Operazione non riuscita</AlertTitle><AlertDescription>{SERR}</AlertDescription></Alert>}
            <Field data-invalid={fe("name") ? true : undefined}><FieldLabel htmlFor="v-nome">Nome</FieldLabel><Input id="v-nome" value={form.name} aria-invalid={fe("name") ? true : undefined} onChange={(e) => setF("name", e.target.value)} />{fe("name") && <FieldError>{fe("name")}</FieldError>}</Field>
            <Collapsible open={enOpen} onOpenChange={setEnOpen} className="rounded-lg border" data-block="traduzione-inglese">
              <CollapsibleTrigger render={<button type="button" className="flex min-h-11 w-full items-center gap-2 px-3 text-left text-sm font-medium" />}>
                Traduzione inglese <span className="font-normal text-muted-foreground">(facoltativa)</span>
                <Badge data-component="Badge" variant="outline" className="ml-auto">{form.nameEn ? "Presente" : "Manca"}</Badge><ChevronDown className={`size-4 transition-transform ${enOpen ? "rotate-180" : ""}`} />
              </CollapsibleTrigger>
              <CollapsibleContent><div className="flex flex-col gap-4 border-t p-3"><Field><FieldLabel htmlFor="v-nome-en">Name</FieldLabel><Input id="v-nome-en" placeholder={form.name} value={form.nameEn} onChange={(e) => setF("nameEn", e.target.value)} /><FieldDescription>Facoltativa. Se resta vuota, il menù mostra il testo italiano.</FieldDescription></Field></div></CollapsibleContent>
            </Collapsible>
            <Field data-invalid={fe("price") ? true : undefined}><FieldLabel htmlFor="v-prezzo">Prezzo (€)</FieldLabel><Input id="v-prezzo" inputMode="decimal" value={form.price} aria-invalid={fe("price") ? true : undefined} onChange={(e) => setF("price", e.target.value)} />{fe("price") && <FieldError>{fe("price")}</FieldError>}</Field>
            <Field orientation="horizontal"><div className="flex-1"><FieldLabel htmlFor="v-dis" className="min-h-11 items-center">Disabilitato</FieldLabel><FieldDescription>Assente a tempo indefinito: il servizio non compare nel menù.</FieldDescription></div><Switch id="v-dis" data-component="Switch" checked={form.disabled} onCheckedChange={(c) => setF("disabled", c === true)} /></Field>
          </FieldGroup>
          <SheetFooter className="grid grid-cols-2"><Button size="lg" onClick={save} disabled={busy}>{busy && <Spinner data-icon="inline-start" />}{busy ? "Salvataggio…" : "Salva"}</Button><Button size="lg" variant="outline" disabled={busy} onClick={() => setSelId(null)}>Annulla</Button></SheetFooter>
        </SheetContent>
      </Sheet>

      {/* Elimina: il cascade è dichiarato prima di «Non si può annullare.» (D14) */}
      <AlertDialog open={delTarget !== null} onOpenChange={(o) => { if (!o && !delBusy) setDelTarget(null) }}>
        <AlertDialogContent data-component="AlertDialog" data-state={uso.length ? "elimina-con-uso" : "elimina"}>
          <AlertDialogHeader><AlertDialogTitle>Eliminare {delTarget?.name}?</AlertDialogTitle>
            <AlertDialogDescription>{uso.length ? `Verrà tolto anche da ${pl(uso.length, "menù fisso", "menù fissi")}: ${uso.join(", ")}. Non si può annullare.` : "Non si può annullare."}</AlertDialogDescription></AlertDialogHeader>
          <AlertDialogFooter><AlertDialogCancel disabled={delBusy}>Indietro</AlertDialogCancel><Button variant="destructive" data-component="Button" onClick={doDelete} disabled={delBusy}>{delBusy && <Spinner data-icon="inline-start" />}Elimina</Button></AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

      {/* Ricompila (componente condiviso con Piatti) */}
      <AlertDialog open={rebuildOpen} onOpenChange={(o) => !o && !rebuildBusy && setRebuildOpen(false)}>
        <AlertDialogContent data-component="AlertDialog" data-state="ricompila">
          <AlertDialogHeader><AlertDialogTitle>Ricompilare il menù pubblico?</AlertDialogTitle>
            <AlertDialogDescription>La pubblicazione richiede alcuni minuti. Serve per vedere piatti nuovi e modifiche ai contenuti, ai servizi, agli orari, alle chiusure e ai giorni speciali. «Terminato» e «disabilitato» valgono già.</AlertDialogDescription></AlertDialogHeader>
          <AlertDialogFooter><AlertDialogCancel disabled={rebuildBusy}>Indietro</AlertDialogCancel><Button data-component="Button" onClick={rebuild} disabled={rebuildBusy}>{rebuildBusy && <Spinner data-icon="inline-start" />}Ricompila</Button></AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

      <div data-demo className="fixed bottom-2 right-2 z-50 rounded-md border bg-card px-1.5 py-0.5 text-[11px] text-muted-foreground shadow-xs">
        <label>Demo stato <select aria-label="Stato demo" className="bg-transparent text-foreground" defaultValue="normale" onChange={(e) => demo(e.target.value)}>
          <option value="normale">normale</option><option value="caricamento">caricamento</option><option value="errore-caricamento">errore di caricamento</option><option value="vuoto">nessun servizio</option>
          <option value="errore-azione">errore all’azione successiva</option>
        </select></label>
      </div>
    </Shell>
  )
}
export const serviziPage = <ServiziPage />
