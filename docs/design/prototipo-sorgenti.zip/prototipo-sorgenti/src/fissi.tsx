import * as React from "react"
import { Pencil, Trash2, Plus, Search, CircleCheck, CircleAlert, ChevronDown, RefreshCw, ArrowUp, ArrowDown, ArrowLeft, X, Info } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { Switch } from "@/components/ui/switch"
import { Checkbox } from "@/components/ui/checkbox"
import { Badge } from "@/components/ui/badge"
import { Card, CardContent } from "@/components/ui/card"
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert"
import { Skeleton } from "@/components/ui/skeleton"
import { Spinner } from "@/components/ui/spinner"
import { Field, FieldDescription, FieldError, FieldGroup, FieldLabel, FieldLegend, FieldSet } from "@/components/ui/field"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Sheet, SheetContent, SheetDescription, SheetFooter, SheetHeader, SheetTitle } from "@/components/ui/sheet"
import { AlertDialog, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle } from "@/components/ui/alert-dialog"
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from "@/components/ui/collapsible"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs"
import { Breadcrumb, BreadcrumbItem, BreadcrumbList, BreadcrumbPage, BreadcrumbSeparator, BreadcrumbLink } from "@/components/ui/breadcrumb"
import { SidebarGroup, SidebarGroupContent, SidebarGroupLabel, SidebarMenu, SidebarMenuButton, SidebarMenuItem } from "@/components/ui/sidebar"
import { useIsMobile } from "@/hooks/use-mobile"
import { Shell } from "./layouts"
import { UtensilsCrossed, Wine, CupSoda, Martini, BookOpen, ConciergeBell, CalendarHeart, Megaphone, Clock, CalendarDays, Settings } from "lucide-react"

/* ---------- navigazione a otto voci (D1) ---------- */
const GRUPPI: { label: string; voci: { label: string; icon: React.ComponentType<any> }[] }[] = [
  { label: "Menù", voci: [{ label: "Piatti", icon: UtensilsCrossed }, { label: "Vini", icon: Wine }, { label: "Bevande", icon: CupSoda }, { label: "Distillati", icon: Martini }, { label: "Menù fissi", icon: BookOpen }, { label: "Servizi", icon: ConciergeBell }, { label: "Giorni speciali", icon: CalendarHeart }, { label: "Messaggio globale", icon: Megaphone }] },
  { label: "Orari", voci: [{ label: "Orari", icon: Clock }] },
  { label: "Prenotazioni", voci: [{ label: "Elenco", icon: CalendarDays }, { label: "Eccezioni giorno", icon: CalendarDays }, { label: "Impostazioni", icon: Settings }] },
]
function MenuOtto({ active }: { active: string }) {
  return (
    <>
      {GRUPPI.map((g) => (
        <SidebarGroup key={g.label}>
          <SidebarGroupLabel>{g.label}</SidebarGroupLabel>
          <SidebarGroupContent>
            <SidebarMenu>
              {g.voci.map((v) => (
                <SidebarMenuItem key={v.label}>
                  <SidebarMenuButton render={<a href="#" />} isActive={g.label === "Menù" && v.label === active} tooltip={v.label}><v.icon /><span>{v.label}</span></SidebarMenuButton>
                </SidebarMenuItem>
              ))}
            </SidebarMenu>
          </SidebarGroupContent>
        </SidebarGroup>
      ))}
    </>
  )
}

/* ---------- dati di esempio (nel progetto: fixed-menus, fixed-menu-categories, dishes, menu-services, special-days) ---------- */
type Vis = "always" | "lunch_only" | "dinner_only"
const VIS_LABEL: Record<Vis, string> = { always: "Sempre", lunch_only: "Solo pranzo", dinner_only: "Solo cena" }
const VIS_ITEMS = (Object.keys(VIS_LABEL) as Vis[]).map((v) => ({ value: v, label: VIS_LABEL[v] }))
type Cat = { id: number; name: string; nameEn: string; vis: Vis; disabled: boolean }
type Dish = { id: number; name: string; cat: string; disabled?: boolean; soldOut?: boolean }
type Row = { dish: number; portion: string; portionEn: string }
type Menu = { id: number; name: string; nameEn: string; desc: string; descEn: string; price: string; category: number | null; vis: Vis; specialOnly: boolean; dishes: Row[]; services: number[]; disabled: boolean }
const DISHES: Dish[] = [
  { id: 1, name: "Involtini primavera", cat: "Antipasti" }, { id: 2, name: "Nem di carne", cat: "Antipasti" }, { id: 3, name: "Gamberi in tempura", cat: "Antipasti", disabled: true },
  { id: 4, name: "Banana flambé", cat: "Dolci" }, { id: 5, name: "Gelato al cocco", cat: "Dolci" },
  { id: 6, name: "Pho bo", cat: "Primi", soldOut: true }, { id: 7, name: "Ravioli al vapore", cat: "Primi" }, { id: 8, name: "Spaghetti di riso saltati", cat: "Primi" },
  { id: 9, name: "Branzino al vapore", cat: "Secondi" }, { id: 10, name: "Maiale caramellato", cat: "Secondi" }, { id: 11, name: "Pollo al limone", cat: "Secondi" },
]
const DISH_CATS = ["Antipasti", "Dolci", "Primi", "Secondi"] // ordine per nome
const SERVICES = [{ id: 1, name: "Coperto", price: "2,00" }, { id: 2, name: "Diritto di dolce", price: "3,00" }, { id: 3, name: "Diritto di tappo", price: "10,00" }]
const dishById = (id: number) => DISHES.find((d) => d.id === id)!
const R = (dish: number, portion = "", portionEn = ""): Row => ({ dish, portion, portionEn })
const initialCats: Cat[] = [
  { id: 1, name: "Business lunch", nameEn: "", vis: "lunch_only", disabled: false },
  { id: 2, name: "Degustazione", nameEn: "Tasting menu", vis: "always", disabled: false },
]
const M = (id: number, name: string, price: string, category: number, vis: Vis, dishes: Row[], services: number[] = [], extra: Partial<Menu> = {}): Menu => ({ id, name, nameEn: "", desc: "", descEn: "", price, category, vis, specialOnly: false, dishes, services, disabled: false, ...extra })
const initialMenus: Menu[] = [
  M(1, "Business lunch Vietnam", "18,00", 1, "lunch_only", [R(2, "2 pezzi", "2 pieces"), R(6), R(4)], [1], { nameEn: "Vietnam business lunch", desc: "Antipasto, piatto principale e dolce." }),
  M(2, "Business lunch vegetariano", "16,00", 1, "lunch_only", [R(1, "2 pezzi"), R(8), R(5)], [1]),
  M(3, "Business lunch light", "14,00", 1, "lunch_only", [R(7), R(11)]),
  M(4, "Degustazione classica", "38,00", 2, "always", [R(1), R(7), R(9), R(4)]),
  M(5, "Degustazione del mare", "45,00", 2, "always", [R(3), R(9), R(5)], [], { disabled: false }),
  M(6, "Menù San Valentino", "60,00", 2, "always", [R(1), R(9), R(4)], [2], { specialOnly: true }),
]
// giorni speciali che usano il menù (esempio): servono alla conferma di eliminazione, che dichiara il cascade (D14)
const GIORNI: Record<string, string[]> = { "Menù San Valentino": ["14 febbraio 2027"], "Degustazione del mare": ["14 febbraio 2027"] }
const pl = (n: number, one: string, many: string) => (n === 1 ? `1 ${one}` : `${n} ${many}`)
const euro = (p: string) => `${p} €`
const SERR = "Non è stato modificato nulla. Controlla la connessione e riprova; se il problema continua, avvisa l’amministratore."
const PRICE_RE = /^\d+([.,]\d{1,2})?$/
type Form = Omit<Menu, "id">
const emptyForm = (): Form => ({ name: "", nameEn: "", desc: "", descEn: "", price: "", category: null, vis: "always", specialOnly: false, dishes: [], services: [], disabled: false })
type CatForm = Omit<Cat, "id">
let nextId = 100
const visNote = (c: Cat | undefined, vis: Vis): { kind: "info" | "warn"; text: string } | null => {
  if (!c || c.vis === "always") return null
  const quando = c.vis === "lunch_only" ? "a pranzo" : "a cena"
  if (vis === "always") return { kind: "info", text: `La categoria «${c.name}» compare solo ${quando}: anche questo menù compare solo ${quando}.` }
  if (vis !== c.vis) return { kind: "warn", text: `La categoria «${c.name}» compare solo ${quando} e il menù solo ${vis === "lunch_only" ? "a pranzo" : "a cena"}: non comparirà mai.` }
  return null
}

function SelectField({ id, items, value, onChange, placeholder, disabled, invalid }: { id?: string; items: { value: string; label: string }[]; value: string; onChange: (v: string) => void; placeholder?: string; disabled?: boolean; invalid?: boolean }) {
  return (
    <Select items={items} value={value || null} disabled={disabled} onValueChange={(v) => onChange((v as string) ?? "")}>
      <SelectTrigger id={id} data-component="Select" className="w-full" aria-invalid={invalid ? true : undefined}><SelectValue placeholder={placeholder} /></SelectTrigger>
      <SelectContent>{items.map((o) => <SelectItem key={o.value} value={o.value}>{o.label}</SelectItem>)}</SelectContent>
    </Select>
  )
}
const DishBadges = ({ d }: { d: Dish }) => (<>{d.disabled && <Badge data-component="Badge" variant="outline">Disabilitato</Badge>}{d.soldOut && !d.disabled && <Badge data-component="Badge" variant="secondary">Terminato</Badge>}</>)

function FissiPage() {
  const narrow = useIsMobile()
  const [tab, setTab] = React.useState("menu")
  const [menus, setMenus] = React.useState<Menu[]>(initialMenus)
  const [cats, setCats] = React.useState<Cat[]>(initialCats)
  const [notice, setNotice] = React.useState<{ kind: "ok" | "err"; title: string; text?: string } | null>(null)
  const [loadState, setLoadState] = React.useState<"ok" | "loading" | "error" | "empty">("ok")
  const [failNext, setFailNext] = React.useState(false)
  const [rebuildOpen, setRebuildOpen] = React.useState(false)
  const [rebuildBusy, setRebuildBusy] = React.useState(false)
  // modulo del menù
  const [selId, setSelId] = React.useState<number | null>(null)
  const [view, setView] = React.useState<"form" | "piatti">("form")
  const [form, setForm] = React.useState<Form>(emptyForm())
  const [visTouched, setVisTouched] = React.useState(false)
  const [showErr, setShowErr] = React.useState(false)
  const [enOpen, setEnOpen] = React.useState(false)
  const [busy, setBusy] = React.useState(false)
  const [opError, setOpError] = React.useState<string | null>(null)
  const [pick, setPick] = React.useState<number[]>([])
  const [pickQ, setPickQ] = React.useState("")
  const [delTarget, setDelTarget] = React.useState<Menu | null>(null)
  const [delBusy, setDelBusy] = React.useState(false)
  // modulo della categoria
  const [catSel, setCatSel] = React.useState<number | null>(null)
  const [catForm, setCatForm] = React.useState<CatForm>({ name: "", nameEn: "", vis: "always", disabled: false })
  const [catErr, setCatErr] = React.useState(false)
  const [catEn, setCatEn] = React.useState(false)

  const catById = (id: number | null) => cats.find((c) => c.id === id)
  const sortedCats = [...cats].sort((a, b) => a.name.localeCompare(b.name, "it", { sensitivity: "base" }))
  const patchMenu = (id: number, p: Partial<Menu>) => setMenus((x) => x.map((m) => (m.id === id ? { ...m, ...p } : m)))
  async function toggleMenu(m: Menu) {
    setNotice(null); await new Promise((r) => setTimeout(r, 250))
    if (failNext) { setFailNext(false); setNotice({ kind: "err", title: "Operazione non riuscita", text: SERR }); return }
    patchMenu(m.id, { disabled: !m.disabled }); setNotice({ kind: "ok", title: m.disabled ? "Menù fisso abilitato" : "Menù fisso disabilitato", text: "Il menù pubblico si aggiorna entro pochi secondi." })
  }
  async function toggleCat(c: Cat) {
    setNotice(null); await new Promise((r) => setTimeout(r, 250))
    if (failNext) { setFailNext(false); setNotice({ kind: "err", title: "Operazione non riuscita", text: SERR }); return }
    setCats((x) => x.map((k) => (k.id === c.id ? { ...k, disabled: !k.disabled } : k))); setNotice({ kind: "ok", title: c.disabled ? "Categoria abilitata" : "Categoria disabilitata", text: "Il menù pubblico si aggiorna entro pochi secondi." })
  }
  function openEdit(m: Menu) { const { id, ...rest } = m; setForm(rest); setEnOpen(!!(m.nameEn || m.descEn || m.dishes.some((r) => r.portionEn))); setVisTouched(true); setShowErr(false); setOpError(null); setView("form"); setSelId(id) }
  function openNew() { setForm(emptyForm()); setEnOpen(false); setVisTouched(false); setShowErr(false); setOpError(null); setView("form"); setSelId(-1) }
  const setF = <K extends keyof Form>(k: K, v: Form[K]) => setForm((f) => ({ ...f, [k]: v }))
  const setCategory = (idStr: string) => { const id = Number(idStr); const c = catById(id); setForm((f) => ({ ...f, category: id, vis: !visTouched && c ? c.vis : f.vis })) }
  const errs = {
    name: form.name.trim() ? null : "Campo obbligatorio.",
    price: !form.price.trim() ? "Campo obbligatorio." : PRICE_RE.test(form.price.trim()) ? null : "Inserisci un prezzo valido (es. 18,00).",
    category: form.category ? null : "Scegli una categoria.",
    dishes: form.dishes.length ? null : "Aggiungi almeno un piatto.",
  }
  const hasErr = Object.values(errs).some(Boolean)
  const fe = (k: keyof typeof errs) => (showErr ? errs[k] : null)
  async function save() {
    if (hasErr) { setShowErr(true); requestAnimationFrame(() => document.querySelector<HTMLElement>('[data-slot="sheet-content"] [aria-invalid="true"]')?.focus()); return }
    setBusy(true); setOpError(null); await new Promise((r) => setTimeout(r, 700)); setBusy(false)
    if (failNext) { setFailNext(false); setOpError("Operazione non riuscita. " + SERR); return }
    const isNew = selId === -1
    if (isNew) setMenus((x) => [...x, { id: nextId++, ...form, name: form.name.trim() }]); else patchMenu(selId!, { ...form, name: form.name.trim() })
    setSelId(null); setNotice({ kind: "ok", title: isNew ? "Menù fisso aggiunto" : "Menù fisso salvato", text: "Per vederlo sul menù pubblico serve «Ricompila il menù pubblico»." })
  }
  async function doDelete() {
    if (!delTarget) return
    setDelBusy(true); await new Promise((r) => setTimeout(r, 600)); setDelBusy(false)
    const id = delTarget.id; setMenus((x) => x.filter((m) => m.id !== id)); setDelTarget(null)
    setNotice({ kind: "ok", title: "Menù fisso eliminato", text: "Per toglierlo dal menù pubblico serve «Ricompila il menù pubblico»." })
  }
  async function rebuild() { setRebuildBusy(true); await new Promise((r) => setTimeout(r, 800)); setRebuildBusy(false); setRebuildOpen(false); setNotice({ kind: "ok", title: "Ricompilazione avviata", text: "Il menù pubblico si aggiorna tra alcuni minuti." }) }
  // composizione dei piatti
  const move = (i: number, d: number) => setForm((f) => { const a = [...f.dishes]; const j = i + d; if (j < 0 || j >= a.length) return f; [a[i], a[j]] = [a[j], a[i]]; return { ...f, dishes: a } })
  const removeRow = (i: number) => setForm((f) => ({ ...f, dishes: f.dishes.filter((_, k) => k !== i) }))
  const setRow = (i: number, p: Partial<Row>) => setForm((f) => ({ ...f, dishes: f.dishes.map((r, k) => (k === i ? { ...r, ...p } : r)) }))
  const topSheet = () => requestAnimationFrame(() => document.querySelector<HTMLElement>('[data-slot="sheet-content"]')?.scrollTo(0, 0))
  const backToForm = () => { setView("form"); requestAnimationFrame(() => requestAnimationFrame(() => document.querySelector<HTMLElement>('[data-block="piatti"]')?.scrollIntoView({ block: "start" }))) }
  const openPicker = () => { setPick(form.dishes.map((r) => r.dish)); setPickQ(""); setView("piatti"); topSheet() }
  const applyPicker = () => { setForm((f) => { const keep = f.dishes.filter((r) => pick.includes(r.dish)); const added = pick.filter((id) => !f.dishes.some((r) => r.dish === id)).map((id) => R(id)); return { ...f, dishes: [...keep, ...added] } }); backToForm() }
  // categorie
  function openCatEdit(c: Cat) { setCatForm({ name: c.name, nameEn: c.nameEn, vis: c.vis, disabled: c.disabled }); setCatEn(!!c.nameEn); setCatErr(false); setCatSel(c.id) }
  function openCatNew() { setCatForm({ name: "", nameEn: "", vis: "always", disabled: false }); setCatEn(false); setCatErr(false); setCatSel(-1) }
  function saveCat() {
    if (!catForm.name.trim()) { setCatErr(true); requestAnimationFrame(() => document.querySelector<HTMLElement>('[data-slot="sheet-content"] [aria-invalid="true"]')?.focus()); return }
    const isNew = catSel === -1
    if (isNew) setCats((x) => [...x, { id: nextId++, ...catForm, name: catForm.name.trim() }]); else setCats((x) => x.map((c) => (c.id === catSel ? { ...c, ...catForm, name: catForm.name.trim() } : c)))
    setCatSel(null); setNotice({ kind: "ok", title: isNew ? "Categoria aggiunta" : "Categoria salvata", text: "Per vederla sul menù pubblico serve «Ricompila il menù pubblico»." })
  }
  function demo(v: string) {
    setNotice(null); setLoadState("ok"); setFailNext(false); setMenus(initialMenus); setCats(initialCats)
    if (v === "caricamento") setLoadState("loading"); if (v === "errore-caricamento") setLoadState("error"); if (v === "vuoto") { setMenus([]) }
    if (v === "senza-categorie") { setMenus([]); setCats([]) }
    if (v === "errore-azione") setFailNext(true)
  }
  const giorni = delTarget ? GIORNI[delTarget.name] ?? [] : [] // nel progetto: giorni speciali che contengono il menù, letti con la sessione dell'utente

  const dishLine = (m: Menu) => pl(m.dishes.length, "piatto", "piatti")
  const Actions = ({ m }: { m: Menu }) => (
    <div className="flex items-center">
      <Button variant="ghost" size="icon" aria-label={`Modifica ${m.name}`} data-component="Button" onClick={() => openEdit(m)}><Pencil /></Button>
      <Button variant="ghost" size="icon" aria-label={`Elimina ${m.name}`} data-component="Button" onClick={() => setDelTarget(m)}><Trash2 /></Button>
    </div>
  )
  const Avail = ({ m }: { m: Menu }) => <Switch data-component="Switch" aria-label={`Disponibile: ${m.name}`} checked={!m.disabled} onCheckedChange={() => toggleMenu(m)} />
  const Group = ({ c }: { c: Cat }) => {
    const rows = menus.filter((m) => m.category === c.id).sort((a, b) => a.name.localeCompare(b.name, "it", { sensitivity: "base" })); if (!rows.length) return null
    return (
      <section data-block={`gruppo-${c.name.toLowerCase().replace(/\s+/g, "-")}`} className="flex flex-col gap-2">
        <h2 className="flex flex-wrap items-baseline gap-x-2 text-base font-semibold">{c.name} <span className="text-sm font-normal text-muted-foreground">{pl(rows.length, "menù", "menù")} · {VIS_LABEL[c.vis]}{c.disabled ? " · categoria disabilitata" : ""}</span></h2>
        <div className="hidden rounded-lg border md:block" data-block="elenco-tabella">
          <Table data-component="Table" className="table-fixed">
            <TableHeader><TableRow><TableHead>Nome</TableHead><TableHead className="w-32">Visibilità</TableHead><TableHead className="w-28">Prezzo</TableHead><TableHead className="w-28">Disponibile</TableHead><TableHead className="w-24"><span className="sr-only">Azioni</span></TableHead></TableRow></TableHeader>
            <TableBody>
              {rows.map((m) => (
                <TableRow key={m.id} className={m.disabled ? "text-muted-foreground" : ""}>
                  <TableCell><div className="flex flex-wrap items-center gap-2"><span className="truncate text-sm font-medium">{m.name}</span>{m.specialOnly && <Badge data-component="Badge" variant="secondary">Solo giorni speciali</Badge>}{m.disabled && <Badge data-component="Badge" variant="outline">Disabilitato</Badge>}</div><div className="text-xs text-muted-foreground">{dishLine(m)}</div></TableCell>
                  <TableCell className="text-sm">{VIS_LABEL[m.vis]}</TableCell>
                  <TableCell className="tabular-nums">{euro(m.price)}</TableCell>
                  <TableCell><Avail m={m} /></TableCell>
                  <TableCell className="text-right"><Actions m={m} /></TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </div>
        <div className="flex flex-col gap-2 md:hidden" data-block="elenco-schede">
          {rows.map((m) => (
            <Card key={m.id} size="sm" data-component="Card" className={m.disabled ? "text-muted-foreground" : ""}>
              <CardContent className="flex items-center gap-2">
                <div className="min-w-0 flex-1 py-1">
                  <div className="truncate text-sm font-medium">{m.name}</div>
                  <div className="truncate text-xs text-muted-foreground"><span className="tabular-nums">{euro(m.price)}</span> · {VIS_LABEL[m.vis]} · {dishLine(m)}</div>
                  {(m.specialOnly || m.disabled) && <div className="mt-0.5 flex flex-wrap gap-1">{m.specialOnly && <Badge data-component="Badge" variant="secondary">Solo giorni speciali</Badge>}{m.disabled && <Badge data-component="Badge" variant="outline">Disabilitato</Badge>}</div>}
                </div>
                <label className="flex flex-col items-center gap-1 text-[11px] text-muted-foreground"><Avail m={m} />Disponibile</label>
                <Actions m={m} />
              </CardContent>
            </Card>
          ))}
        </div>
      </section>
    )
  }
  const Skel = () => <div className="flex flex-col gap-2" aria-busy="true" data-block="caricamento">{[0, 1, 2, 3].map((i) => <Skeleton key={i} className="h-16 w-full rounded-xl" />)}</div>
  const visInfo = visNote(catById(form.category), form.vis)
  const pickList = (q: string) => DISH_CATS.map((c) => ({ c, rows: DISHES.filter((d) => d.cat === c && d.name.toLowerCase().includes(q.trim().toLowerCase())) })).filter((g) => g.rows.length)

  return (
    <Shell themeSwitch adminInUserMenu menu={<MenuOtto active="Menù fissi" />}
      topbar={<Breadcrumb><BreadcrumbList><BreadcrumbItem><BreadcrumbLink href="#">Menù</BreadcrumbLink></BreadcrumbItem><BreadcrumbSeparator /><BreadcrumbItem>{tab === "categorie" ? <BreadcrumbLink href="#">Menù fissi</BreadcrumbLink> : <BreadcrumbPage>Menù fissi</BreadcrumbPage>}</BreadcrumbItem>{tab === "categorie" && <><BreadcrumbSeparator /><BreadcrumbItem><BreadcrumbPage>Categorie</BreadcrumbPage></BreadcrumbItem></>}</BreadcrumbList></Breadcrumb>}>
      <div className="mx-auto flex w-full max-w-5xl flex-col gap-5" data-block="contenitore-elenco">
        <div className="flex flex-col gap-3 sm:flex-row sm:items-start sm:justify-between" data-block="intestazione-pagina">
          <div><h1 className="text-xl font-semibold tracking-tight">Menù fissi</h1><p className="text-sm text-muted-foreground">I menù a prezzo fisso e le loro categorie.</p></div>
          <Button variant="outline" size="lg" data-component="Button" onClick={() => setRebuildOpen(true)}><RefreshCw data-icon="inline-start" /> Ricompila il menù pubblico</Button>
        </div>
        {notice && <Alert role="status" data-component="Alert" variant={notice.kind === "err" ? "destructive" : "default"}>{notice.kind === "err" ? <CircleAlert /> : <CircleCheck />}<AlertTitle>{notice.title}</AlertTitle>{notice.text && <AlertDescription>{notice.text}</AlertDescription>}</Alert>}
        <Tabs value={tab} onValueChange={(v) => setTab(v as string)} className="gap-5">
          <div className="-mx-4 overflow-x-auto px-4 md:mx-0 md:px-0" data-block="schede"><TabsList variant="line" data-component="Tabs" data-variant="line"><TabsTrigger value="menu">Menù fissi</TabsTrigger><TabsTrigger value="categorie">Categorie</TabsTrigger></TabsList></div>
          <TabsContent value="menu" className="flex flex-col gap-5">
            <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">{menus.length ? <p className="text-sm text-muted-foreground">{pl(menus.length, "menù fisso", "menù fissi")}, raggruppati per categoria.</p> : <span />}<Button size="lg" data-component="Button" onClick={openNew}><Plus data-icon="inline-start" /> Nuovo menù fisso</Button></div>
            {loadState === "loading" && <Skel />}
            {loadState === "error" && <Alert variant="destructive" role="alert" data-component="Alert"><CircleAlert /><AlertTitle>Impossibile caricare i menù fissi</AlertTitle><AlertDescription><p>Riprova tra qualche istante; se il problema continua, avvisa l’amministratore.</p><Button variant="outline" className="mt-3" data-component="Button" onClick={() => setLoadState("ok")}>Riprova</Button></AlertDescription></Alert>}
            {(loadState === "empty" || (loadState === "ok" && menus.length === 0)) && <div className="flex flex-col items-start gap-3 rounded-lg border border-dashed p-6" data-block="vuoto"><p className="text-sm text-muted-foreground">Nessun menù fisso.</p><Button variant="outline" data-component="Button" onClick={openNew}>Nuovo menù fisso</Button></div>}
            {loadState === "ok" && menus.length > 0 && <div className="flex flex-col gap-6">{sortedCats.map((c) => <Group key={c.id} c={c} />)}</div>}
          </TabsContent>
          <TabsContent value="categorie" className="flex flex-col gap-5">
            <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between"><p className="text-sm text-muted-foreground">{pl(cats.length, "categoria", "categorie")}, in ordine per nome.</p><Button size="lg" data-component="Button" onClick={openCatNew}><Plus data-icon="inline-start" /> Nuova categoria</Button></div>
            {cats.length === 0
              ? <div className="flex flex-col items-start gap-3 rounded-lg border border-dashed p-6" data-block="vuoto-categorie"><p className="text-sm text-muted-foreground">Nessuna categoria. Creane una per poter comporre i menù fissi.</p><Button variant="outline" data-component="Button" onClick={openCatNew}>Nuova categoria</Button></div>
              : <div className="flex flex-col gap-2" data-block="elenco-categorie">{sortedCats.map((c) => (
                <Card key={c.id} size="sm" data-component="Card" className={c.disabled ? "text-muted-foreground" : ""}>
                  <CardContent className="flex items-center gap-2">
                    <div className="min-w-0 flex-1 py-1"><div className="truncate text-sm font-medium">{c.name}</div><div className="mt-0.5 flex items-center gap-2 text-xs text-muted-foreground"><span>{VIS_LABEL[c.vis]}</span><span>·</span><span>{pl(menus.filter((m) => m.category === c.id).length, "menù", "menù")}</span>{c.disabled && <Badge data-component="Badge" variant="outline">Disabilitata</Badge>}</div></div>
                    <label className="flex flex-col items-center gap-1 text-[11px] text-muted-foreground"><Switch data-component="Switch" aria-label={`Attiva: ${c.name}`} checked={!c.disabled} onCheckedChange={() => toggleCat(c)} />Attiva</label>
                    <Button variant="ghost" size="icon" aria-label={`Modifica ${c.name}`} data-component="Button" onClick={() => openCatEdit(c)}><Pencil /></Button>
                  </CardContent>
                </Card>))}</div>}
          </TabsContent>
        </Tabs>
      </div>

      {/* Modulo del menù fisso: due viste nello stesso foglio (modulo e «Scegli piatti») */}
      <Sheet open={selId !== null} onOpenChange={(o) => { if (!o && !busy) setSelId(null) }}>
        <SheetContent side={narrow ? "bottom" : "right"} data-component="Sheet" data-state={view === "piatti" ? "scegli-piatti" : selId === -1 ? "new" : "edit"}>
          {view === "piatti" ? (
            <>
              <SheetHeader>
                <div className="flex items-center gap-1"><Button variant="ghost" size="icon" aria-label="Indietro al modulo" data-component="Button" onClick={backToForm}><ArrowLeft /></Button><SheetTitle>Scegli piatti</SheetTitle></div>
                <SheetDescription>Spunta i piatti del menù. Quelli già scelti sono spuntati.</SheetDescription>
              </SheetHeader>
              <div className="flex flex-col gap-4 px-4" data-block="scegli-piatti">
                <div className="relative"><Search className="pointer-events-none absolute top-1/2 left-3 size-4 -translate-y-1/2 text-muted-foreground" /><Input data-component="Input" aria-label="Cerca un piatto" placeholder="Cerca un piatto" className="pl-9" value={pickQ} onChange={(e) => setPickQ(e.target.value)} /></div>
                {pickList(pickQ).length === 0 ? <p className="text-sm text-muted-foreground">Nessun piatto trovato.</p> : pickList(pickQ).map((g) => (
                  <FieldSet key={g.c}>
                    <FieldLegend variant="label">{g.c}</FieldLegend>
                    {g.rows.map((d) => (
                      <Field key={d.id} orientation="horizontal">
                        <Checkbox id={`p-${d.id}`} data-component="Checkbox" checked={pick.includes(d.id)} onCheckedChange={(c) => setPick((p) => (c === true ? [...p, d.id] : p.filter((x) => x !== d.id)))} />
                        <FieldLabel htmlFor={`p-${d.id}`} className="min-h-11 flex-1 flex-wrap items-center gap-2 font-normal">{d.name}<DishBadges d={d} /></FieldLabel>
                      </Field>
                    ))}
                  </FieldSet>
                ))}
              </div>
              <SheetFooter className="grid grid-cols-2"><Button size="lg" onClick={applyPicker}>Fatto ({pick.length})</Button><Button size="lg" variant="outline" onClick={backToForm}>Annulla</Button></SheetFooter>
            </>
          ) : (
            <>
              <SheetHeader><SheetTitle>{selId === -1 ? "Nuovo menù fisso" : "Modifica menù fisso"}</SheetTitle><SheetDescription>{selId === -1 ? "Il menù compare nel menù pubblico dopo la ricompilazione." : form.name}</SheetDescription></SheetHeader>
              <FieldGroup className="px-4" data-block="modulo-menu-fisso">
                {opError && <Alert variant="destructive" role="alert" data-component="Alert"><CircleAlert /><AlertTitle>Operazione non riuscita</AlertTitle><AlertDescription>{SERR}</AlertDescription></Alert>}
                <FieldSet data-block="dati">
                  <FieldLegend variant="label">Dati</FieldLegend>
                  <Field data-invalid={fe("name") ? true : undefined}><FieldLabel htmlFor="m-nome">Nome</FieldLabel><Input id="m-nome" value={form.name} aria-invalid={fe("name") ? true : undefined} onChange={(e) => setF("name", e.target.value)} />{fe("name") && <FieldError>{fe("name")}</FieldError>}</Field>
                  <Field><FieldLabel htmlFor="m-desc">Descrizione</FieldLabel><Textarea id="m-desc" data-component="Textarea" value={form.desc} onChange={(e) => setF("desc", e.target.value)} /></Field>
                  <Field data-invalid={fe("price") ? true : undefined}><FieldLabel htmlFor="m-prezzo">Prezzo (€)</FieldLabel><Input id="m-prezzo" inputMode="decimal" value={form.price} aria-invalid={fe("price") ? true : undefined} onChange={(e) => setF("price", e.target.value)} />{fe("price") && <FieldError>{fe("price")}</FieldError>}</Field>
                </FieldSet>
                <FieldSet data-block="categoria-visibilita">
                  <FieldLegend variant="label">Categoria e visibilità</FieldLegend>
                  <Field data-invalid={fe("category") ? true : undefined}>
                    <FieldLabel htmlFor="m-cat">Categoria</FieldLabel>
                    <SelectField id="m-cat" items={sortedCats.filter((c) => !c.disabled || c.id === form.category).map((c) => ({ value: String(c.id), label: c.name }))} value={form.category ? String(form.category) : ""} onChange={setCategory} placeholder={cats.length ? "Scegli" : "Nessuna categoria: creane una nella scheda Categorie"} disabled={cats.length === 0} invalid={!!fe("category")} />
                    {fe("category") && <FieldError>{fe("category")}</FieldError>}
                  </Field>
                  <Field>
                    <FieldLabel htmlFor="m-vis">Visibilità</FieldLabel>
                    <SelectField id="m-vis" items={VIS_ITEMS} value={form.vis} onChange={(v) => { setVisTouched(true); setF("vis", v as Vis) }} />
                    <FieldDescription>Quando compare nel menù pubblico. Vale insieme alla visibilità della categoria.</FieldDescription>
                  </Field>
                  {visInfo && <Alert data-component="Alert" role="status" variant={visInfo.kind === "warn" ? "destructive" : "default"}>{visInfo.kind === "warn" ? <CircleAlert /> : <Info />}<AlertDescription>{visInfo.text}</AlertDescription></Alert>}
                  <Field orientation="horizontal"><div className="flex-1"><FieldLabel htmlFor="m-spec" className="min-h-11 items-center">Solo giorni speciali</FieldLabel><FieldDescription>Se attivo, il menù non compare nelle pagine normali del menù pubblico, solo tramite i giorni speciali.</FieldDescription></div><Switch id="m-spec" data-component="Switch" checked={form.specialOnly} onCheckedChange={(c) => setF("specialOnly", c === true)} /></Field>
                </FieldSet>
                <FieldSet data-block="piatti">
                  <FieldLegend variant="label">Piatti</FieldLegend>
                  {form.dishes.length === 0 && <p className="text-sm text-muted-foreground">Nessun piatto nel menù.</p>}
                  {form.dishes.map((r, i) => { const d = dishById(r.dish); return (
                    <div key={r.dish} className="flex flex-col gap-2 rounded-lg border p-3" data-block="piatto-nel-menu">
                      <div className="flex items-center gap-1">
                        <div className="flex min-w-0 flex-1 flex-wrap items-center gap-2"><span className="text-sm font-medium">{i + 1}. {d.name}</span><DishBadges d={d} /></div>
                        <Button variant="ghost" size="icon" aria-label={`Sposta su ${d.name}`} data-component="Button" disabled={i === 0} onClick={() => move(i, -1)}><ArrowUp /></Button>
                        <Button variant="ghost" size="icon" aria-label={`Sposta giù ${d.name}`} data-component="Button" disabled={i === form.dishes.length - 1} onClick={() => move(i, 1)}><ArrowDown /></Button>
                        <Button variant="ghost" size="icon" aria-label={`Togli ${d.name} dal menù`} data-component="Button" onClick={() => removeRow(i)}><X /></Button>
                      </div>
                      <Field><FieldLabel htmlFor={`m-por-${r.dish}`} className="text-xs text-muted-foreground">Porzione</FieldLabel><Input id={`m-por-${r.dish}`} placeholder="Facoltativa, per esempio «2 pezzi»" value={r.portion} onChange={(e) => setRow(i, { portion: e.target.value })} /></Field>
                    </div>
                  ) })}
                  {fe("dishes") && <FieldError>{fe("dishes")}</FieldError>}
                  <Button type="button" variant="outline" size="lg" data-component="Button" aria-invalid={fe("dishes") ? true : undefined} onClick={openPicker}><Plus data-icon="inline-start" /> {form.dishes.length ? "Aggiungi o togli piatti" : "Aggiungi piatti"}</Button>
                  <FieldDescription>La porzione serve solo se la quantità nel menù è diversa da quella alla carta.</FieldDescription>
                </FieldSet>
                <FieldSet data-block="servizi">
                  <FieldLegend variant="label">Servizi</FieldLegend>
                  {SERVICES.map((s) => (
                    <Field key={s.id} orientation="horizontal"><Checkbox id={`m-s-${s.id}`} data-component="Checkbox" checked={form.services.includes(s.id)} onCheckedChange={(c) => setF("services", c === true ? [...form.services, s.id] : form.services.filter((x) => x !== s.id))} /><FieldLabel htmlFor={`m-s-${s.id}`} className="min-h-11 flex-1 items-center font-normal">{s.name} <span className="text-muted-foreground tabular-nums">· {euro(s.price)}</span></FieldLabel></Field>
                  ))}
                </FieldSet>
                <Collapsible open={enOpen} onOpenChange={setEnOpen} className="rounded-lg border" data-block="traduzione-inglese">
                  <CollapsibleTrigger render={<button type="button" className="flex min-h-11 w-full items-center gap-2 px-3 text-left text-sm font-medium" />}>
                    Traduzione inglese <span className="font-normal text-muted-foreground">(facoltativa)</span>
                    <Badge data-component="Badge" variant="outline" className="ml-auto">{form.nameEn || form.descEn || form.dishes.some((r) => r.portionEn) ? "Presente" : "Manca"}</Badge><ChevronDown className={`size-4 transition-transform ${enOpen ? "rotate-180" : ""}`} />
                  </CollapsibleTrigger>
                  <CollapsibleContent><div className="flex flex-col gap-4 border-t p-3">
                    <Field><FieldLabel htmlFor="m-nome-en">Name</FieldLabel><Input id="m-nome-en" placeholder={form.name} value={form.nameEn} onChange={(e) => setF("nameEn", e.target.value)} /></Field>
                    <Field><FieldLabel htmlFor="m-desc-en">Description</FieldLabel><Textarea id="m-desc-en" value={form.descEn} onChange={(e) => setF("descEn", e.target.value)} /></Field>
                    {form.dishes.some((r) => r.portion) && <FieldSet><FieldLegend variant="label">Porzioni</FieldLegend>{form.dishes.map((r, i) => r.portion ? <Field key={r.dish}><FieldLabel htmlFor={`m-pe-${r.dish}`}>{dishById(r.dish).name}</FieldLabel><Input id={`m-pe-${r.dish}`} placeholder={r.portion} value={r.portionEn} onChange={(e) => setRow(i, { portionEn: e.target.value })} /></Field> : null)}</FieldSet>}
                    <FieldDescription>Facoltativa. Quello che resta vuoto, il menù lo mostra in italiano.</FieldDescription>
                  </div></CollapsibleContent>
                </Collapsible>
                <FieldSet data-block="disponibilita">
                  <FieldLegend variant="label">Disponibilità</FieldLegend>
                  <Field orientation="horizontal"><div className="flex-1"><FieldLabel htmlFor="m-dis" className="min-h-11 items-center">Disabilitato</FieldLabel><FieldDescription>Assente a tempo indefinito: il menù fisso non compare nel menù.</FieldDescription></div><Switch id="m-dis" data-component="Switch" checked={form.disabled} onCheckedChange={(c) => setF("disabled", c === true)} /></Field>
                </FieldSet>
              </FieldGroup>
              <SheetFooter className="grid grid-cols-2"><Button size="lg" onClick={save} disabled={busy}>{busy && <Spinner data-icon="inline-start" />}{busy ? "Salvataggio…" : "Salva"}</Button><Button size="lg" variant="outline" disabled={busy} onClick={() => setSelId(null)}>Annulla</Button></SheetFooter>
            </>
          )}
        </SheetContent>
      </Sheet>

      {/* Modulo della categoria */}
      <Sheet open={catSel !== null} onOpenChange={(o) => { if (!o) setCatSel(null) }}>
        <SheetContent side={narrow ? "bottom" : "right"} data-component="Sheet" data-state={catSel === -1 ? "new-category" : "edit-category"}>
          <SheetHeader><SheetTitle>{catSel === -1 ? "Nuova categoria" : "Modifica categoria"}</SheetTitle><SheetDescription>{catSel === -1 ? "Raggruppa i menù fissi nel menù pubblico." : catForm.name}</SheetDescription></SheetHeader>
          <FieldGroup className="px-4" data-block="modulo-categoria">
            <Field data-invalid={catErr && !catForm.name.trim() ? true : undefined}><FieldLabel htmlFor="c-nome">Nome</FieldLabel><Input id="c-nome" value={catForm.name} aria-invalid={catErr && !catForm.name.trim() ? true : undefined} onChange={(e) => setCatForm({ ...catForm, name: e.target.value })} />{catErr && !catForm.name.trim() && <FieldError>Campo obbligatorio.</FieldError>}</Field>
            <Collapsible open={catEn} onOpenChange={setCatEn} className="rounded-lg border">
              <CollapsibleTrigger render={<button type="button" className="flex min-h-11 w-full items-center gap-2 px-3 text-left text-sm font-medium" />}>Traduzione inglese <span className="font-normal text-muted-foreground">(facoltativa)</span><Badge data-component="Badge" variant="outline" className="ml-auto">{catForm.nameEn ? "Presente" : "Manca"}</Badge><ChevronDown className={`size-4 transition-transform ${catEn ? "rotate-180" : ""}`} /></CollapsibleTrigger>
              <CollapsibleContent><div className="flex flex-col gap-4 border-t p-3"><Field><FieldLabel htmlFor="c-nome-en">Name</FieldLabel><Input id="c-nome-en" placeholder={catForm.name} value={catForm.nameEn} onChange={(e) => setCatForm({ ...catForm, nameEn: e.target.value })} /><FieldDescription>Facoltativa. Se resta vuota, il menù mostra il testo italiano.</FieldDescription></Field></div></CollapsibleContent>
            </Collapsible>
            <Field><FieldLabel htmlFor="c-vis">Visibilità</FieldLabel><SelectField id="c-vis" items={VIS_ITEMS} value={catForm.vis} onChange={(v) => setCatForm({ ...catForm, vis: v as Vis })} /><FieldDescription>Quando la categoria compare nelle pagine del menù pubblico.</FieldDescription></Field>
            <Field orientation="horizontal"><div className="flex-1"><FieldLabel htmlFor="c-dis" className="min-h-11 items-center">Disabilitata</FieldLabel><FieldDescription>Assente a tempo indefinito: la categoria non compare nel menù.</FieldDescription></div><Switch id="c-dis" data-component="Switch" checked={catForm.disabled} onCheckedChange={(c) => setCatForm({ ...catForm, disabled: c === true })} /></Field>
          </FieldGroup>
          <SheetFooter className="grid grid-cols-2"><Button size="lg" onClick={saveCat}>Salva</Button><Button size="lg" variant="outline" onClick={() => setCatSel(null)}>Annulla</Button></SheetFooter>
        </SheetContent>
      </Sheet>

      {/* Elimina un menù: il cascade sui giorni speciali è dichiarato prima di «Non si può annullare.» (D14) */}
      <AlertDialog open={delTarget !== null} onOpenChange={(o) => { if (!o && !delBusy) setDelTarget(null) }}>
        <AlertDialogContent data-component="AlertDialog" data-state={giorni.length ? "elimina-con-uso" : "elimina"}>
          <AlertDialogHeader><AlertDialogTitle>Eliminare {delTarget?.name}?</AlertDialogTitle>
            <AlertDialogDescription>{giorni.length ? `Verrà tolto anche da ${pl(giorni.length, "giorno speciale", "giorni speciali")}: ${giorni.join(", ")}. Non si può annullare.` : "Non si può annullare."}</AlertDialogDescription></AlertDialogHeader>
          <AlertDialogFooter><AlertDialogCancel disabled={delBusy}>Indietro</AlertDialogCancel><Button variant="destructive" data-component="Button" onClick={doDelete} disabled={delBusy}>{delBusy && <Spinner data-icon="inline-start" />}Elimina</Button></AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

      {/* Ricompila (componente condiviso con Piatti) */}
      <AlertDialog open={rebuildOpen} onOpenChange={(o) => !o && !rebuildBusy && setRebuildOpen(false)}>
        <AlertDialogContent data-component="AlertDialog" data-state="ricompila">
          <AlertDialogHeader><AlertDialogTitle>Ricompilare il menù pubblico?</AlertDialogTitle>
            <AlertDialogDescription>La pubblicazione richiede alcuni minuti. Serve per vedere piatti nuovi e modifiche ai contenuti, ai servizi, agli orari, alle chiusure e ai giorni speciali. «Terminato» e «disabilitato» valgono già.</AlertDialogDescription></AlertDialogHeader>
          <AlertDialogFooter><AlertDialogCancel disabled={rebuildBusy}>Indietro</AlertDialogCancel><Button data-component="Button" onClick={rebuild} disabled={rebuildBusy}>{rebuildBusy && <Spinner data-icon="inline-start" />}Ricompila</Button></AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

      <div data-demo className="fixed bottom-2 right-2 z-50 rounded-md border bg-card px-1.5 py-0.5 text-[11px] text-muted-foreground shadow-xs">
        <label>Demo stato <select aria-label="Stato demo" className="bg-transparent text-foreground" defaultValue="normale" onChange={(e) => demo(e.target.value)}>
          <option value="normale">normale</option><option value="caricamento">caricamento</option><option value="errore-caricamento">errore di caricamento</option><option value="vuoto">nessun menù fisso</option>
          <option value="senza-categorie">nessuna categoria né menù (stato di produzione)</option><option value="errore-azione">errore all’azione successiva</option>
        </select></label>
      </div>
    </Shell>
  )
}
export const fissiPage = <FissiPage />
