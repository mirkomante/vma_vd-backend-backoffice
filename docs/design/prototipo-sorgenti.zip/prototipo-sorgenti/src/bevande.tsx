import * as React from "react"
import { Pencil, Trash2, Plus, Search, SlidersHorizontal, X, CircleCheck, CircleAlert, ChevronDown, RefreshCw, Info } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { Switch } from "@/components/ui/switch"
import { Badge } from "@/components/ui/badge"
import { Card, CardContent } from "@/components/ui/card"
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert"
import { Skeleton } from "@/components/ui/skeleton"
import { Spinner } from "@/components/ui/spinner"
import { Field, FieldDescription, FieldError, FieldGroup, FieldLabel, FieldLegend, FieldSet } from "@/components/ui/field"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Sheet, SheetContent, SheetDescription, SheetFooter, SheetHeader, SheetTitle } from "@/components/ui/sheet"
import { AlertDialog, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle } from "@/components/ui/alert-dialog"
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from "@/components/ui/collapsible"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Breadcrumb, BreadcrumbItem, BreadcrumbList, BreadcrumbPage, BreadcrumbSeparator, BreadcrumbLink } from "@/components/ui/breadcrumb"
import { SidebarGroup, SidebarGroupContent, SidebarGroupLabel, SidebarMenu, SidebarMenuButton, SidebarMenuItem } from "@/components/ui/sidebar"
import { useIsMobile } from "@/hooks/use-mobile"
import { Shell } from "./layouts"
import { UtensilsCrossed, Wine, CupSoda, Martini, BookOpen, ConciergeBell, CalendarHeart, Megaphone, Clock, CalendarDays, Settings } from "lucide-react"

/* ---------- navigazione a otto voci (D1) ---------- */
const GRUPPI: { label: string; voci: { label: string; icon: React.ComponentType<any> }[] }[] = [
  { label: "Menù", voci: [{ label: "Piatti", icon: UtensilsCrossed }, { label: "Vini", icon: Wine }, { label: "Bevande", icon: CupSoda }, { label: "Distillati", icon: Martini }, { label: "Menù fissi", icon: BookOpen }, { label: "Servizi", icon: ConciergeBell }, { label: "Giorni speciali", icon: CalendarHeart }, { label: "Messaggio globale", icon: Megaphone }] },
  { label: "Orari", voci: [{ label: "Orari", icon: Clock }] },
  { label: "Prenotazioni", voci: [{ label: "Elenco", icon: CalendarDays }, { label: "Eccezioni giorno", icon: CalendarDays }, { label: "Impostazioni", icon: Settings }] },
]
function MenuOtto({ active }: { active: string }) {
  return (
    <>
      {GRUPPI.map((g) => (
        <SidebarGroup key={g.label}>
          <SidebarGroupLabel>{g.label}</SidebarGroupLabel>
          <SidebarGroupContent>
            <SidebarMenu>
              {g.voci.map((v) => (
                <SidebarMenuItem key={v.label}>
                  <SidebarMenuButton render={<a href="#" />} isActive={g.label === "Menù" && v.label === active} tooltip={v.label}><v.icon /><span>{v.label}</span></SidebarMenuButton>
                </SidebarMenuItem>
              ))}
            </SidebarMenu>
          </SidebarGroupContent>
        </SidebarGroup>
      ))}
    </>
  )
}

/* ---------- dati di esempio (nel progetto: collection wines e tassonomie) ---------- */
// Paesi abilitati (12 del seed, Libano no): nella schermata vera è un'interrogazione filtrata (enabled). Tipologie: dalle `drink-types` (nello snapshot sono create dai nomi; «Birre» si crea a mano).
const PAESI = ["Filippine", "Francia", "Giappone", "Guatemala", "Guyana", "Italia", "Martinica", "Scozia", "Thailandia", "Trinidad e Tobago", "Venezuela", "Vietnam"]
const TIPI = ["Acque", "Bibite", "Birre", "Tè e infusi"] // ordine per nome (ADR-112)
// Formati (decisione del 2026-10-14): capacità a scelta (25, 33, 50, 75 cl) e grado a scelta da 3% a 12% a passi di 0,5, come vini e distillati; allergeni non gestiti nell'App.
const CAPACITA = ["25 cl", "33 cl", "50 cl", "75 cl"]
const GRADI = Array.from({ length: 19 }, (_, i) => { const v = 3 + i * 0.5; return Number.isInteger(v) ? `${v}%` : `${String(v).replace(".", ",")}%` })
type Dist = { id: number; name: string; nameEn: string; descIt: string; descEn: string; volume: string; abv: string; price: string; country: string; type: string; disabled: boolean }
const D = (id: number, name: string, type: string, country: string, volume: string, abv: string, price: string, extra: Partial<Dist> = {}): Dist => ({ id, name, nameEn: "", descIt: "", descEn: "", volume, abv, price, country, type, disabled: false, ...extra })
const initialData: Dist[] = [
  D(1, "Acqua naturale", "Acque", "", "75 cl", "", "3,50", { nameEn: "Still water" }),
  D(2, "Acqua frizzante", "Acque", "", "75 cl", "", "3,50"),
  D(3, "Cola", "Bibite", "", "33 cl", "", "4,00"),
  D(4, "Ginger beer", "Bibite", "", "20 cl", "", "4,50"),
  D(5, "Limonata artigianale", "Bibite", "Italia", "33 cl", "", "4,50"),
  D(6, "Birra chiara", "Birre", "Vietnam", "33 cl", "5%", "5,00", { nameEn: "Lager", descIt: "Leggera e rinfrescante.", descEn: "Light and refreshing." }),
  D(7, "Birra scura", "Birre", "Thailandia", "33 cl", "5,5%", "5,50"),
  D(8, "Birra artigianale", "Birre", "Italia", "50 cl", "6,5%", "8,00"),
  D(9, "Tè verde", "Tè e infusi", "Giappone", "", "", "3,00"),
  D(10, "Tè al gelsomino", "Tè e infusi", "Vietnam", "", "", "3,00", { disabled: true }),
]
const pl = (n: number, one: string, many: string) => (n === 1 ? `1 ${one}` : `${n} ${many}`)
const euro = (p: string) => `${p} €`
const items = (a: string[]) => a.map((v) => ({ value: v, label: v }))
const tipoItems = [{ value: "tutte", label: "Tutte le tipologie" }, ...items(TIPI)]
const paeseItems = [{ value: "tutti", label: "Tutti i paesi" }, ...items(PAESI)]
const statoItems = [{ value: "tutti", label: "Tutte" }, { value: "abilitati", label: "Abilitate" }, { value: "disabilitati", label: "Disabilitate" }]
const SERR = "Non è stato modificato nulla. Controlla la connessione e riprova; se il problema continua, avvisa l’amministratore."
const PRICE_RE = /^\d+([.,]\d{1,2})?$/
type Form = Omit<Dist, "id">
const emptyForm = (): Form => ({ name: "", nameEn: "", descIt: "", descEn: "", volume: "", abv: "", price: "", country: "", type: "", disabled: false })
let nextId = 100

const NONE = "__nessuno"
// Select con valori da elenco. `clearLabel`: prima voce che svuota il campo (solo per i campi facoltativi); un valore salvato fuori elenco resta tra le opzioni.
function SelectField({ id, list, value, onChange, placeholder, disabled, invalid, clearLabel }: { id?: string; list: string[]; value: string; onChange: (v: string) => void; placeholder?: string; disabled?: boolean; invalid?: boolean; clearLabel?: string }) {
  const all = value && !list.includes(value) ? [value, ...list] : list
  const opts = [...(clearLabel ? [{ value: NONE, label: clearLabel }] : []), ...items(all)]
  return (
    <Select items={opts} value={value || null} disabled={disabled} onValueChange={(v) => onChange(v === NONE ? "" : ((v as string) ?? ""))}>
      <SelectTrigger id={id} data-component="Select" className="w-full" aria-invalid={invalid ? true : undefined}><SelectValue placeholder={placeholder} /></SelectTrigger>
      <SelectContent>{opts.map((o) => <SelectItem key={o.value} value={o.value}>{o.label}</SelectItem>)}</SelectContent>
    </Select>
  )
}

function BevandePage() {
  const narrow = useIsMobile()
  const [data, setData] = React.useState<Dist[]>(initialData)
  const [q, setQ] = React.useState("")
  const [filters, setFilters] = React.useState({ tipo: "tutte", paese: "tutti", stato: "tutti" })
  const [draft, setDraft] = React.useState(filters)
  const [filterOpen, setFilterOpen] = React.useState(false)
  const [selId, setSelId] = React.useState<number | null>(null)
  const [form, setForm] = React.useState<Form>(emptyForm())
  const [showErr, setShowErr] = React.useState(false)
  const [enOpen, setEnOpen] = React.useState(false)
  const [busy, setBusy] = React.useState(false)
  const [opError, setOpError] = React.useState<string | null>(null)
  const [notice, setNotice] = React.useState<{ kind: "ok" | "err" | "info"; title: string; text?: string } | null>(null)
  const [loadState, setLoadState] = React.useState<"ok" | "loading" | "error" | "empty">("ok")
  const [failNext, setFailNext] = React.useState(false)
  const [truncated, setTruncated] = React.useState(false)
  const [delTarget, setDelTarget] = React.useState<Dist | null>(null)
  const [delBusy, setDelBusy] = React.useState(false)
  const [rebuildOpen, setRebuildOpen] = React.useState(false)
  const [rebuildBusy, setRebuildBusy] = React.useState(false)

  const term = q.trim().toLowerCase()
  const list = data.filter((v) =>
    (filters.tipo === "tutte" || v.type === filters.tipo) && (filters.paese === "tutti" || v.country === filters.paese) &&
    (filters.stato === "tutti" || (filters.stato === "abilitati") === !v.disabled) && (!term || v.name.toLowerCase().includes(term)))
  const chips: { k: string; label: string }[] = []
  if (filters.tipo !== "tutte") chips.push({ k: "tipo", label: filters.tipo })
  if (filters.paese !== "tutti") chips.push({ k: "paese", label: filters.paese })
  if (filters.stato !== "tutti") chips.push({ k: "stato", label: statoItems.find((x) => x.value === filters.stato)!.label })
  const reset = { tipo: "tutte", paese: "tutti", stato: "tutti" }
  const clearChip = (k: string) => setFilters((f) => ({ ...f, [k]: (reset as any)[k] }))
  const patch = (id: number, p: Partial<Dist>) => setData((x) => x.map((v) => (v.id === id ? { ...v, ...p } : v)))

  async function toggle(v: Dist) {
    setNotice(null); await new Promise((r) => setTimeout(r, 250))
    if (failNext) { setFailNext(false); setNotice({ kind: "err", title: "Operazione non riuscita", text: SERR }); return }
    patch(v.id, { disabled: !v.disabled }); setNotice({ kind: "ok", title: v.disabled ? "Bevanda abilitata" : "Bevanda disabilitata", text: "Il menù pubblico si aggiorna entro pochi secondi." })
  }
  function openEdit(v: Dist) { const { id, ...rest } = v; setForm(rest); setEnOpen(!!(v.descEn || v.nameEn)); setShowErr(false); setOpError(null); setSelId(id) }
  function openNew() { setForm(emptyForm()); setEnOpen(false); setShowErr(false); setOpError(null); setSelId(-1) }
  const errs = {
    name: form.name.trim() ? null : "Campo obbligatorio.",
    type: form.type ? null : "Scegli una tipologia.",
    price: !form.price.trim() ? "Campo obbligatorio." : PRICE_RE.test(form.price.trim()) ? null : "Inserisci un prezzo valido (es. 28,50).",
  }
  const hasErr = Object.values(errs).some(Boolean)
  const fe = (k: keyof typeof errs) => (showErr ? errs[k] : null)
  const setF = <K extends keyof Form>(k: K, v: Form[K]) => setForm((f) => ({ ...f, [k]: v }))
  async function save() {
    if (hasErr) { setShowErr(true); requestAnimationFrame(() => document.querySelector<HTMLElement>('[data-slot="sheet-content"] [aria-invalid="true"]')?.focus()); return }
    setBusy(true); setOpError(null); await new Promise((r) => setTimeout(r, 700)); setBusy(false)
    if (failNext) { setFailNext(false); setOpError("Operazione non riuscita. " + SERR); return }
    const isNew = selId === -1
    if (isNew) setData((x) => [...x, { id: nextId++, ...form, name: form.name.trim() }]); else patch(selId!, { ...form, name: form.name.trim() })
    setSelId(null); setNotice({ kind: "ok", title: isNew ? "Bevanda aggiunta" : "Bevanda salvata", text: "Per vederla sul menù pubblico serve «Ricompila il menù pubblico»." })
  }
  async function doDelete() {
    if (!delTarget) return
    setDelBusy(true); await new Promise((r) => setTimeout(r, 600)); setDelBusy(false)
    const id = delTarget.id; setData((x) => x.filter((v) => v.id !== id)); setDelTarget(null)
    setNotice({ kind: "ok", title: "Bevanda eliminata", text: "Per toglierla dal menù pubblico serve «Ricompila il menù pubblico»." })
  }
  async function rebuild() { setRebuildBusy(true); await new Promise((r) => setTimeout(r, 800)); setRebuildBusy(false); setRebuildOpen(false); setNotice({ kind: "ok", title: "Ricompilazione avviata", text: "Il menù pubblico si aggiorna tra alcuni minuti." }) }
  function demo(v: string) {
    setNotice(null); setLoadState("ok"); setFailNext(false); setTruncated(false)
    if (v === "caricamento") setLoadState("loading"); if (v === "errore-caricamento") setLoadState("error"); if (v === "vuoto") setLoadState("empty")
    if (v === "molte-bevande") setTruncated(true); if (v === "errore-azione") setFailNext(true);
  }

  const Actions = ({ v }: { v: Dist }) => (
    <div className="flex items-center">
      <Button variant="ghost" size="icon" aria-label={`Modifica ${v.name}`} data-component="Button" onClick={() => openEdit(v)}><Pencil /></Button>
      <Button variant="ghost" size="icon" aria-label={`Elimina ${v.name}`} data-component="Button" onClick={() => setDelTarget(v)}><Trash2 /></Button>
    </div>
  )
  const Avail = ({ v }: { v: Dist }) => <Switch data-component="Switch" aria-label={`Disponibile: ${v.name}`} checked={!v.disabled} onCheckedChange={() => toggle(v)} />
  const sub = (v: Dist) => [v.volume, v.abv].filter(Boolean).join(" · ")
  const Group = ({ tipo }: { tipo: string }) => {
    const rows = list.filter((v) => v.type === tipo).sort((a, b) => a.name.localeCompare(b.name, "it", { sensitivity: "base" })); if (!rows.length) return null
    return (
      <section data-block={`gruppo-${tipo.toLowerCase()}`} className="flex flex-col gap-2">
        <h2 className="flex items-baseline gap-2 text-base font-semibold">{tipo} <span className="text-sm font-normal text-muted-foreground">{pl(rows.length, "bevanda", "bevande")}</span></h2>
        <div className="hidden rounded-lg border md:block" data-block="elenco-tabella">
          <Table data-component="Table" className="table-fixed">
            <TableHeader><TableRow><TableHead>Nome</TableHead><TableHead className="w-44">Paese</TableHead><TableHead className="w-28">Prezzo</TableHead><TableHead className="w-28">Disponibile</TableHead><TableHead className="w-24"><span className="sr-only">Azioni</span></TableHead></TableRow></TableHeader>
            <TableBody>
              {rows.map((v) => (
                <TableRow key={v.id} className={v.disabled ? "text-muted-foreground" : ""}>
                  <TableCell><div className="flex items-center gap-2"><span className="truncate text-sm font-medium">{v.name}</span>{v.disabled && <Badge data-component="Badge" variant="outline">Disabilitata</Badge>}</div><div className="truncate text-xs text-muted-foreground">{sub(v)}</div></TableCell>
                  <TableCell className="text-sm">{v.country}</TableCell>
                  <TableCell className="tabular-nums">{euro(v.price)}</TableCell>
                  <TableCell><Avail v={v} /></TableCell>
                  <TableCell className="text-right"><Actions v={v} /></TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </div>
        <div className="flex flex-col gap-2 md:hidden" data-block="elenco-schede">
          {rows.map((v) => (
            <Card key={v.id} size="sm" data-component="Card" className={v.disabled ? "text-muted-foreground" : ""}>
              <CardContent className="flex items-center gap-2">
                <div className="min-w-0 flex-1 py-1">
                  <div className="truncate text-sm font-medium">{v.name}</div>
                  <div className="truncate text-xs text-muted-foreground">{sub(v)}</div>
                  <div className="mt-0.5 flex items-center gap-2 text-xs text-muted-foreground"><span className="tabular-nums">{euro(v.price)}{v.country && ` · ${v.country}`}</span>{v.disabled && <Badge data-component="Badge" variant="outline">Disabilitata</Badge>}</div>
                </div>
                <label className="flex flex-col items-center gap-1 text-[11px] text-muted-foreground"><Avail v={v} />Disponibile</label>
                <Actions v={v} />
              </CardContent>
            </Card>
          ))}
        </div>
      </section>
    )
  }
  const Skel = () => <div className="flex flex-col gap-2" aria-busy="true" data-block="caricamento">{[0, 1, 2, 3].map((i) => <Skeleton key={i} className="h-16 w-full rounded-xl" />)}</div>
  return (
    <Shell themeSwitch adminInUserMenu menu={<MenuOtto active="Bevande" />}
      topbar={<Breadcrumb><BreadcrumbList><BreadcrumbItem><BreadcrumbLink href="#">Menù</BreadcrumbLink></BreadcrumbItem><BreadcrumbSeparator /><BreadcrumbItem><BreadcrumbPage>Bevande</BreadcrumbPage></BreadcrumbItem></BreadcrumbList></Breadcrumb>}>
      <div className="mx-auto flex w-full max-w-5xl flex-col gap-5" data-block="contenitore-elenco">
        <div className="flex flex-col gap-3 sm:flex-row sm:items-start sm:justify-between" data-block="intestazione-pagina">
          <div><h1 className="text-xl font-semibold tracking-tight">Bevande</h1><p className="text-sm text-muted-foreground">Le bevande del ristorante, birre comprese.</p></div>
          <div className="flex flex-col-reverse gap-2 sm:flex-row">
            <Button variant="outline" size="lg" data-component="Button" onClick={() => setRebuildOpen(true)}><RefreshCw data-icon="inline-start" /> Ricompila il menù pubblico</Button>
            <Button size="lg" data-component="Button" onClick={openNew}><Plus data-icon="inline-start" /> Nuova bevanda</Button>
          </div>
        </div>

        {notice && <Alert role="status" data-component="Alert" variant={notice.kind === "err" ? "destructive" : "default"}>{notice.kind === "err" ? <CircleAlert /> : <CircleCheck />}<AlertTitle>{notice.title}</AlertTitle>{notice.text && <AlertDescription>{notice.text}</AlertDescription>}</Alert>}

        <div className="flex gap-2" data-block="ricerca-filtri">
          <div className="relative min-w-0 flex-1"><Search className="pointer-events-none absolute top-1/2 left-3 size-4 -translate-y-1/2 text-muted-foreground" /><Input data-component="Input" aria-label="Cerca" placeholder="Cerca una bevanda" className="pl-9" value={q} onChange={(e) => setQ(e.target.value)} /></div>
          <Button variant="outline" data-component="Button" onClick={() => { setDraft(filters); setFilterOpen(true) }}><SlidersHorizontal data-icon="inline-start" /> Filtri{chips.length > 0 && <Badge data-component="Badge" className="ml-1">{chips.length}</Badge>}</Button>
        </div>
        {chips.length > 0 && <div className="flex flex-wrap gap-2" data-block="filtri-attivi">{chips.map((c) => <Button key={c.k} variant="secondary" size="sm" data-component="Button" aria-label={`Rimuovi filtro ${c.label}`} onClick={() => clearChip(c.k)}>{c.label}<X data-icon="inline-end" /></Button>)}</div>}

        {loadState === "loading" && <Skel />}
        {loadState === "error" && <Alert variant="destructive" role="alert" data-component="Alert"><CircleAlert /><AlertTitle>Impossibile caricare le bevande</AlertTitle><AlertDescription><p>Riprova tra qualche istante; se il problema continua, avvisa l’amministratore.</p><Button variant="outline" className="mt-3" data-component="Button" onClick={() => setLoadState("ok")}>Riprova</Button></AlertDescription></Alert>}
        {loadState === "empty" && <div className="flex flex-col items-start gap-3 rounded-lg border border-dashed p-6" data-block="vuoto"><p className="text-sm text-muted-foreground">Nessuna bevanda in carta.</p><Button variant="outline" data-component="Button" onClick={openNew}>Nuova bevanda</Button></div>}
        {loadState === "ok" && truncated && <Alert role="status" data-component="Alert" data-state="elenco-parziale"><Info /><AlertTitle>Mostrate 100 bevande su 137</AlertTitle><AlertDescription><p>Restringi l’elenco con la ricerca o i filtri, oppure mostra le altre.</p><Button variant="outline" className="mt-3" data-component="Button" onClick={() => setTruncated(false)}>Mostra altre bevande</Button></AlertDescription></Alert>}
        {loadState === "ok" && (list.length === 0
          ? <div className="flex flex-col items-start gap-3 rounded-lg border border-dashed p-6" data-block="nessun-risultato"><p className="text-sm text-muted-foreground">Nessun risultato con questi filtri.</p><Button variant="outline" data-component="Button" onClick={() => { setFilters(reset); setQ("") }}>Azzera filtri</Button></div>
          : <div className="flex flex-col gap-6">{TIPI.map((t) => <Group key={t} tipo={t} />)}</div>)}
      </div>

      {/* Filtri */}
      <Sheet open={filterOpen} onOpenChange={setFilterOpen}>
        <SheetContent side={narrow ? "bottom" : "right"} data-component="Sheet">
          <SheetHeader><SheetTitle>Filtri</SheetTitle><SheetDescription>Restringi l’elenco delle bevande.</SheetDescription></SheetHeader>
          <FieldGroup className="px-4">
            <Field><FieldLabel htmlFor="f-tipo">Tipologia</FieldLabel><Select items={tipoItems} value={draft.tipo} onValueChange={(v) => setDraft({ ...draft, tipo: v as string })}><SelectTrigger id="f-tipo" data-component="Select" className="w-full"><SelectValue /></SelectTrigger><SelectContent>{tipoItems.map((s) => <SelectItem key={s.value} value={s.value}>{s.label}</SelectItem>)}</SelectContent></Select></Field>
            <Field><FieldLabel htmlFor="f-paese">Paese</FieldLabel><Select items={paeseItems} value={draft.paese} onValueChange={(v) => setDraft({ ...draft, paese: v as string })}><SelectTrigger id="f-paese" data-component="Select" className="w-full"><SelectValue /></SelectTrigger><SelectContent>{paeseItems.map((s) => <SelectItem key={s.value} value={s.value}>{s.label}</SelectItem>)}</SelectContent></Select></Field>
            <Field><FieldLabel htmlFor="f-stato">Stato</FieldLabel><Select items={statoItems} value={draft.stato} onValueChange={(v) => setDraft({ ...draft, stato: v as string })}><SelectTrigger id="f-stato" data-component="Select" className="w-full"><SelectValue /></SelectTrigger><SelectContent>{statoItems.map((s) => <SelectItem key={s.value} value={s.value}>{s.label}</SelectItem>)}</SelectContent></Select></Field>
          </FieldGroup>
          <SheetFooter className="grid grid-cols-2"><Button size="lg" onClick={() => { setFilters(draft); setFilterOpen(false) }}>Applica</Button><Button size="lg" variant="outline" onClick={() => setDraft(reset)}>Azzera</Button></SheetFooter>
        </SheetContent>
      </Sheet>

      {/* Modulo bevanda */}
      <Sheet open={selId !== null} onOpenChange={(o) => { if (!o && !busy) setSelId(null) }}>
        <SheetContent side={narrow ? "bottom" : "right"} data-component="Sheet" data-state={selId === -1 ? "new" : "edit"}>
          <SheetHeader><SheetTitle>{selId === -1 ? "Nuova bevanda" : "Modifica bevanda"}</SheetTitle><SheetDescription>{selId === -1 ? "La bevanda compare nel menù pubblico dopo la ricompilazione." : form.name}</SheetDescription></SheetHeader>
          <FieldGroup className="px-4" data-block="modulo-bevanda">
            {opError && <Alert variant="destructive" role="alert" data-component="Alert"><CircleAlert /><AlertTitle>Operazione non riuscita</AlertTitle><AlertDescription>{SERR}</AlertDescription></Alert>}
            <FieldSet data-block="dati">
              <FieldLegend variant="label">Dati</FieldLegend>
              <Field data-invalid={fe("name") ? true : undefined}><FieldLabel htmlFor="v-nome">Nome</FieldLabel><Input id="v-nome" value={form.name} aria-invalid={fe("name") ? true : undefined} onChange={(e) => setF("name", e.target.value)} />{fe("name") && <FieldError>{fe("name")}</FieldError>}</Field>
              <div className="grid grid-cols-2 gap-3">
                <Field><FieldLabel htmlFor="v-cap">Capacità</FieldLabel><SelectField id="v-cap" list={CAPACITA} value={form.volume} onChange={(v) => setF("volume", v)} placeholder="Scegli" clearLabel="Non indicata" /></Field>
                <Field><FieldLabel htmlFor="v-grado">Grado</FieldLabel><SelectField id="v-grado" list={GRADI} value={form.abv} onChange={(v) => setF("abv", v)} placeholder="Scegli" clearLabel="Non indicato" /></Field>
              </div>
              <FieldDescription>Capacità e grado si scelgono da un elenco, così i dati restano uniformi. Il grado è vuoto per le analcoliche.{(form.volume && !CAPACITA.includes(form.volume)) || (form.abv && !GRADI.includes(form.abv)) ? " Un valore non in elenco resta finché non lo cambi." : ""}</FieldDescription>
              <Field><FieldLabel htmlFor="v-desc">Descrizione</FieldLabel><Textarea id="v-desc" data-component="Textarea" value={form.descIt} onChange={(e) => setF("descIt", e.target.value)} /></Field>
              <Collapsible open={enOpen} onOpenChange={setEnOpen} className="rounded-lg border" data-block="traduzione-inglese">
                <CollapsibleTrigger render={<button type="button" className="flex min-h-11 w-full items-center gap-2 px-3 text-left text-sm font-medium" />}>
                  Traduzione inglese <span className="font-normal text-muted-foreground">(facoltativa)</span>
                  <Badge data-component="Badge" variant="outline" className="ml-auto">{form.descEn || form.nameEn ? "Presente" : "Manca"}</Badge><ChevronDown className={`size-4 transition-transform ${enOpen ? "rotate-180" : ""}`} />
                </CollapsibleTrigger>
                <CollapsibleContent><div className="flex flex-col gap-4 border-t p-3">
                  <Field><FieldLabel htmlFor="v-nome-en">Name</FieldLabel><Input id="v-nome-en" placeholder={form.name} value={form.nameEn} onChange={(e) => setF("nameEn", e.target.value)} /></Field>
                  <Field><FieldLabel htmlFor="v-desc-en">Description</FieldLabel><Textarea id="v-desc-en" value={form.descEn} onChange={(e) => setF("descEn", e.target.value)} /><FieldDescription>Facoltativa. Se resta vuota, il menù mostra il testo italiano.</FieldDescription></Field>
                </div></CollapsibleContent>
              </Collapsible>
            </FieldSet>
            <FieldSet data-block="origine">
              <FieldLegend variant="label">Tipologia e paese</FieldLegend>
              <Field data-invalid={fe("type") ? true : undefined}><FieldLabel htmlFor="v-tipo">Tipologia</FieldLabel><SelectField id="v-tipo" list={TIPI} value={form.type} onChange={(v) => setF("type", v)} placeholder="Scegli" invalid={!!fe("type")} />{fe("type") && <FieldError>{fe("type")}</FieldError>}</Field>
              <Field><FieldLabel htmlFor="v-paese">Paese</FieldLabel><SelectField id="v-paese" list={PAESI} value={form.country} onChange={(v) => setF("country", v)} placeholder="Facoltativo" clearLabel="Nessun paese" /></Field>
            </FieldSet>
            <FieldSet data-block="prezzi">
              <FieldLegend variant="label">Prezzo</FieldLegend>
              <Field data-invalid={fe("price") ? true : undefined}><FieldLabel htmlFor="v-prezzo">Prezzo (€)</FieldLabel><Input id="v-prezzo" inputMode="decimal" value={form.price} aria-invalid={fe("price") ? true : undefined} onChange={(e) => setF("price", e.target.value)} />{fe("price") && <FieldError>{fe("price")}</FieldError>}</Field>
            </FieldSet>
            <FieldSet data-block="disponibilita">
              <FieldLegend variant="label">Disponibilità</FieldLegend>
              <Field orientation="horizontal"><div className="flex-1"><FieldLabel htmlFor="v-dis" className="min-h-11 items-center">Disabilitata</FieldLabel><FieldDescription>Assente a tempo indefinito: la bevanda non compare nel menù.</FieldDescription></div><Switch id="v-dis" data-component="Switch" checked={form.disabled} onCheckedChange={(c) => setF("disabled", c === true)} /></Field>
            </FieldSet>
          </FieldGroup>
          <SheetFooter className="grid grid-cols-2"><Button size="lg" onClick={save} disabled={busy}>{busy && <Spinner data-icon="inline-start" />}{busy ? "Salvataggio…" : "Salva"}</Button><Button size="lg" variant="outline" disabled={busy} onClick={() => setSelId(null)}>Annulla</Button></SheetFooter>
        </SheetContent>
      </Sheet>

      {/* Elimina */}
      <AlertDialog open={delTarget !== null} onOpenChange={(o) => { if (!o && !delBusy) setDelTarget(null) }}>
        <AlertDialogContent data-component="AlertDialog" data-state="elimina">
          <AlertDialogHeader><AlertDialogTitle>Eliminare {delTarget?.name}?</AlertDialogTitle><AlertDialogDescription>Non si può annullare.</AlertDialogDescription></AlertDialogHeader>
          <AlertDialogFooter><AlertDialogCancel disabled={delBusy}>Indietro</AlertDialogCancel><Button variant="destructive" data-component="Button" onClick={doDelete} disabled={delBusy}>{delBusy && <Spinner data-icon="inline-start" />}Elimina</Button></AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

      {/* Ricompila (componente condiviso con Piatti) */}
      <AlertDialog open={rebuildOpen} onOpenChange={(o) => !o && !rebuildBusy && setRebuildOpen(false)}>
        <AlertDialogContent data-component="AlertDialog" data-state="ricompila">
          <AlertDialogHeader><AlertDialogTitle>Ricompilare il menù pubblico?</AlertDialogTitle>
            <AlertDialogDescription>La pubblicazione richiede alcuni minuti. Serve per vedere piatti nuovi e modifiche ai contenuti, ai servizi, agli orari, alle chiusure e ai giorni speciali. «Terminato» e «disabilitato» valgono già.</AlertDialogDescription></AlertDialogHeader>
          <AlertDialogFooter><AlertDialogCancel disabled={rebuildBusy}>Indietro</AlertDialogCancel><Button data-component="Button" onClick={rebuild} disabled={rebuildBusy}>{rebuildBusy && <Spinner data-icon="inline-start" />}Ricompila</Button></AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

      <div data-demo className="fixed bottom-2 right-2 z-50 rounded-md border bg-card px-1.5 py-0.5 text-[11px] text-muted-foreground shadow-xs">
        <label>Demo stato <select aria-label="Stato demo" className="bg-transparent text-foreground" defaultValue="normale" onChange={(e) => demo(e.target.value)}>
          <option value="normale">normale</option><option value="caricamento">caricamento</option><option value="errore-caricamento">errore di caricamento</option><option value="vuoto">nessuna bevanda</option>
          <option value="molte-bevande">più di 100 bevande</option><option value="errore-azione">errore all’azione successiva</option>
        </select></label>
      </div>
    </Shell>
  )
}
export const bevandePage = <BevandePage />
