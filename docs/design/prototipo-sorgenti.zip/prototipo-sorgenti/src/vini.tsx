import * as React from "react"
import { Pencil, Trash2, Plus, Search, SlidersHorizontal, X, CircleCheck, CircleAlert, ChevronDown, RefreshCw, Info } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { Switch } from "@/components/ui/switch"
import { Checkbox } from "@/components/ui/checkbox"
import { Badge } from "@/components/ui/badge"
import { Card, CardContent } from "@/components/ui/card"
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert"
import { Skeleton } from "@/components/ui/skeleton"
import { Spinner } from "@/components/ui/spinner"
import { Field, FieldDescription, FieldError, FieldGroup, FieldLabel, FieldLegend, FieldSet } from "@/components/ui/field"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Sheet, SheetContent, SheetDescription, SheetFooter, SheetHeader, SheetTitle } from "@/components/ui/sheet"
import { AlertDialog, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle } from "@/components/ui/alert-dialog"
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from "@/components/ui/collapsible"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Breadcrumb, BreadcrumbItem, BreadcrumbList, BreadcrumbPage, BreadcrumbSeparator, BreadcrumbLink } from "@/components/ui/breadcrumb"
import { SidebarGroup, SidebarGroupContent, SidebarGroupLabel, SidebarMenu, SidebarMenuButton, SidebarMenuItem } from "@/components/ui/sidebar"
import { useIsMobile } from "@/hooks/use-mobile"
import { Shell } from "./layouts"
import { UtensilsCrossed, Wine, CupSoda, Martini, BookOpen, ConciergeBell, CalendarHeart, Megaphone, Clock, CalendarDays, Settings } from "lucide-react"

/* ---------- navigazione a otto voci (D1) ---------- */
const GRUPPI: { label: string; voci: { label: string; icon: React.ComponentType<any> }[] }[] = [
  { label: "Menù", voci: [{ label: "Piatti", icon: UtensilsCrossed }, { label: "Vini", icon: Wine }, { label: "Bevande", icon: CupSoda }, { label: "Distillati", icon: Martini }, { label: "Menù fissi", icon: BookOpen }, { label: "Servizi", icon: ConciergeBell }, { label: "Giorni speciali", icon: CalendarHeart }, { label: "Messaggio globale", icon: Megaphone }] },
  { label: "Orari", voci: [{ label: "Orari", icon: Clock }] },
  { label: "Prenotazioni", voci: [{ label: "Elenco", icon: CalendarDays }, { label: "Eccezioni giorno", icon: CalendarDays }, { label: "Impostazioni", icon: Settings }] },
]
function MenuOtto({ active }: { active: string }) {
  return (
    <>
      {GRUPPI.map((g) => (
        <SidebarGroup key={g.label}>
          <SidebarGroupLabel>{g.label}</SidebarGroupLabel>
          <SidebarGroupContent>
            <SidebarMenu>
              {g.voci.map((v) => (
                <SidebarMenuItem key={v.label}>
                  <SidebarMenuButton render={<a href="#" />} isActive={g.label === "Menù" && v.label === active} tooltip={v.label}><v.icon /><span>{v.label}</span></SidebarMenuButton>
                </SidebarMenuItem>
              ))}
            </SidebarMenu>
          </SidebarGroupContent>
        </SidebarGroup>
      ))}
    </>
  )
}

/* ---------- dati di esempio (nel progetto: collection wines e tassonomie) ---------- */
// Paesi abilitati (12 del seed, Libano no) e relazioni: nella schermata vera sono interrogazioni filtrate (enabled, paese, regione).
const PAESI = ["Filippine", "Francia", "Giappone", "Guatemala", "Guyana", "Italia", "Martinica", "Scozia", "Thailandia", "Trinidad e Tobago", "Venezuela", "Vietnam"]
const REGIONI: Record<string, string[]> = {
  Italia: ["Campania", "Friuli Venezia Giulia", "Lombardia", "Marche", "Piemonte", "Puglia", "Sardegna", "Toscana", "Trentino Alto Adige", "Umbria", "Veneto"],
  Francia: ["Alsazia", "Borgogna", "Loira", "Rodano"],
}
const DENOM: Record<string, string[]> = { "Friuli Venezia Giulia": ["Carso", "Collio"], Lombardia: ["Franciacorta"] }
const CLASS: Record<string, string[]> = { Italia: ["D.O.C.G.", "D.O.C.", "I.G.T.", "D.O.P."], Francia: ["A.O.C.", "A.O.P."] }
const TIPI = ["Bianchi", "Champagne", "Rosati", "Rossi", "Spumanti"] // ordine per nome (ADR-112)
type Vino = { id: number; name: string; descIt: string; descEn: string; winery: string; year: string; volume: string; abv: string; price: string; glass: string; cls: string; country: string; region: string; app: string; type: string; disabled: boolean }
const W = (id: number, name: string, winery: string, type: string, country: string, region: string, app: string, cls: string, year: string, price: string, glass = "", extra: Partial<Vino> = {}): Vino => ({ id, name, descIt: "", descEn: "", winery, year, volume: "75 cl", abv: "13%", price, glass, cls, country, region, app, type, disabled: false, ...extra })
const initialData: Vino[] = [
  W(1, "Friulano", "Tenuta Verde", "Bianchi", "Italia", "Friuli Venezia Giulia", "Collio", "D.O.C.", "2022", "28,00", "7,00", { descIt: "Fresco, con note di mandorla.", descEn: "Fresh, with notes of almond." }),
  W(2, "Vitovska", "Cantina del Colle", "Bianchi", "Italia", "Friuli Venezia Giulia", "Carso", "D.O.C.", "2021", "32,00"),
  W(3, "Vermentino", "Tenuta Verde", "Bianchi", "Italia", "Sardegna", "", "", "2023", "24,00", "6,00"),
  W(4, "Chablis", "Domaine Lumière", "Bianchi", "Francia", "Borgogna", "", "A.O.C.", "2022", "48,00"),
  W(5, "Brut", "Cantina del Colle", "Spumanti", "Italia", "Lombardia", "Franciacorta", "D.O.C.G.", "2020", "38,00", "9,00"),
  W(6, "Satèn", "Cantina del Colle", "Spumanti", "Italia", "Lombardia", "Franciacorta", "D.O.C.G.", "2019", "44,00"),
  W(7, "Brut Réserve", "Domaine Lumière", "Champagne", "Francia", "", "", "A.O.C.", "NV", "70,00", "14,00"),
  W(8, "Barolo", "Tenuta Verde", "Rossi", "Italia", "Piemonte", "", "D.O.C.G.", "2018", "65,00"),
  W(9, "Bourgogne Rouge", "Domaine Lumière", "Rossi", "Francia", "Borgogna", "", "A.O.C.", "2021", "45,00", "", { disabled: true }),
  W(10, "Chianti", "Tenuta Verde", "Rossi", "Italia", "Toscana", "", "D.O.C.G.", "2021", "30,00", "7,50", { abv: "12,8%" }),
  W(11, "Rosato del Salento", "Cantina del Colle", "Rosati", "Italia", "Puglia", "", "I.G.T.", "2023", "22,00"),
]
// Campi a scelta (decisione del 2026-10-14): capacità e grado sono select con valori uniformi; l'anno è numerico validato (1900 – anno corrente) con «Senza annata (NV)».
const CAPACITA = ["25 cl", "33 cl", "37,5 cl", "50 cl", "75 cl", "150 cl"]
const GRADI = Array.from({ length: 31 }, (_, i) => { const v = 5 + i * 0.5; return Number.isInteger(v) ? `${v}%` : `${String(v).replace(".", ",")}%` })
const ANNO_CORRENTE = 2026
const annoValido = (y: string) => /^\d{4}$/.test(y) && Number(y) >= 1900 && Number(y) <= ANNO_CORRENTE
const pl = (n: number, one: string, many: string) => (n === 1 ? `1 ${one}` : `${n} ${many}`)
const euro = (p: string) => `${p} €`
const items = (a: string[]) => a.map((v) => ({ value: v, label: v }))
const tipoItems = [{ value: "tutte", label: "Tutte le tipologie" }, ...items(TIPI)]
const paeseItems = [{ value: "tutti", label: "Tutti i paesi" }, ...items(PAESI)]
const statoItems = [{ value: "tutti", label: "Tutti" }, { value: "abilitati", label: "Abilitati" }, { value: "disabilitati", label: "Disabilitati" }]
const SERR = "Non è stato modificato nulla. Controlla la connessione e riprova; se il problema continua, avvisa l’amministratore."
const PRICE_RE = /^\d+([.,]\d{1,2})?$/
type Form = Omit<Vino, "id">
const emptyForm = (): Form => ({ name: "", descIt: "", descEn: "", winery: "", year: "", volume: "", abv: "", price: "", glass: "", cls: "", country: "", region: "", app: "", type: "", disabled: false })
let nextId = 100

const NONE = "__nessuno"
// Select con valori da elenco. `clearLabel`: prima voce che svuota il campo (solo per i campi facoltativi); un valore salvato fuori elenco resta tra le opzioni.
function SelectField({ id, list, value, onChange, placeholder, disabled, invalid, clearLabel }: { id?: string; list: string[]; value: string; onChange: (v: string) => void; placeholder?: string; disabled?: boolean; invalid?: boolean; clearLabel?: string }) {
  const all = value && !list.includes(value) ? [value, ...list] : list
  const opts = [...(clearLabel ? [{ value: NONE, label: clearLabel }] : []), ...items(all)]
  return (
    <Select items={opts} value={value || null} disabled={disabled} onValueChange={(v) => onChange(v === NONE ? "" : ((v as string) ?? ""))}>
      <SelectTrigger id={id} data-component="Select" className="w-full" aria-invalid={invalid ? true : undefined}><SelectValue placeholder={placeholder} /></SelectTrigger>
      <SelectContent>{opts.map((o) => <SelectItem key={o.value} value={o.value}>{o.label}</SelectItem>)}</SelectContent>
    </Select>
  )
}

function ViniPage() {
  const narrow = useIsMobile()
  const [data, setData] = React.useState<Vino[]>(initialData)
  const [q, setQ] = React.useState("")
  const [filters, setFilters] = React.useState({ tipo: "tutte", paese: "tutti", regione: "tutte", denom: "tutte", stato: "tutti" })
  const [draft, setDraft] = React.useState(filters)
  const [filterOpen, setFilterOpen] = React.useState(false)
  const [selId, setSelId] = React.useState<number | null>(null)
  const [form, setForm] = React.useState<Form>(emptyForm())
  const [showErr, setShowErr] = React.useState(false)
  const [enOpen, setEnOpen] = React.useState(false)
  const [busy, setBusy] = React.useState(false)
  const [opError, setOpError] = React.useState<string | null>(null)
  const [geoErr, setGeoErr] = React.useState(false)
  const [geoShown, setGeoShown] = React.useState(false)
  const [notice, setNotice] = React.useState<{ kind: "ok" | "err" | "info"; title: string; text?: string } | null>(null)
  const [loadState, setLoadState] = React.useState<"ok" | "loading" | "error" | "empty">("ok")
  const [failNext, setFailNext] = React.useState(false)
  const [truncated, setTruncated] = React.useState(false)
  const [delTarget, setDelTarget] = React.useState<Vino | null>(null)
  const [delBusy, setDelBusy] = React.useState(false)
  const [rebuildOpen, setRebuildOpen] = React.useState(false)
  const [rebuildBusy, setRebuildBusy] = React.useState(false)

  const term = q.trim().toLowerCase()
  const list = data.filter((v) =>
    (filters.tipo === "tutte" || v.type === filters.tipo) && (filters.paese === "tutti" || v.country === filters.paese) && (filters.regione === "tutte" || v.region === filters.regione) && (filters.denom === "tutte" || v.app === filters.denom) &&
    (filters.stato === "tutti" || (filters.stato === "abilitati") === !v.disabled) && (!term || `${v.name} ${v.winery}`.toLowerCase().includes(term)))
  const chips: { k: string; label: string }[] = []
  if (filters.tipo !== "tutte") chips.push({ k: "tipo", label: filters.tipo })
  if (filters.paese !== "tutti") chips.push({ k: "paese", label: filters.paese })
  if (filters.regione !== "tutte") chips.push({ k: "regione", label: filters.regione })
  if (filters.denom !== "tutte") chips.push({ k: "denom", label: filters.denom })
  if (filters.stato !== "tutti") chips.push({ k: "stato", label: statoItems.find((s) => s.value === filters.stato)!.label })
  const reset = { tipo: "tutte", paese: "tutti", regione: "tutte", denom: "tutte", stato: "tutti" }
  // togliere un livello dell'origine toglie anche quelli sotto
  const clearChip = (k: string) => setFilters((f) => ({ ...f, ...(k === "paese" ? { paese: "tutti", regione: "tutte", denom: "tutte" } : k === "regione" ? { regione: "tutte", denom: "tutte" } : { [k]: (reset as any)[k] }) }))
  const patch = (id: number, p: Partial<Vino>) => setData((x) => x.map((v) => (v.id === id ? { ...v, ...p } : v)))

  async function toggle(v: Vino) {
    setNotice(null); await new Promise((r) => setTimeout(r, 250))
    if (failNext) { setFailNext(false); setNotice({ kind: "err", title: "Operazione non riuscita", text: SERR }); return }
    patch(v.id, { disabled: !v.disabled }); setNotice({ kind: "ok", title: v.disabled ? "Vino abilitato" : "Vino disabilitato", text: "Il menù pubblico si aggiorna entro pochi minuti." })
  }
  function openEdit(v: Vino) { const { id, ...rest } = v; setForm(rest); setEnOpen(!!v.descEn); setShowErr(false); setOpError(null); setGeoShown(false); setSelId(id) }
  function openNew() { setForm(emptyForm()); setEnOpen(false); setShowErr(false); setOpError(null); setGeoShown(false); setSelId(-1) }
  const errs = {
    name: form.name.trim() ? null : "Campo obbligatorio.",
    type: form.type ? null : "Scegli una tipologia.",
    country: form.country ? null : "Scegli un paese.",
    price: !form.price.trim() ? "Campo obbligatorio." : PRICE_RE.test(form.price.trim()) ? null : "Inserisci un prezzo valido (es. 28,50).",
    glass: !form.glass.trim() || PRICE_RE.test(form.glass.trim()) ? null : "Inserisci un prezzo valido (es. 7,00).",
    year: !form.year || form.year === "NV" || annoValido(form.year) ? null : `Inserisci un anno di quattro cifre tra 1900 e ${ANNO_CORRENTE}.`,
  }
  const hasErr = Object.values(errs).some(Boolean)
  const fe = (k: keyof typeof errs) => (showErr ? errs[k] : null)
  const setF = <K extends keyof Form>(k: K, v: Form[K]) => setForm((f) => ({ ...f, [k]: v }))
  // cambiando il livello alto si svuotano i sottostanti (regione, denominazione); la classificazione si svuota se non è del nuovo paese
  const setCountry = (c: string) => setForm((f) => ({ ...f, country: c, region: "", app: "", cls: (CLASS[c] ?? []).includes(f.cls) ? f.cls : "" }))
  const setRegion = (r: string) => setForm((f) => ({ ...f, region: r, app: "" }))
  async function save() {
    if (hasErr) { setShowErr(true); requestAnimationFrame(() => document.querySelector<HTMLElement>('[data-slot="sheet-content"] [aria-invalid="true"]')?.focus()); return }
    setBusy(true); setOpError(null); setGeoShown(false); await new Promise((r) => setTimeout(r, 700)); setBusy(false)
    if (geoErr) { setGeoErr(false); setGeoShown(true); requestAnimationFrame(() => document.querySelector<HTMLElement>('[data-slot="sheet-content"] [aria-invalid="true"]')?.focus()); return }
    if (failNext) { setFailNext(false); setOpError("Operazione non riuscita. " + SERR); return }
    const isNew = selId === -1
    if (isNew) setData((x) => [...x, { id: nextId++, ...form, name: form.name.trim() }]); else patch(selId!, { ...form, name: form.name.trim() })
    setSelId(null); setNotice({ kind: "ok", title: isNew ? "Vino aggiunto" : "Vino salvato", text: "Per vederlo sul menù pubblico serve «Ricompila il menù pubblico»." })
  }
  async function doDelete() {
    if (!delTarget) return
    setDelBusy(true); await new Promise((r) => setTimeout(r, 600)); setDelBusy(false)
    const id = delTarget.id; setData((x) => x.filter((v) => v.id !== id)); setDelTarget(null)
    setNotice({ kind: "ok", title: "Vino eliminato", text: "Per toglierlo dal menù pubblico serve «Ricompila il menù pubblico»." })
  }
  async function rebuild() { setRebuildBusy(true); await new Promise((r) => setTimeout(r, 800)); setRebuildBusy(false); setRebuildOpen(false); setNotice({ kind: "ok", title: "Ricompilazione avviata", text: "Il menù pubblico si aggiorna tra alcuni minuti." }) }
  function demo(v: string) {
    setNotice(null); setLoadState("ok"); setFailNext(false); setTruncated(false); setGeoErr(false)
    if (v === "caricamento") setLoadState("loading"); if (v === "errore-caricamento") setLoadState("error"); if (v === "vuoto") setLoadState("empty")
    if (v === "molti-vini") setTruncated(true); if (v === "errore-azione") setFailNext(true); if (v === "errore-geografia") setGeoErr(true)
  }

  const Actions = ({ v }: { v: Vino }) => (
    <div className="flex items-center">
      <Button variant="ghost" size="icon" aria-label={`Modifica ${v.name}`} data-component="Button" onClick={() => openEdit(v)}><Pencil /></Button>
      <Button variant="ghost" size="icon" aria-label={`Elimina ${v.name}`} data-component="Button" onClick={() => setDelTarget(v)}><Trash2 /></Button>
    </div>
  )
  const Avail = ({ v }: { v: Vino }) => <Switch data-component="Switch" aria-label={`Disponibile: ${v.name}`} checked={!v.disabled} onCheckedChange={() => toggle(v)} />
  const sub = (v: Vino) => [v.winery, v.year].filter(Boolean).join(" · ")
  const Group = ({ tipo }: { tipo: string }) => {
    const rows = list.filter((v) => v.type === tipo).sort((a, b) => a.name.localeCompare(b.name, "it", { sensitivity: "base" })); if (!rows.length) return null
    return (
      <section data-block={`gruppo-${tipo.toLowerCase()}`} className="flex flex-col gap-2">
        <h2 className="flex items-baseline gap-2 text-base font-semibold">{tipo} <span className="text-sm font-normal text-muted-foreground">{pl(rows.length, "vino", "vini")}</span></h2>
        <div className="hidden rounded-lg border md:block" data-block="elenco-tabella">
          <Table data-component="Table" className="table-fixed">
            <TableHeader><TableRow><TableHead>Nome</TableHead><TableHead className="w-56">Origine</TableHead><TableHead className="w-28">Prezzo</TableHead><TableHead className="w-28">Disponibile</TableHead><TableHead className="w-24"><span className="sr-only">Azioni</span></TableHead></TableRow></TableHeader>
            <TableBody>
              {rows.map((v) => (
                <TableRow key={v.id} className={v.disabled ? "text-muted-foreground" : ""}>
                  <TableCell><div className="flex items-center gap-2"><span className="truncate text-sm font-medium">{v.name}</span>{v.disabled && <Badge data-component="Badge" variant="outline">Disabilitato</Badge>}</div><div className="truncate text-xs text-muted-foreground">{sub(v)}</div></TableCell>
                  <TableCell className="text-sm">{[v.country, v.region].filter(Boolean).join(" · ")}</TableCell>
                  <TableCell className="tabular-nums">{euro(v.price)}{v.glass && <div className="text-xs text-muted-foreground">calice {euro(v.glass)}</div>}</TableCell>
                  <TableCell><Avail v={v} /></TableCell>
                  <TableCell className="text-right"><Actions v={v} /></TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </div>
        <div className="flex flex-col gap-2 md:hidden" data-block="elenco-schede">
          {rows.map((v) => (
            <Card key={v.id} size="sm" data-component="Card" className={v.disabled ? "text-muted-foreground" : ""}>
              <CardContent className="flex items-center gap-2">
                <div className="min-w-0 flex-1 py-1">
                  <div className="truncate text-sm font-medium">{v.name}</div>
                  <div className="truncate text-xs text-muted-foreground">{sub(v)}</div>
                  <div className="mt-0.5 flex items-center gap-2 text-xs text-muted-foreground"><span className="tabular-nums">{euro(v.price)}{v.glass && ` · calice ${euro(v.glass)}`}</span>{v.disabled && <Badge data-component="Badge" variant="outline">Disabilitato</Badge>}</div>
                </div>
                <label className="flex flex-col items-center gap-1 text-[11px] text-muted-foreground"><Avail v={v} />Disponibile</label>
                <Actions v={v} />
              </CardContent>
            </Card>
          ))}
        </div>
      </section>
    )
  }
  const Skel = () => <div className="flex flex-col gap-2" aria-busy="true" data-block="caricamento">{[0, 1, 2, 3].map((i) => <Skeleton key={i} className="h-16 w-full rounded-xl" />)}</div>
  const regionList = REGIONI[form.country] ?? []
  const denomList = DENOM[form.region] ?? []
  const classList = CLASS[form.country] ?? []

  return (
    <Shell themeSwitch adminInUserMenu menu={<MenuOtto active="Vini" />}
      topbar={<Breadcrumb><BreadcrumbList><BreadcrumbItem><BreadcrumbLink href="#">Menù</BreadcrumbLink></BreadcrumbItem><BreadcrumbSeparator /><BreadcrumbItem><BreadcrumbPage>Vini</BreadcrumbPage></BreadcrumbItem></BreadcrumbList></Breadcrumb>}>
      <div className="mx-auto flex w-full max-w-5xl flex-col gap-5" data-block="contenitore-elenco">
        <div className="flex flex-col gap-3 sm:flex-row sm:items-start sm:justify-between" data-block="intestazione-pagina">
          <div><h1 className="text-xl font-semibold tracking-tight">Vini</h1><p className="text-sm text-muted-foreground">La carta dei vini del ristorante.</p></div>
          <div className="flex flex-col-reverse gap-2 sm:flex-row">
            <Button variant="outline" size="lg" data-component="Button" onClick={() => setRebuildOpen(true)}><RefreshCw data-icon="inline-start" /> Ricompila il menù pubblico</Button>
            <Button size="lg" data-component="Button" onClick={openNew}><Plus data-icon="inline-start" /> Nuovo vino</Button>
          </div>
        </div>

        {notice && <Alert role="status" data-component="Alert" variant={notice.kind === "err" ? "destructive" : "default"}>{notice.kind === "err" ? <CircleAlert /> : <CircleCheck />}<AlertTitle>{notice.title}</AlertTitle>{notice.text && <AlertDescription>{notice.text}</AlertDescription>}</Alert>}

        <div className="flex gap-2" data-block="ricerca-filtri">
          <div className="relative min-w-0 flex-1"><Search className="pointer-events-none absolute top-1/2 left-3 size-4 -translate-y-1/2 text-muted-foreground" /><Input data-component="Input" aria-label="Cerca" placeholder="Cerca un vino o una cantina" className="pl-9" value={q} onChange={(e) => setQ(e.target.value)} /></div>
          <Button variant="outline" data-component="Button" onClick={() => { setDraft(filters); setFilterOpen(true) }}><SlidersHorizontal data-icon="inline-start" /> Filtri{chips.length > 0 && <Badge data-component="Badge" className="ml-1">{chips.length}</Badge>}</Button>
        </div>
        {chips.length > 0 && <div className="flex flex-wrap gap-2" data-block="filtri-attivi">{chips.map((c) => <Button key={c.k} variant="secondary" size="sm" data-component="Button" aria-label={`Rimuovi filtro ${c.label}`} onClick={() => clearChip(c.k)}>{c.label}<X data-icon="inline-end" /></Button>)}</div>}

        {loadState === "loading" && <Skel />}
        {loadState === "error" && <Alert variant="destructive" role="alert" data-component="Alert"><CircleAlert /><AlertTitle>Impossibile caricare i vini</AlertTitle><AlertDescription><p>Riprova tra qualche istante; se il problema continua, avvisa l’amministratore.</p><Button variant="outline" className="mt-3" data-component="Button" onClick={() => setLoadState("ok")}>Riprova</Button></AlertDescription></Alert>}
        {loadState === "empty" && <div className="flex flex-col items-start gap-3 rounded-lg border border-dashed p-6" data-block="vuoto"><p className="text-sm text-muted-foreground">Nessun vino in carta.</p><Button variant="outline" data-component="Button" onClick={openNew}>Nuovo vino</Button></div>}
        {loadState === "ok" && truncated && <Alert role="status" data-component="Alert" data-state="elenco-parziale"><Info /><AlertTitle>Mostrati 100 vini su 137</AlertTitle><AlertDescription><p>Restringi l’elenco con la ricerca o i filtri, oppure mostra gli altri.</p><Button variant="outline" className="mt-3" data-component="Button" onClick={() => setTruncated(false)}>Mostra altri vini</Button></AlertDescription></Alert>}
        {loadState === "ok" && (list.length === 0
          ? <div className="flex flex-col items-start gap-3 rounded-lg border border-dashed p-6" data-block="nessun-risultato"><p className="text-sm text-muted-foreground">Nessun risultato con questi filtri.</p><Button variant="outline" data-component="Button" onClick={() => { setFilters(reset); setQ("") }}>Azzera filtri</Button></div>
          : <div className="flex flex-col gap-6">{TIPI.map((t) => <Group key={t} tipo={t} />)}</div>)}
      </div>

      {/* Filtri */}
      <Sheet open={filterOpen} onOpenChange={setFilterOpen}>
        <SheetContent side={narrow ? "bottom" : "right"} data-component="Sheet">
          <SheetHeader><SheetTitle>Filtri</SheetTitle><SheetDescription>Restringi l’elenco dei vini.</SheetDescription></SheetHeader>
          <FieldGroup className="px-4">
            <Field><FieldLabel htmlFor="f-tipo">Tipologia</FieldLabel><Select items={tipoItems} value={draft.tipo} onValueChange={(v) => setDraft({ ...draft, tipo: v as string })}><SelectTrigger id="f-tipo" data-component="Select" className="w-full"><SelectValue /></SelectTrigger><SelectContent>{tipoItems.map((s) => <SelectItem key={s.value} value={s.value}>{s.label}</SelectItem>)}</SelectContent></Select></Field>
            <Field><FieldLabel htmlFor="f-paese">Paese</FieldLabel><Select items={paeseItems} value={draft.paese} onValueChange={(v) => setDraft({ ...draft, paese: v as string, regione: "tutte", denom: "tutte" })}><SelectTrigger id="f-paese" data-component="Select" className="w-full"><SelectValue /></SelectTrigger><SelectContent>{paeseItems.map((s) => <SelectItem key={s.value} value={s.value}>{s.label}</SelectItem>)}</SelectContent></Select></Field>
            <Field><FieldLabel htmlFor="f-regione">Regione</FieldLabel><Select items={[{ value: "tutte", label: "Tutte le regioni" }, ...items(REGIONI[draft.paese] ?? [])]} value={draft.regione === "tutte" ? null : draft.regione} disabled={draft.paese === "tutti" || !(REGIONI[draft.paese] ?? []).length} onValueChange={(v) => setDraft({ ...draft, regione: v as string, denom: "tutte" })}><SelectTrigger id="f-regione" data-component="Select" className="w-full"><SelectValue placeholder={draft.paese === "tutti" ? "Scegli prima il paese" : (REGIONI[draft.paese] ?? []).length ? "Tutte le regioni" : "Nessuna regione per questo paese"} /></SelectTrigger><SelectContent>{[{ value: "tutte", label: "Tutte le regioni" }, ...items(REGIONI[draft.paese] ?? [])].map((s) => <SelectItem key={s.value} value={s.value}>{s.label}</SelectItem>)}</SelectContent></Select></Field>
            <Field><FieldLabel htmlFor="f-denom">Denominazione</FieldLabel><Select items={[{ value: "tutte", label: "Tutte le denominazioni" }, ...items(DENOM[draft.regione] ?? [])]} value={draft.denom === "tutte" ? null : draft.denom} disabled={draft.regione === "tutte" || !(DENOM[draft.regione] ?? []).length} onValueChange={(v) => setDraft({ ...draft, denom: v as string })}><SelectTrigger id="f-denom" data-component="Select" className="w-full"><SelectValue placeholder={draft.regione === "tutte" ? "Scegli prima la regione" : (DENOM[draft.regione] ?? []).length ? "Tutte le denominazioni" : "Nessuna denominazione per questa regione"} /></SelectTrigger><SelectContent>{[{ value: "tutte", label: "Tutte le denominazioni" }, ...items(DENOM[draft.regione] ?? [])].map((s) => <SelectItem key={s.value} value={s.value}>{s.label}</SelectItem>)}</SelectContent></Select></Field>
            <Field><FieldLabel htmlFor="f-stato">Stato</FieldLabel><Select items={statoItems} value={draft.stato} onValueChange={(v) => setDraft({ ...draft, stato: v as string })}><SelectTrigger id="f-stato" data-component="Select" className="w-full"><SelectValue /></SelectTrigger><SelectContent>{statoItems.map((s) => <SelectItem key={s.value} value={s.value}>{s.label}</SelectItem>)}</SelectContent></Select></Field>
          </FieldGroup>
          <SheetFooter className="grid grid-cols-2"><Button size="lg" onClick={() => { setFilters(draft); setFilterOpen(false) }}>Applica</Button><Button size="lg" variant="outline" onClick={() => setDraft(reset)}>Azzera</Button></SheetFooter>
        </SheetContent>
      </Sheet>

      {/* Modulo vino */}
      <Sheet open={selId !== null} onOpenChange={(o) => { if (!o && !busy) setSelId(null) }}>
        <SheetContent side={narrow ? "bottom" : "right"} data-component="Sheet" data-state={selId === -1 ? "new" : "edit"}>
          <SheetHeader><SheetTitle>{selId === -1 ? "Nuovo vino" : "Modifica vino"}</SheetTitle><SheetDescription>{selId === -1 ? "Il vino compare nel menù pubblico dopo la ricompilazione." : form.name}</SheetDescription></SheetHeader>
          <FieldGroup className="px-4" data-block="modulo-vino">
            {opError && <Alert variant="destructive" role="alert" data-component="Alert"><CircleAlert /><AlertTitle>Operazione non riuscita</AlertTitle><AlertDescription>{SERR}</AlertDescription></Alert>}
            <FieldSet data-block="dati">
              <FieldLegend variant="label">Dati</FieldLegend>
              <Field data-invalid={fe("name") ? true : undefined}><FieldLabel htmlFor="v-nome">Nome</FieldLabel><Input id="v-nome" value={form.name} aria-invalid={fe("name") ? true : undefined} onChange={(e) => setF("name", e.target.value)} />{fe("name") && <FieldError>{fe("name")}</FieldError>}</Field>
              <Field><FieldLabel htmlFor="v-cantina">Cantina</FieldLabel><Input id="v-cantina" value={form.winery} onChange={(e) => setF("winery", e.target.value)} /></Field>
              <Field data-invalid={fe("year") ? true : undefined}>
                <FieldLabel htmlFor="v-anno">Anno</FieldLabel>
                <Input id="v-anno" inputMode="numeric" maxLength={4} value={form.year === "NV" ? "" : form.year} disabled={form.year === "NV"} aria-invalid={fe("year") ? true : undefined} onChange={(e) => setF("year", e.target.value.replace(/\D/g, ""))} />
                {fe("year") && <FieldError>{fe("year")}</FieldError>}
                <Field orientation="horizontal"><Checkbox id="v-nv" data-component="Checkbox" checked={form.year === "NV"} onCheckedChange={(c) => setF("year", c === true ? "NV" : "")} /><FieldLabel htmlFor="v-nv" className="min-h-11 flex-1 items-center font-normal">Senza annata (NV)</FieldLabel></Field>
              </Field>
              <div className="grid grid-cols-2 gap-3">
                <Field><FieldLabel htmlFor="v-cap">Capacità</FieldLabel><SelectField id="v-cap" list={CAPACITA} value={form.volume} onChange={(v) => setF("volume", v)} placeholder="Scegli" clearLabel="Non indicata" /></Field>
                <Field><FieldLabel htmlFor="v-grado">Grado</FieldLabel><SelectField id="v-grado" list={GRADI} value={form.abv} onChange={(v) => setF("abv", v)} placeholder="Scegli" clearLabel="Non indicato" /></Field>
              </div>
              <FieldDescription>Capacità e grado si scelgono da un elenco, così i dati restano uniformi.{(form.volume && !CAPACITA.includes(form.volume)) || (form.abv && !GRADI.includes(form.abv)) ? " Un valore non in elenco resta finché non lo cambi." : ""}</FieldDescription>
              <Field><FieldLabel htmlFor="v-desc">Descrizione</FieldLabel><Textarea id="v-desc" data-component="Textarea" value={form.descIt} onChange={(e) => setF("descIt", e.target.value)} /></Field>
              <Collapsible open={enOpen} onOpenChange={setEnOpen} className="rounded-lg border" data-block="traduzione-inglese">
                <CollapsibleTrigger render={<button type="button" className="flex min-h-11 w-full items-center gap-2 px-3 text-left text-sm font-medium" />}>
                  Traduzione inglese <span className="font-normal text-muted-foreground">(facoltativa)</span>
                  <Badge data-component="Badge" variant="outline" className="ml-auto">{form.descEn ? "Presente" : "Manca"}</Badge><ChevronDown className={`size-4 transition-transform ${enOpen ? "rotate-180" : ""}`} />
                </CollapsibleTrigger>
                <CollapsibleContent><div className="flex flex-col gap-4 border-t p-3"><Field><FieldLabel htmlFor="v-desc-en">Description</FieldLabel><Textarea id="v-desc-en" value={form.descEn} onChange={(e) => setF("descEn", e.target.value)} /><FieldDescription>Facoltativa. Se resta vuota, il menù mostra il testo italiano. Il nome del vino non si traduce.</FieldDescription></Field></div></CollapsibleContent>
              </Collapsible>
            </FieldSet>
            <FieldSet data-block="origine">
              <FieldLegend variant="label">Origine</FieldLegend>
              <Field data-invalid={fe("type") ? true : undefined}><FieldLabel htmlFor="v-tipo">Tipologia</FieldLabel><SelectField id="v-tipo" list={TIPI} value={form.type} onChange={(v) => setF("type", v)} placeholder="Scegli" invalid={!!fe("type")} />{fe("type") && <FieldError>{fe("type")}</FieldError>}</Field>
              <Field data-invalid={fe("country") ? true : undefined}><FieldLabel htmlFor="v-paese">Paese</FieldLabel><SelectField id="v-paese" list={PAESI} value={form.country} onChange={setCountry} placeholder="Scegli" invalid={!!fe("country")} />{fe("country") && <FieldError>{fe("country")}</FieldError>}</Field>
              <Field data-invalid={geoShown ? true : undefined}><FieldLabel htmlFor="v-reg">Regione</FieldLabel><SelectField id="v-reg" list={regionList} value={form.region} onChange={setRegion} invalid={geoShown} clearLabel="Nessuna regione" placeholder={!form.country ? "Scegli prima il paese" : regionList.length ? "Facoltativa" : "Nessuna regione per questo paese"} disabled={!form.country || !regionList.length} />{geoShown && <FieldError>La regione selezionata non appartiene al paese indicato.</FieldError>}</Field>
              <Field><FieldLabel htmlFor="v-den">Denominazione</FieldLabel><SelectField id="v-den" list={denomList} value={form.app} onChange={(v) => setF("app", v)} clearLabel="Nessuna denominazione" placeholder={!form.region ? "Scegli prima la regione" : denomList.length ? "Facoltativa" : "Nessuna denominazione per questa regione"} disabled={!form.region || !denomList.length} /></Field>
              <Field><FieldLabel htmlFor="v-cls">Classificazione</FieldLabel><SelectField id="v-cls" list={classList} value={form.cls} onChange={(v) => setF("cls", v)} clearLabel="Nessuna classificazione" placeholder={!form.country ? "Scegli prima il paese" : classList.length ? "Facoltativa" : "Nessuna classificazione per questo paese"} disabled={!form.country || !classList.length} /><FieldDescription>Le classificazioni mostrate seguono il paese scelto.</FieldDescription></Field>
            </FieldSet>
            <FieldSet data-block="prezzi">
              <FieldLegend variant="label">Prezzi</FieldLegend>
              <div className="grid grid-cols-2 gap-3">
                <Field data-invalid={fe("price") ? true : undefined}><FieldLabel htmlFor="v-prezzo">Prezzo (€)</FieldLabel><Input id="v-prezzo" inputMode="decimal" value={form.price} aria-invalid={fe("price") ? true : undefined} onChange={(e) => setF("price", e.target.value)} />{fe("price") && <FieldError>{fe("price")}</FieldError>}</Field>
                <Field data-invalid={fe("glass") ? true : undefined}><FieldLabel htmlFor="v-calice">Al calice (€)</FieldLabel><Input id="v-calice" inputMode="decimal" value={form.glass} aria-invalid={fe("glass") ? true : undefined} onChange={(e) => setF("glass", e.target.value)} />{fe("glass") && <FieldError>{fe("glass")}</FieldError>}</Field>
              </div>
              <FieldDescription>Il prezzo al calice è facoltativo.</FieldDescription>
            </FieldSet>
            <FieldSet data-block="disponibilita">
              <FieldLegend variant="label">Disponibilità</FieldLegend>
              <Field orientation="horizontal"><div className="flex-1"><FieldLabel htmlFor="v-dis" className="min-h-11 items-center">Disabilitato</FieldLabel><FieldDescription>Assente a tempo indefinito: il vino non compare nel menù.</FieldDescription></div><Switch id="v-dis" data-component="Switch" checked={form.disabled} onCheckedChange={(c) => setF("disabled", c === true)} /></Field>
            </FieldSet>
          </FieldGroup>
          <SheetFooter className="grid grid-cols-2"><Button size="lg" onClick={save} disabled={busy}>{busy && <Spinner data-icon="inline-start" />}{busy ? "Salvataggio…" : "Salva"}</Button><Button size="lg" variant="outline" disabled={busy} onClick={() => setSelId(null)}>Annulla</Button></SheetFooter>
        </SheetContent>
      </Sheet>

      {/* Elimina */}
      <AlertDialog open={delTarget !== null} onOpenChange={(o) => { if (!o && !delBusy) setDelTarget(null) }}>
        <AlertDialogContent data-component="AlertDialog" data-state="elimina">
          <AlertDialogHeader><AlertDialogTitle>Eliminare {delTarget?.name}?</AlertDialogTitle><AlertDialogDescription>Non si può annullare.</AlertDialogDescription></AlertDialogHeader>
          <AlertDialogFooter><AlertDialogCancel disabled={delBusy}>Indietro</AlertDialogCancel><Button variant="destructive" data-component="Button" onClick={doDelete} disabled={delBusy}>{delBusy && <Spinner data-icon="inline-start" />}Elimina</Button></AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

      {/* Ricompila (componente condiviso con Piatti) */}
      <AlertDialog open={rebuildOpen} onOpenChange={(o) => !o && !rebuildBusy && setRebuildOpen(false)}>
        <AlertDialogContent data-component="AlertDialog" data-state="ricompila">
          <AlertDialogHeader><AlertDialogTitle>Ricompilare il menù pubblico?</AlertDialogTitle>
            <AlertDialogDescription>La pubblicazione richiede alcuni minuti. Serve per vedere piatti nuovi e modifiche ai contenuti, ai servizi, agli orari, alle chiusure e ai giorni speciali. «Terminato» e «disabilitato» valgono già.</AlertDialogDescription></AlertDialogHeader>
          <AlertDialogFooter><AlertDialogCancel disabled={rebuildBusy}>Indietro</AlertDialogCancel><Button data-component="Button" onClick={rebuild} disabled={rebuildBusy}>{rebuildBusy && <Spinner data-icon="inline-start" />}Ricompila</Button></AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

      <div data-demo className="fixed bottom-2 right-2 z-50 rounded-md border bg-card px-1.5 py-0.5 text-[11px] text-muted-foreground shadow-xs">
        <label>Demo stato <select aria-label="Stato demo" className="bg-transparent text-foreground" defaultValue="normale" onChange={(e) => demo(e.target.value)}>
          <option value="normale">normale</option><option value="caricamento">caricamento</option><option value="errore-caricamento">errore di caricamento</option><option value="vuoto">nessun vino</option>
          <option value="molti-vini">più di 100 vini</option><option value="errore-azione">errore all’azione successiva</option><option value="errore-geografia">errore di coerenza geografica</option>
        </select></label>
      </div>
    </Shell>
  )
}
export const viniPage = <ViniPage />
