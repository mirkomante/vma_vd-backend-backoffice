import * as React from "react"
import { CircleCheck, CircleAlert, ChevronDown, Megaphone } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Textarea } from "@/components/ui/textarea"
import { Badge } from "@/components/ui/badge"
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert"
import { Skeleton } from "@/components/ui/skeleton"
import { Spinner } from "@/components/ui/spinner"
import { Field, FieldDescription, FieldGroup, FieldLabel } from "@/components/ui/field"
import { AlertDialog, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle } from "@/components/ui/alert-dialog"
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from "@/components/ui/collapsible"
import { Breadcrumb, BreadcrumbItem, BreadcrumbList, BreadcrumbPage, BreadcrumbSeparator, BreadcrumbLink } from "@/components/ui/breadcrumb"
import { SidebarGroup, SidebarGroupContent, SidebarGroupLabel, SidebarMenu, SidebarMenuButton, SidebarMenuItem } from "@/components/ui/sidebar"
import { Shell } from "./layouts"
import { UtensilsCrossed, Wine, CupSoda, Martini, BookOpen, ConciergeBell, CalendarHeart, Clock, CalendarDays, Settings } from "lucide-react"

/* ---------- navigazione a otto voci (D1) ---------- */
const GRUPPI: { label: string; voci: { label: string; icon: React.ComponentType<any> }[] }[] = [
  { label: "Menù", voci: [{ label: "Piatti", icon: UtensilsCrossed }, { label: "Vini", icon: Wine }, { label: "Bevande", icon: CupSoda }, { label: "Distillati", icon: Martini }, { label: "Menù fissi", icon: BookOpen }, { label: "Servizi", icon: ConciergeBell }, { label: "Giorni speciali", icon: CalendarHeart }, { label: "Messaggio globale", icon: Megaphone }] },
  { label: "Orari", voci: [{ label: "Orari", icon: Clock }] },
  { label: "Prenotazioni", voci: [{ label: "Elenco", icon: CalendarDays }, { label: "Eccezioni giorno", icon: CalendarDays }, { label: "Impostazioni", icon: Settings }] },
]
function MenuOtto({ active }: { active: string }) {
  return (
    <>
      {GRUPPI.map((g) => (
        <SidebarGroup key={g.label}>
          <SidebarGroupLabel>{g.label}</SidebarGroupLabel>
          <SidebarGroupContent>
            <SidebarMenu>
              {g.voci.map((v) => (
                <SidebarMenuItem key={v.label}>
                  <SidebarMenuButton render={<a href="#" />} isActive={g.label === "Menù" && v.label === active} tooltip={v.label}><v.icon /><span>{v.label}</span></SidebarMenuButton>
                </SidebarMenuItem>
              ))}
            </SidebarMenu>
          </SidebarGroupContent>
        </SidebarGroup>
      ))}
    </>
  )
}

type Msg = { it: string; en: string }
// `file`: il contenuto di disponibilita.json letto dal server (null = non leggibile: niente indicatore, resta l'avviso standard)
type FileState = { it: string; at: string } | null
const SERR = "Non è stato modificato nulla. Controlla la connessione e riprova; se il problema continua, avvisa l’amministratore."
const ora = () => new Date().toLocaleTimeString("it-IT", { hour: "2-digit", minute: "2-digit" })
const CLEAN = (s: string) => s.replace(/\s*\n\s*/g, " ") // il campo è un testo breve: niente a capo

function MessaggioPage() {
  const [saved, setSaved] = React.useState<Msg>({ it: "Oggi la cucina chiude alle 22:00.", en: "" })
  const [draft, setDraft] = React.useState<Msg>(saved)
  const [file, setFile] = React.useState<FileState>({ it: "Oggi la cucina chiude alle 22:00.", at: "12:41" })
  const [enOpen, setEnOpen] = React.useState(false)
  const [busy, setBusy] = React.useState(false)
  const [notice, setNotice] = React.useState<{ kind: "ok" | "err"; title: string; text?: string } | null>(null)
  const [loadState, setLoadState] = React.useState<"ok" | "loading" | "error">("ok")
  const [failNext, setFailNext] = React.useState(false)
  const [slow, setSlow] = React.useState(false)
  const [delOpen, setDelOpen] = React.useState(false)
  const [delBusy, setDelBusy] = React.useState(false)

  const dirty = draft.it !== saved.it || draft.en !== saved.en
  const hasSaved = !!(saved.it || saved.en)
  const publishing = file !== null && file.it !== saved.it // il file non ha ancora il testo salvato
  async function publish(it: string) {
    if (file === null) return
    await new Promise((r) => setTimeout(r, slow ? 2500 : 300))
    setFile({ it, at: ora() })
  }
  async function save() {
    setBusy(true); setNotice(null); await new Promise((r) => setTimeout(r, 600)); setBusy(false)
    if (failNext) { setFailNext(false); setNotice({ kind: "err", title: "Operazione non riuscita", text: SERR }); return }
    const next = { it: draft.it.trim(), en: draft.en.trim() }
    setSaved(next); setDraft(next); setNotice({ kind: "ok", title: "Messaggio salvato", text: "Il menù pubblico lo mostra entro pochi minuti." }); publish(next.it)
  }
  async function remove() {
    setDelBusy(true); await new Promise((r) => setTimeout(r, 500)); setDelBusy(false)
    if (failNext) { setFailNext(false); setDelOpen(false); setNotice({ kind: "err", title: "Operazione non riuscita", text: SERR }); return }
    const empty = { it: "", en: "" }; setSaved(empty); setDraft(empty); setDelOpen(false); setNotice({ kind: "ok", title: "Messaggio tolto", text: "Il menù pubblico non lo mostra più entro pochi minuti." }); publish("")
  }
  function demo(v: string) {
    setNotice(null); setLoadState("ok"); setFailNext(false); setSlow(false)
    const base = { it: "Oggi la cucina chiude alle 22:00.", en: "" }
    setSaved(base); setDraft(base); setFile({ it: base.it, at: "12:41" })
    if (v === "caricamento") setLoadState("loading"); if (v === "errore-caricamento") setLoadState("error"); if (v === "errore-azione") setFailNext(true); if (v === "pubblicazione-lenta") setSlow(true)
    if (v === "nessun-messaggio") { const e = { it: "", en: "" }; setSaved(e); setDraft(e); setFile({ it: "", at: "12:41" }) }
    if (v === "file-non-leggibile") setFile(null)
  }

  return (
    <Shell themeSwitch adminInUserMenu menu={<MenuOtto active="Messaggio globale" />}
      topbar={<Breadcrumb><BreadcrumbList><BreadcrumbItem><BreadcrumbLink href="#">Menù</BreadcrumbLink></BreadcrumbItem><BreadcrumbSeparator /><BreadcrumbItem><BreadcrumbPage>Messaggio globale</BreadcrumbPage></BreadcrumbItem></BreadcrumbList></Breadcrumb>}>
      <div className="mx-auto flex w-full max-w-2xl flex-col gap-5" data-block="contenitore-pagina">
        <div data-block="intestazione-pagina"><h1 className="text-xl font-semibold tracking-tight">Messaggio globale</h1><p className="text-sm text-muted-foreground">Un avviso breve sul menù pubblico, per esempio «oggi cucina chiusa». Compare senza ricompilare.</p></div>
        {notice && <Alert role="status" data-component="Alert" variant={notice.kind === "err" ? "destructive" : "default"}>{notice.kind === "err" ? <CircleAlert /> : <CircleCheck />}<AlertTitle>{notice.title}</AlertTitle>{notice.text && <AlertDescription>{notice.text}</AlertDescription>}</Alert>}
        {loadState === "loading" && <div className="flex flex-col gap-3" aria-busy="true" data-block="caricamento"><Skeleton className="h-20 w-full rounded-xl" /><Skeleton className="h-32 w-full rounded-xl" /></div>}
        {loadState === "error" && <Alert variant="destructive" role="alert" data-component="Alert"><CircleAlert /><AlertTitle>Impossibile caricare il messaggio</AlertTitle><AlertDescription><p>Riprova tra qualche istante; se il problema continua, avvisa l’amministratore.</p><Button variant="outline" className="mt-3" data-component="Button" onClick={() => setLoadState("ok")}>Riprova</Button></AlertDescription></Alert>}
        {loadState === "ok" && (
          <>
            <section className="flex flex-col gap-2 rounded-lg border p-4" data-block="stato-pubblicato" aria-live="polite">
              <h2 className="text-sm font-semibold">Sul menù pubblico</h2>
              {file === null
                ? <p className="text-sm">{hasSaved ? <>Messaggio salvato: «{saved.it || saved.en}»</> : "Nessun messaggio."}</p>
                : <p className="text-sm">{file.it ? <>«{file.it}»</> : "Nessun messaggio."}</p>}
              {file !== null && (publishing
                ? <p className="flex items-center gap-2 text-xs text-muted-foreground"><Spinner className="size-3" /> In pubblicazione…</p>
                : <p className="text-xs text-muted-foreground">Menù pubblico aggiornato alle {file.at}. Chi ha la pagina aperta lo vede entro circa cinque minuti.</p>)}
            </section>
            <FieldGroup data-block="modulo-messaggio">
              <Field>
                <FieldLabel htmlFor="mg-it">Messaggio</FieldLabel>
                <Textarea id="mg-it" data-component="Textarea" rows={3} value={draft.it} onChange={(e) => setDraft({ ...draft, it: CLEAN(e.target.value) })} />
                <FieldDescription>Un avviso breve, per esempio «oggi cucina chiusa». Vuoto vuol dire nessun messaggio.</FieldDescription>
              </Field>
              <Collapsible open={enOpen} onOpenChange={setEnOpen} className="rounded-lg border" data-block="traduzione-inglese">
                <CollapsibleTrigger render={<button type="button" className="flex min-h-11 w-full items-center gap-2 px-3 text-left text-sm font-medium" />}>Traduzione inglese <span className="font-normal text-muted-foreground">(facoltativa)</span><Badge data-component="Badge" variant="outline" className="ml-auto">{draft.en ? "Presente" : "Manca"}</Badge><ChevronDown className={`size-4 transition-transform ${enOpen ? "rotate-180" : ""}`} /></CollapsibleTrigger>
                <CollapsibleContent><div className="flex flex-col gap-4 border-t p-3"><Field><FieldLabel htmlFor="mg-en">Message</FieldLabel><Textarea id="mg-en" rows={3} value={draft.en} onChange={(e) => setDraft({ ...draft, en: CLEAN(e.target.value) })} /><FieldDescription>Facoltativa. Se resta vuota, il menù mostra il testo italiano.</FieldDescription></Field></div></CollapsibleContent>
              </Collapsible>
            </FieldGroup>
            <div className="flex flex-col gap-2 sm:flex-row" data-block="azioni-pagina">
              <Button size="lg" data-component="Button" disabled={!dirty || busy} onClick={save}>{busy && <Spinner data-icon="inline-start" />}{busy ? "Salvataggio…" : "Salva modifiche"}</Button>
              <Button size="lg" variant="outline" data-component="Button" disabled={!dirty || busy} onClick={() => setDraft(saved)}>Annulla modifiche</Button>
              {hasSaved && <Button size="lg" variant="outline" data-component="Button" className="sm:ml-auto" disabled={busy} onClick={() => setDelOpen(true)}>Togli il messaggio</Button>}
            </div>
          </>
        )}
      </div>

      <AlertDialog open={delOpen} onOpenChange={(o) => !o && !delBusy && setDelOpen(false)}>
        <AlertDialogContent data-component="AlertDialog" data-state="togli">
          <AlertDialogHeader><AlertDialogTitle>Togliere il messaggio?</AlertDialogTitle><AlertDialogDescription>Il testo si perde.</AlertDialogDescription></AlertDialogHeader>
          <AlertDialogFooter><AlertDialogCancel disabled={delBusy}>Indietro</AlertDialogCancel><Button variant="destructive" data-component="Button" onClick={remove} disabled={delBusy}>{delBusy && <Spinner data-icon="inline-start" />}Togli</Button></AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

      <div data-demo className="fixed bottom-2 right-2 z-50 rounded-md border bg-card px-1.5 py-0.5 text-[11px] text-muted-foreground shadow-xs">
        <label>Demo stato <select aria-label="Stato demo" className="bg-transparent text-foreground" defaultValue="normale" onChange={(e) => demo(e.target.value)}>
          <option value="normale">normale (messaggio attivo)</option><option value="nessun-messaggio">nessun messaggio</option><option value="pubblicazione-lenta">pubblicazione lenta</option>
          <option value="file-non-leggibile">file non leggibile (senza ora)</option><option value="caricamento">caricamento</option><option value="errore-caricamento">errore di caricamento</option><option value="errore-azione">errore all’azione successiva</option>
        </select></label>
      </div>
    </Shell>
  )
}
export const messaggioPage = <MessaggioPage />
