import * as React from "react"
import { Pencil, Trash2, Plus, Search, SlidersHorizontal, MoreHorizontal, X, CircleCheck, Info, ChevronDown, UtensilsCrossed, Wine, CupSoda, Martini, BookOpen, ConciergeBell, CalendarHeart, Megaphone, Clock, CalendarDays, Settings } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { Switch } from "@/components/ui/switch"
import { Badge } from "@/components/ui/badge"
import { Card, CardContent } from "@/components/ui/card"
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert"
import { Field, FieldDescription, FieldGroup, FieldLabel, FieldLegend, FieldSet } from "@/components/ui/field"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Sheet, SheetContent, SheetDescription, SheetFooter, SheetHeader, SheetTitle } from "@/components/ui/sheet"
import { AlertDialog, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle } from "@/components/ui/alert-dialog"
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from "@/components/ui/collapsible"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs"
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "@/components/ui/dropdown-menu"
import { Breadcrumb, BreadcrumbItem, BreadcrumbList, BreadcrumbPage, BreadcrumbSeparator, BreadcrumbLink } from "@/components/ui/breadcrumb"
import { SidebarGroup, SidebarGroupContent, SidebarGroupLabel, SidebarMenu, SidebarMenuButton, SidebarMenuItem, useSidebar } from "@/components/ui/sidebar"
import { useIsMobile } from "@/hooks/use-mobile"
import { Shell } from "./layouts"

/* ============ Menu con otto voci sotto «Menù» ============ */
type Voce = { label: string; icon: React.ComponentType<any> }
const GRUPPI: { label: string; voci: Voce[] }[] = [
  { label: "Menù", voci: [
    { label: "Piatti", icon: UtensilsCrossed }, { label: "Vini", icon: Wine }, { label: "Bevande", icon: CupSoda },
    { label: "Distillati", icon: Martini }, { label: "Menù fissi", icon: BookOpen },
    { label: "Servizi", icon: ConciergeBell }, { label: "Giorni speciali", icon: CalendarHeart }, { label: "Messaggio globale", icon: Megaphone },
  ] },
  { label: "Orari", voci: [{ label: "Orari", icon: Clock }] },
  { label: "Prenotazioni", voci: [{ label: "Elenco", icon: CalendarDays }, { label: "Eccezioni giorno", icon: CalendarDays }, { label: "Impostazioni", icon: Settings }] },
]
function MenuOtto({ active }: { active: string }) {
  return (
    <>
      {GRUPPI.map((g) => (
        <SidebarGroup key={g.label}>
          <SidebarGroupLabel>{g.label}</SidebarGroupLabel>
          <SidebarGroupContent>
            <SidebarMenu>
              {g.voci.map((v) => (
                <SidebarMenuItem key={v.label}>
                  <SidebarMenuButton render={<a href="#" />} isActive={g.label === "Menù" && v.label === active} tooltip={v.label}><v.icon /><span>{v.label}</span></SidebarMenuButton>
                </SidebarMenuItem>
              ))}
            </SidebarMenu>
          </SidebarGroupContent>
        </SidebarGroup>
      ))}
    </>
  )
}
function OpenMobile() {
  const { setOpenMobile, isMobile } = useSidebar()
  React.useEffect(() => { if (isMobile) setOpenMobile(true) }, [isMobile, setOpenMobile])
  return null
}
const crumbs = (voce: string, extra?: string) => (
  <Breadcrumb><BreadcrumbList>
    <BreadcrumbItem><BreadcrumbLink href="#">Menù</BreadcrumbLink></BreadcrumbItem><BreadcrumbSeparator />
    <BreadcrumbItem>{extra ? <BreadcrumbLink href="#">{voce}</BreadcrumbLink> : <BreadcrumbPage>{voce}</BreadcrumbPage>}</BreadcrumbItem>
    {extra && <><BreadcrumbSeparator /><BreadcrumbItem><BreadcrumbPage>{extra}</BreadcrumbPage></BreadcrumbItem></>}
  </BreadcrumbList></Breadcrumb>
)
const pl = (n: number, one: string, many: string) => (n === 1 ? `1 ${one}` : `${n} ${many}`)
const euro = (p: string) => `${p} €`

function Nav8() {
  return (
    <Shell themeSwitch adminInUserMenu menu={<MenuOtto active="Vini" />} topbar={crumbs("Vini")}>
      <OpenMobile />
      <div className="mx-auto flex w-full max-w-5xl flex-col gap-2"><h1 className="text-xl font-semibold tracking-tight">Vini</h1><p className="text-sm text-muted-foreground">Bozza: qui si vede solo la navigazione a otto voci sotto «Menù».</p></div>
    </Shell>
  )
}

/* ============ Vini ============ */
const PAESI = ["Filippine", "Francia", "Giappone", "Guatemala", "Guyana", "Italia", "Martinica", "Scozia", "Thailandia", "Trinidad e Tobago", "Venezuela", "Vietnam"] // i 12 abilitati del seed, filtrati nella query
const REGIONI: Record<string, string[]> = { Italia: ["Campania", "Friuli Venezia Giulia", "Lombardia", "Marche", "Piemonte", "Puglia", "Sardegna", "Toscana", "Trentino Alto Adige", "Umbria", "Veneto"], Francia: ["Alsazia", "Borgogna", "Loira", "Rodano"] }
const DENOM: Record<string, string[]> = { "Friuli Venezia Giulia": ["Carso", "Collio"], Lombardia: ["Franciacorta"] }
const CLASS: Record<string, string[]> = { Italia: ["D.O.C.G.", "D.O.C.", "I.G.T.", "D.O.P."], Francia: ["A.O.C.", "A.O.P."] }
const TIPI = ["Bianchi", "Champagne", "Rosati", "Rossi", "Spumanti"]
type Vino = { id: number; name: string; winery: string; year: string; volume: string; abv: string; price: string; glass: string; cls: string; country: string; region: string; app: string; type: string; disabled: boolean }
const W = (id: number, name: string, type: string, country: string, region: string, app: string, cls: string, year: string, price: string, glass = "", disabled = false): Vino => ({ id, name, winery: "Cantina di esempio", year, volume: "75 cl", abv: "13%", price, glass, cls, country, region, app, type, disabled })
const VINI0: Vino[] = [
  W(1, "Friulano", "Bianchi", "Italia", "Friuli Venezia Giulia", "Collio", "D.O.C.", "2022", "28,00", "7,00"),
  W(2, "Vitovska", "Bianchi", "Italia", "Friuli Venezia Giulia", "Carso", "D.O.C.", "2021", "32,00"),
  W(3, "Brut", "Spumanti", "Italia", "Lombardia", "Franciacorta", "D.O.C.G.", "2020", "38,00", "9,00"),
  W(4, "Bourgogne Rouge", "Rossi", "Francia", "Borgogna", "", "A.O.C.", "2021", "45,00", "", true),
  W(5, "Brut Réserve", "Champagne", "Francia", "", "", "A.O.C.", "NV", "70,00", "14,00"),
]
const sel = (arr: string[]) => arr.map((v) => ({ value: v, label: v }))
function SelectF({ id, items, value, onChange, placeholder, disabled }: { id?: string; items: string[]; value: string; onChange: (v: string) => void; placeholder?: string; disabled?: boolean }) {
  return (
    <Select items={sel(items)} value={value || null} disabled={disabled} onValueChange={(v) => onChange((v as string) ?? "")}>
      <SelectTrigger id={id} data-component="Select" className="w-full"><SelectValue placeholder={placeholder} /></SelectTrigger>
      <SelectContent>{items.map((s) => <SelectItem key={s} value={s}>{s}</SelectItem>)}</SelectContent>
    </Select>
  )
}

function ViniPage({ mode, openForm, conferma }: { mode: "switch" | "menu" | "icone"; openForm?: boolean; conferma?: boolean }) {
  const narrow = useIsMobile()
  const [data, setData] = React.useState<Vino[]>(VINI0)
  const [q, setQ] = React.useState("")
  const [filters, setFilters] = React.useState({ tipo: "tutte", paese: "tutti", stato: "tutti" })
  const [draft, setDraft] = React.useState(filters)
  const [fOpen, setFOpen] = React.useState(false)
  const [sel_, setSel] = React.useState<number | null>(openForm ? 1 : null)
  const [form, setForm] = React.useState<Vino>(VINI0[0])
  const [glassOn] = React.useState(true)
  const [enOpen, setEnOpen] = React.useState(false)
  const [notice, setNotice] = React.useState<{ title: string; text: string } | null>(null)
  const [delTarget, setDelTarget] = React.useState<Vino | null>(conferma ? VINI0[1] : null)
  const term = q.trim().toLowerCase()
  const list = data.filter((v) =>
    (filters.tipo === "tutte" || v.type === filters.tipo) && (filters.paese === "tutti" || v.country === filters.paese) &&
    (filters.stato === "tutti" || (filters.stato === "abilitati") === !v.disabled) && (!term || `${v.name} ${v.winery}`.toLowerCase().includes(term)))
  const chips: { k: string; label: string }[] = []
  if (filters.tipo !== "tutte") chips.push({ k: "tipo", label: filters.tipo })
  if (filters.paese !== "tutti") chips.push({ k: "paese", label: filters.paese })
  if (filters.stato !== "tutti") chips.push({ k: "stato", label: filters.stato === "abilitati" ? "Abilitati" : "Disabilitati" })
  const reset = { tipo: "tutte", paese: "tutti", stato: "tutti" }
  const patch = (id: number, p: Partial<Vino>) => setData((x) => x.map((v) => (v.id === id ? { ...v, ...p } : v)))
  const toggle = (v: Vino) => { patch(v.id, { disabled: !v.disabled }); setNotice({ title: v.disabled ? "Vino abilitato" : "Vino disabilitato", text: "Il menù pubblico si aggiorna entro pochi secondi." }) }
  const openEdit = (v: Vino) => { setForm(v); setEnOpen(false); setSel(v.id) }
  const setF = <K extends keyof Vino>(k: K, val: Vino[K]) => setForm((f) => ({ ...f, [k]: val }))
  const setCountry = (c: string) => setForm((f) => ({ ...f, country: c, region: "", app: "", cls: CLASS[c]?.includes(f.cls) ? f.cls : "" }))
  const setRegion = (r: string) => setForm((f) => ({ ...f, region: r, app: "" }))

  const Switcher = ({ v }: { v: Vino }) => <Switch data-component="Switch" aria-label={`Disponibile: ${v.name}`} checked={!v.disabled} onCheckedChange={() => toggle(v)} />
  const Actions = ({ v }: { v: Vino }) => mode === "icone" ? (
    <div className="flex items-center">
      <Button variant="ghost" size="icon" aria-label={`Modifica ${v.name}`} data-component="Button" onClick={() => openEdit(v)}><Pencil /></Button>
      <Button variant="ghost" size="icon" aria-label={`Elimina ${v.name}`} data-component="Button" onClick={() => setDelTarget(v)}><Trash2 /></Button>
    </div>
  ) : (
    <DropdownMenu>
      <DropdownMenuTrigger render={<Button variant="ghost" size="icon" aria-label={`Azioni per ${v.name}`} data-component="Button" />}><MoreHorizontal /></DropdownMenuTrigger>
      <DropdownMenuContent align="end" className="min-w-44">
        <DropdownMenuItem onClick={() => openEdit(v)}>Modifica</DropdownMenuItem>
        {mode === "menu" && <DropdownMenuItem onClick={() => toggle(v)}>{v.disabled ? "Abilita" : "Disabilita"}</DropdownMenuItem>}
      </DropdownMenuContent>
    </DropdownMenu>
  )
  const NameWrap: any = mode === "icone" ? "div" : "button"
  const sub = (v: Vino) => [v.winery, v.year].filter(Boolean).join(" · ")
  const Group = ({ tipo }: { tipo: string }) => {
    const rows = list.filter((v) => v.type === tipo).sort((a, b) => a.name.localeCompare(b.name, "it", { sensitivity: "base" })); if (!rows.length) return null
    return (
      <section className="flex flex-col gap-2" data-block={`gruppo-${tipo.toLowerCase()}`}>
        <h2 className="flex items-baseline gap-2 text-base font-semibold">{tipo} <span className="text-sm font-normal text-muted-foreground">{pl(rows.length, "vino", "vini")}</span></h2>
        <div className="hidden rounded-lg border md:block" data-block="elenco-tabella">
          <Table data-component="Table">
            <TableHeader><TableRow><TableHead>Nome</TableHead><TableHead>Origine</TableHead><TableHead className="w-28">Prezzo</TableHead><TableHead className="w-32">Stato</TableHead>{mode !== "menu" && <TableHead className="w-28">Disponibile</TableHead>}<TableHead className="w-14"><span className="sr-only">Azioni</span></TableHead></TableRow></TableHeader>
            <TableBody>
              {rows.map((v) => (
                <TableRow key={v.id} className={v.disabled ? "text-muted-foreground" : ""}>
                  <TableCell>{mode === "icone" ? <span className="text-sm font-medium">{v.name}</span> : <Button variant="link" className="h-auto justify-start p-0 text-inherit" onClick={() => openEdit(v)}>{v.name}</Button>}<div className="text-xs text-muted-foreground">{sub(v)}</div></TableCell>
                  <TableCell className="text-sm">{[v.country, v.region].filter(Boolean).join(" · ")}</TableCell>
                  <TableCell className="tabular-nums">{euro(v.price)}{v.glass && <div className="text-xs text-muted-foreground">calice {euro(v.glass)}</div>}</TableCell>
                  <TableCell>{v.disabled ? <Badge data-component="Badge" variant="outline">Disabilitato</Badge> : <span className="text-sm text-muted-foreground">Disponibile</span>}</TableCell>
                  {mode !== "menu" && <TableCell><Switcher v={v} /></TableCell>}
                  <TableCell className="text-right"><Actions v={v} /></TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </div>
        <div className="flex flex-col gap-2 md:hidden" data-block="elenco-schede">
          {rows.map((v) => (
            <Card key={v.id} size="sm" data-component="Card" className={v.disabled ? "text-muted-foreground" : ""}>
              <CardContent className="flex items-center gap-2">
                <NameWrap {...(mode === "icone" ? {} : { type: "button", onClick: () => openEdit(v), "aria-label": `${v.name}, ${euro(v.price)}` })} className="min-w-0 flex-1 rounded-md py-1 text-left outline-none focus-visible:ring-3 focus-visible:ring-ring/50">
                  <div className="truncate text-sm font-medium">{v.name}</div>
                  <div className="truncate text-xs text-muted-foreground">{sub(v)}</div>
                  <div className="mt-0.5 flex items-center gap-2 text-xs text-muted-foreground"><span className="tabular-nums">{euro(v.price)}{v.glass && ` · calice ${euro(v.glass)}`}</span>{v.disabled && <Badge data-component="Badge" variant="outline">Disabilitato</Badge>}</div>
                </NameWrap>
                {mode !== "menu" && <label className="flex flex-col items-center gap-1 text-[11px] text-muted-foreground"><Switcher v={v} />Disponibile</label>}
                <Actions v={v} />
              </CardContent>
            </Card>
          ))}
        </div>
      </section>
    )
  }

  return (
    <Shell themeSwitch adminInUserMenu menu={<MenuOtto active="Vini" />} topbar={crumbs("Vini")}>
      <div className="mx-auto flex w-full max-w-5xl flex-col gap-5" data-block="contenitore-elenco">
        <div className="flex flex-col gap-3 sm:flex-row sm:items-start sm:justify-between">
          <div><h1 className="text-xl font-semibold tracking-tight">Vini</h1><p className="text-sm text-muted-foreground">La carta dei vini.</p></div>
          <Button size="lg" data-component="Button"><Plus data-icon="inline-start" /> Nuovo vino</Button>
        </div>
        {notice && <Alert role="status" data-component="Alert"><CircleCheck /><AlertTitle>{notice.title}</AlertTitle><AlertDescription>{notice.text}</AlertDescription></Alert>}
        <div className="flex gap-2" data-block="ricerca-filtri">
          <div className="relative min-w-0 flex-1"><Search className="pointer-events-none absolute top-1/2 left-3 size-4 -translate-y-1/2 text-muted-foreground" /><Input data-component="Input" aria-label="Cerca" placeholder="Cerca un vino o una cantina" className="pl-9" value={q} onChange={(e) => setQ(e.target.value)} /></div>
          <Button variant="outline" data-component="Button" onClick={() => { setDraft(filters); setFOpen(true) }}><SlidersHorizontal data-icon="inline-start" /> Filtri{chips.length > 0 && <Badge data-component="Badge" className="ml-1">{chips.length}</Badge>}</Button>
        </div>
        {chips.length > 0 && <div className="flex flex-wrap gap-2">{chips.map((c) => <Button key={c.k} variant="secondary" size="sm" data-component="Button" aria-label={`Rimuovi filtro ${c.label}`} onClick={() => setFilters({ ...filters, [c.k]: (reset as any)[c.k] })}>{c.label}<X data-icon="inline-end" /></Button>)}</div>}
        {list.length === 0
          ? <div className="flex flex-col items-start gap-3 rounded-lg border border-dashed p-6"><p className="text-sm text-muted-foreground">Nessun risultato con questi filtri.</p><Button variant="outline" onClick={() => { setFilters(reset); setQ("") }}>Azzera filtri</Button></div>
          : <div className="flex flex-col gap-6">{TIPI.map((t) => <Group key={t} tipo={t} />)}</div>}
        <p className="text-xs text-muted-foreground">Dati di esempio. Bozza per decidere: matita per modificare, interruttore «Disponibile» per abilitare e disabilitare, cestino per eliminare (con conferma).</p>
      </div>

      <AlertDialog open={delTarget !== null} onOpenChange={(o) => { if (!o) setDelTarget(null) }}>
        <AlertDialogContent data-component="AlertDialog" data-state="elimina">
          <AlertDialogHeader><AlertDialogTitle>Eliminare {delTarget?.name}?</AlertDialogTitle>
            <AlertDialogDescription>Non si può annullare.</AlertDialogDescription></AlertDialogHeader>
          <AlertDialogFooter><AlertDialogCancel>Indietro</AlertDialogCancel><Button variant="destructive" data-component="Button" onClick={() => { const id = delTarget!.id; setData((x) => x.filter((w) => w.id !== id)); setDelTarget(null); setNotice({ title: "Vino eliminato", text: "Per toglierlo dal menù pubblico serve «Ricompila il menù pubblico»." }) }}>Elimina</Button></AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

      <Sheet open={fOpen} onOpenChange={setFOpen}>
        <SheetContent side={narrow ? "bottom" : "right"} data-component="Sheet">
          <SheetHeader><SheetTitle>Filtri</SheetTitle><SheetDescription>Restringi l’elenco dei vini.</SheetDescription></SheetHeader>
          <FieldGroup className="px-4">
            <Field><FieldLabel htmlFor="f-tipo">Tipologia</FieldLabel><Select items={[{ value: "tutte", label: "Tutte le tipologie" }, ...sel(TIPI)]} value={draft.tipo} onValueChange={(v) => setDraft({ ...draft, tipo: v as string })}><SelectTrigger id="f-tipo" className="w-full"><SelectValue /></SelectTrigger><SelectContent>{[{ value: "tutte", label: "Tutte le tipologie" }, ...sel(TIPI)].map((s) => <SelectItem key={s.value} value={s.value}>{s.label}</SelectItem>)}</SelectContent></Select></Field>
            <Field><FieldLabel htmlFor="f-paese">Paese</FieldLabel><Select items={[{ value: "tutti", label: "Tutti i paesi" }, ...sel(PAESI)]} value={draft.paese} onValueChange={(v) => setDraft({ ...draft, paese: v as string })}><SelectTrigger id="f-paese" className="w-full"><SelectValue /></SelectTrigger><SelectContent>{[{ value: "tutti", label: "Tutti i paesi" }, ...sel(PAESI)].map((s) => <SelectItem key={s.value} value={s.value}>{s.label}</SelectItem>)}</SelectContent></Select></Field>
            <Field><FieldLabel htmlFor="f-stato">Stato</FieldLabel><Select items={[{ value: "tutti", label: "Tutti" }, { value: "abilitati", label: "Abilitati" }, { value: "disabilitati", label: "Disabilitati" }]} value={draft.stato} onValueChange={(v) => setDraft({ ...draft, stato: v as string })}><SelectTrigger id="f-stato" className="w-full"><SelectValue /></SelectTrigger><SelectContent>{[{ value: "tutti", label: "Tutti" }, { value: "abilitati", label: "Abilitati" }, { value: "disabilitati", label: "Disabilitati" }].map((s) => <SelectItem key={s.value} value={s.value}>{s.label}</SelectItem>)}</SelectContent></Select></Field>
          </FieldGroup>
          <SheetFooter className="grid grid-cols-2"><Button size="lg" onClick={() => { setFilters(draft); setFOpen(false) }}>Applica</Button><Button size="lg" variant="outline" onClick={() => setDraft(reset)}>Azzera</Button></SheetFooter>
        </SheetContent>
      </Sheet>

      <Sheet open={sel_ !== null} onOpenChange={(o) => { if (!o) setSel(null) }}>
        <SheetContent side={narrow ? "bottom" : "right"} data-component="Sheet">
          <SheetHeader><SheetTitle>Modifica vino</SheetTitle><SheetDescription>{form.name}</SheetDescription></SheetHeader>
          <FieldGroup className="px-4" data-block="modulo-vino">
            <FieldSet data-block="dati">
              <FieldLegend variant="label">Dati</FieldLegend>
              <Field><FieldLabel htmlFor="v-nome">Nome</FieldLabel><Input id="v-nome" value={form.name} onChange={(e) => setF("name", e.target.value)} /></Field>
              <Field><FieldLabel htmlFor="v-cantina">Cantina</FieldLabel><Input id="v-cantina" value={form.winery} onChange={(e) => setF("winery", e.target.value)} /></Field>
              <div className="grid grid-cols-3 gap-3">
                <Field><FieldLabel htmlFor="v-anno">Anno</FieldLabel><Input id="v-anno" value={form.year} onChange={(e) => setF("year", e.target.value)} /></Field>
                <Field><FieldLabel htmlFor="v-cap">Capacità</FieldLabel><Input id="v-cap" value={form.volume} onChange={(e) => setF("volume", e.target.value)} /></Field>
                <Field><FieldLabel htmlFor="v-grado">Grado</FieldLabel><Input id="v-grado" value={form.abv} onChange={(e) => setF("abv", e.target.value)} /></Field>
              </div>
              <Field><FieldLabel htmlFor="v-desc">Descrizione</FieldLabel><Textarea id="v-desc" data-component="Textarea" /></Field>
              <Collapsible open={enOpen} onOpenChange={setEnOpen} className="rounded-lg border" data-block="traduzione-inglese">
                <CollapsibleTrigger render={<button type="button" className="flex min-h-11 w-full items-center gap-2 px-3 text-left text-sm font-medium" />}>
                  Traduzione inglese <span className="font-normal text-muted-foreground">(facoltativa)</span>
                  <Badge data-component="Badge" variant="outline" className="ml-auto">Manca</Badge><ChevronDown className={`size-4 transition-transform ${enOpen ? "rotate-180" : ""}`} />
                </CollapsibleTrigger>
                <CollapsibleContent><div className="flex flex-col gap-4 border-t p-3"><Field><FieldLabel htmlFor="v-desc-en">Description</FieldLabel><Textarea id="v-desc-en" /><FieldDescription>Facoltativa. Se resta vuota, il menù mostra il testo italiano.</FieldDescription></Field></div></CollapsibleContent>
              </Collapsible>
            </FieldSet>
            <FieldSet data-block="origine">
              <FieldLegend variant="label">Origine</FieldLegend>
              <Field><FieldLabel htmlFor="v-tipo">Tipologia</FieldLabel><SelectF id="v-tipo" items={TIPI} value={form.type} onChange={(v) => setF("type", v)} placeholder="Scegli" /></Field>
              <Field><FieldLabel htmlFor="v-paese">Paese</FieldLabel><SelectF id="v-paese" items={PAESI} value={form.country} onChange={setCountry} placeholder="Scegli" /></Field>
              <Field><FieldLabel htmlFor="v-reg">Regione</FieldLabel><SelectF id="v-reg" items={REGIONI[form.country] ?? []} value={form.region} onChange={setRegion} placeholder={!form.country ? "Scegli prima il paese" : (REGIONI[form.country] ?? []).length ? "Facoltativa" : "Nessuna regione per questo paese"} disabled={!form.country || !(REGIONI[form.country] ?? []).length} /></Field>
              <Field><FieldLabel htmlFor="v-den">Denominazione</FieldLabel><SelectF id="v-den" items={DENOM[form.region] ?? []} value={form.app} onChange={(v) => setF("app", v)} placeholder={form.region ? ((DENOM[form.region] ?? []).length ? "Facoltativa" : "Nessuna denominazione per questa regione") : "Scegli prima la regione"} disabled={!form.region || !(DENOM[form.region] ?? []).length} /></Field>
              <Field><FieldLabel htmlFor="v-cls">Classificazione</FieldLabel><SelectF id="v-cls" items={CLASS[form.country] ?? []} value={form.cls} onChange={(v) => setF("cls", v)} placeholder={!form.country ? "Scegli prima il paese" : (CLASS[form.country] ?? []).length ? "Facoltativa" : "Nessuna classificazione per questo paese"} disabled={!form.country || !(CLASS[form.country] ?? []).length} />
                <FieldDescription>Le classificazioni mostrate seguono il paese scelto.</FieldDescription></Field>
            </FieldSet>
            <FieldSet data-block="prezzi">
              <FieldLegend variant="label">Prezzi</FieldLegend>
              <div className="grid grid-cols-2 gap-3">
                <Field><FieldLabel htmlFor="v-prezzo">Prezzo (€)</FieldLabel><Input id="v-prezzo" inputMode="decimal" value={form.price} onChange={(e) => setF("price", e.target.value)} /></Field>
                <Field><FieldLabel htmlFor="v-calice">Al calice (€)</FieldLabel><Input id="v-calice" inputMode="decimal" value={form.glass} onChange={(e) => setF("glass", e.target.value)} /></Field>
              </div>
            </FieldSet>
            <FieldSet data-block="disponibilita">
              <FieldLegend variant="label">Disponibilità</FieldLegend>
              <Field orientation="horizontal"><div className="flex-1"><FieldLabel htmlFor="v-dis" className="min-h-11 items-center">Disabilitato</FieldLabel><FieldDescription>Assente a tempo indefinito: il vino non compare nel menù.</FieldDescription></div><Switch id="v-dis" data-component="Switch" checked={form.disabled} onCheckedChange={(c) => setF("disabled", c === true)} /></Field>
            </FieldSet>
          </FieldGroup>
          <SheetFooter className="grid grid-cols-2"><Button size="lg" onClick={() => { patch(form.id, form); setSel(null) }}>Salva</Button><Button size="lg" variant="outline" onClick={() => setSel(null)}>Annulla</Button></SheetFooter>
        </SheetContent>
      </Sheet>
    </Shell>
  )
}

/* ============ Menù fissi con scheda «Categorie» ============ */
type Cat = { id: number; name: string; vis: string; disabled: boolean; n: number }
const VIS = ["Sempre", "Solo pranzo", "Solo cena"]
const CATS0: Cat[] = [{ id: 1, name: "Business lunch", vis: "Solo pranzo", disabled: false, n: 2 }, { id: 2, name: "Degustazione", vis: "Sempre", disabled: false, n: 2 }]
const MENUS0 = [
  { cat: "Business lunch", name: "Business lunch Vietnam", price: "18,00", vis: "Solo pranzo" }, { cat: "Business lunch", name: "Business lunch Vegetariano", price: "16,00", vis: "Solo pranzo" },
  { cat: "Degustazione", name: "Degustazione classica", price: "38,00", vis: "Sempre" }, { cat: "Degustazione", name: "Degustazione del mare", price: "45,00", vis: "Sempre" },
]
function MenuFissiPage({ senzaCategorie }: { senzaCategorie?: boolean }) {
  const narrow = useIsMobile()
  const [tab, setTab] = React.useState<string>(senzaCategorie ? "menu" : "categorie")
  const [cats, setCats] = React.useState<Cat[]>(senzaCategorie ? [] : CATS0)
  const [selId, setSelId] = React.useState<number | null>(null)
  const [form, setForm] = React.useState({ name: "", nameEn: "", vis: "Sempre", disabled: false })
  const [enOpen, setEnOpen] = React.useState(false)
  const [notice, setNotice] = React.useState<{ title: string; text: string } | null>(null)
  const openNew = () => { setForm({ name: "", nameEn: "", vis: "Sempre", disabled: false }); setEnOpen(false); setSelId(-1) }
  const openEdit = (c: Cat) => { setForm({ name: c.name, nameEn: "", vis: c.vis, disabled: c.disabled }); setEnOpen(false); setSelId(c.id) }
  const save = () => {
    if (!form.name.trim()) return
    if (selId === -1) setCats((x) => [...x, { id: 50 + x.length, name: form.name.trim(), vis: form.vis, disabled: form.disabled, n: 0 }])
    else setCats((x) => x.map((c) => (c.id === selId ? { ...c, name: form.name.trim(), vis: form.vis, disabled: form.disabled } : c)))
    setSelId(null); setNotice({ title: selId === -1 ? "Categoria aggiunta" : "Categoria salvata", text: "Per vederla sul menù pubblico serve «Ricompila il menù pubblico»." })
  }
  const sorted = [...cats].sort((a, b) => a.name.localeCompare(b.name, "it", { sensitivity: "base" }))
  const toggleDis = (c: Cat) => { setCats((x) => x.map((k) => (k.id === c.id ? { ...k, disabled: !k.disabled } : k))); setNotice({ title: c.disabled ? "Categoria abilitata" : "Categoria disabilitata", text: "Per vederla sul menù pubblico serve «Ricompila il menù pubblico»." }) }
  const noCats = cats.length === 0
  return (
    <Shell themeSwitch adminInUserMenu menu={<MenuOtto active="Menù fissi" />} topbar={crumbs("Menù fissi", tab === "categorie" ? "Categorie" : undefined)}>
      <div className="mx-auto flex w-full max-w-5xl flex-col gap-5" data-block="contenitore-elenco">
        <div><h1 className="text-xl font-semibold tracking-tight">Menù fissi</h1><p className="text-sm text-muted-foreground">I menù a prezzo fisso e le loro categorie.</p></div>
        <Tabs value={tab} onValueChange={(v) => setTab(v as string)} className="gap-5">
          <div className="-mx-4 overflow-x-auto px-4 md:mx-0 md:px-0" data-block="schede"><TabsList variant="line" data-component="Tabs" data-variant="line"><TabsTrigger value="menu">Menù fissi</TabsTrigger><TabsTrigger value="categorie">Categorie</TabsTrigger></TabsList></div>
          {notice && <Alert role="status" data-component="Alert"><CircleCheck /><AlertTitle>{notice.title}</AlertTitle><AlertDescription>{notice.text}</AlertDescription></Alert>}
          <TabsContent value="menu" className="flex flex-col gap-5">
            <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between"><p className="text-sm text-muted-foreground">Bozza di contesto: la schermata dei menù fissi si disegna dopo.</p><Button size="lg" data-component="Button" disabled={noCats}><Plus data-icon="inline-start" /> Nuovo menù fisso</Button></div>
            {noCats
              ? <Alert data-component="Alert" role="status"><Info /><AlertTitle>Prima serve una categoria</AlertTitle><AlertDescription><p>Ogni menù fisso appartiene a una categoria (per esempio «Degustazione»). Creane almeno una per poter comporre i menù.</p><Button variant="outline" className="mt-3" data-component="Button" onClick={() => setTab("categorie")}>Vai alle categorie</Button></AlertDescription></Alert>
              : <div className="flex flex-col gap-4">{sorted.map((c) => (
                <section key={c.id} className="flex flex-col gap-2"><h2 className="text-base font-semibold">{c.name}</h2>
                  {MENUS0.filter((m) => m.cat === c.name).map((m) => <Card key={m.name} size="sm" data-component="Card"><CardContent className="flex items-center justify-between gap-2"><div><div className="text-sm font-medium">{m.name}</div><div className="text-xs text-muted-foreground">{m.vis}</div></div><span className="text-sm tabular-nums">{euro(m.price)}</span></CardContent></Card>)}
                </section>))}</div>}
          </TabsContent>
          <TabsContent value="categorie" className="flex flex-col gap-5">
            <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between"><p className="text-sm text-muted-foreground">{pl(cats.length, "categoria", "categorie")}, in ordine per nome.</p><Button size="lg" data-component="Button" onClick={openNew}><Plus data-icon="inline-start" /> Nuova categoria</Button></div>
            {noCats
              ? <div className="flex flex-col items-start gap-3 rounded-lg border border-dashed p-6" data-block="vuoto"><p className="text-sm text-muted-foreground">Nessuna categoria. Creane una per poter comporre i menù fissi.</p><Button variant="outline" data-component="Button" onClick={openNew}>Nuova categoria</Button></div>
              : <div className="flex flex-col gap-2" data-block="elenco-categorie">{sorted.map((c) => (
                <Card key={c.id} size="sm" data-component="Card" className={c.disabled ? "text-muted-foreground" : ""}>
                  <CardContent className="flex items-center gap-2">
                    <div className="min-w-0 flex-1 rounded-md py-1 text-left">
                      <div className="truncate text-sm font-medium">{c.name}</div>
                      <div className="mt-0.5 flex items-center gap-2 text-xs text-muted-foreground"><span>{c.vis}</span><span>·</span><span>{pl(c.n, "menù", "menù")}</span>{c.disabled && <Badge data-component="Badge" variant="outline">Disabilitata</Badge>}</div>
                    </div>
                    <label className="flex flex-col items-center gap-1 text-[11px] text-muted-foreground"><Switch data-component="Switch" aria-label={`Attiva: ${c.name}`} checked={!c.disabled} onCheckedChange={() => toggleDis(c)} />Attiva</label>
                    <Button variant="ghost" size="icon" aria-label={`Modifica ${c.name}`} data-component="Button" onClick={() => openEdit(c)}><Pencil /></Button>
                  </CardContent>
                </Card>))}</div>}
          </TabsContent>
        </Tabs>
      </div>
      <Sheet open={selId !== null} onOpenChange={(o) => { if (!o) setSelId(null) }}>
        <SheetContent side={narrow ? "bottom" : "right"} data-component="Sheet">
          <SheetHeader><SheetTitle>{selId === -1 ? "Nuova categoria" : "Modifica categoria"}</SheetTitle><SheetDescription>{selId === -1 ? "Raggruppa i menù fissi nel menù pubblico." : form.name}</SheetDescription></SheetHeader>
          <FieldGroup className="px-4">
            <Field><FieldLabel htmlFor="c-nome">Nome</FieldLabel><Input id="c-nome" value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} /></Field>
            <Collapsible open={enOpen} onOpenChange={setEnOpen} className="rounded-lg border">
              <CollapsibleTrigger render={<button type="button" className="flex min-h-11 w-full items-center gap-2 px-3 text-left text-sm font-medium" />}>Traduzione inglese <span className="font-normal text-muted-foreground">(facoltativa)</span><Badge data-component="Badge" variant="outline" className="ml-auto">Manca</Badge><ChevronDown className={`size-4 transition-transform ${enOpen ? "rotate-180" : ""}`} /></CollapsibleTrigger>
              <CollapsibleContent><div className="flex flex-col gap-4 border-t p-3"><Field><FieldLabel htmlFor="c-nome-en">Name</FieldLabel><Input id="c-nome-en" placeholder={form.name} value={form.nameEn} onChange={(e) => setForm({ ...form, nameEn: e.target.value })} /><FieldDescription>Facoltativa. Se resta vuota, il menù mostra il testo italiano.</FieldDescription></Field></div></CollapsibleContent>
            </Collapsible>
            <Field><FieldLabel htmlFor="c-vis">Visibilità</FieldLabel><SelectF id="c-vis" items={VIS} value={form.vis} onChange={(v) => setForm({ ...form, vis: v })} /><FieldDescription>Quando la categoria compare nelle pagine del menù pubblico.</FieldDescription></Field>
            <Field orientation="horizontal"><div className="flex-1"><FieldLabel htmlFor="c-dis" className="min-h-11 items-center">Disabilitata</FieldLabel><FieldDescription>Assente a tempo indefinito: la categoria non compare nel menù.</FieldDescription></div><Switch id="c-dis" data-component="Switch" checked={form.disabled} onCheckedChange={(c) => setForm({ ...form, disabled: c === true })} /></Field>
          </FieldGroup>
          <SheetFooter className="grid grid-cols-2"><Button size="lg" onClick={save}>Salva</Button><Button size="lg" variant="outline" onClick={() => setSelId(null)}>Annulla</Button></SheetFooter>
        </SheetContent>
      </Sheet>
    </Shell>
  )
}

export function bozza(n: number) {
  switch (n) {
    case 1: return <Nav8 />
    case 3: return <ViniPage mode="icone" />
    case 6: return <ViniPage mode="icone" conferma />
    case 4: return <ViniPage mode="icone" openForm />
    case 5: return <MenuFissiPage />
    default: return <Nav8 />
  }
}
