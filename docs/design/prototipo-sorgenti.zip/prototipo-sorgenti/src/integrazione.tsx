import * as React from "react"
import { UtensilsCrossed, Wine, CupSoda, Martini, BookOpen, ConciergeBell, CalendarHeart, Megaphone, Clock, CalendarDays, Settings, ChevronRight } from "lucide-react"
import { Card, CardContent } from "@/components/ui/card"
import { Skeleton } from "@/components/ui/skeleton"
import { SidebarGroup, SidebarGroupContent, SidebarGroupLabel, SidebarMenu, SidebarMenuButton, SidebarMenuItem, useSidebar } from "@/components/ui/sidebar"
import { Shell } from "./layouts"

/* ---------- navigazione a otto voci (D1): la tabella di lib/app/navigation.ts ---------- */
const GRUPPI: { label: string; voci: { label: string; icon: React.ComponentType<any> }[] }[] = [
  { label: "Menù", voci: [{ label: "Piatti", icon: UtensilsCrossed }, { label: "Vini", icon: Wine }, { label: "Bevande", icon: CupSoda }, { label: "Distillati", icon: Martini }, { label: "Menù fissi", icon: BookOpen }, { label: "Servizi", icon: ConciergeBell }, { label: "Giorni speciali", icon: CalendarHeart }, { label: "Messaggio globale", icon: Megaphone }] },
  { label: "Orari", voci: [{ label: "Orari", icon: Clock }] },
  { label: "Prenotazioni", voci: [{ label: "Elenco", icon: CalendarDays }, { label: "Eccezioni giorno", icon: CalendarDays }, { label: "Impostazioni", icon: Settings }] },
]
function MenuOtto() {
  return (
    <>
      {GRUPPI.map((g) => (
        <SidebarGroup key={g.label}>
          <SidebarGroupLabel>{g.label}</SidebarGroupLabel>
          <SidebarGroupContent>
            <SidebarMenu>
              {g.voci.map((v) => (
                <SidebarMenuItem key={v.label}>
                  <SidebarMenuButton render={<a href="#" />} isActive={false} tooltip={v.label}><v.icon /><span>{v.label}</span></SidebarMenuButton>
                </SidebarMenuItem>
              ))}
            </SidebarMenu>
          </SidebarGroupContent>
        </SidebarGroup>
      ))}
    </>
  )
}
function OpenMobile({ open }: { open: boolean }) {
  const { setOpenMobile, isMobile } = useSidebar()
  React.useEffect(() => { if (isMobile) setOpenMobile(open) }, [open, isMobile, setOpenMobile])
  return null
}

/* ---------- schede della home (D2) ---------- */
type MenuRow = { kind: "dati"; n: number } | { kind: "caricamento" } | { kind: "errore" }
const pl = (n: number, one: string, many: string) => (n === 1 ? `1 ${one}` : `${n} ${many}`)
// Riga di stato del Menù: i piatti TERMINATI (soldOut), letti con la sessione dell'utente; i disabilitati non contano (Mirko, 2026-10-15)
const menuStatus = (n: number) => (n === 0 ? "Nessun piatto terminato" : pl(n, "piatto terminato", "piatti terminati"))
function Scheda({ titolo, desc, icon: Icon, riga }: { titolo: string; desc: string; icon: React.ComponentType<any>; riga?: React.ReactNode }) {
  return (
    <a href="#" className="block rounded-xl outline-none focus-visible:ring-3 focus-visible:ring-ring/50" data-component="Card" data-block={`scheda-${titolo.toLowerCase()}`}>
      <Card className="transition-colors hover:bg-muted/50">
        <CardContent className="flex items-center gap-3">
          <div className="flex size-11 shrink-0 items-center justify-center rounded-lg bg-muted"><Icon className="size-5" /></div>
          <div className="min-w-0 flex-1">
            <div className="text-sm font-medium">{titolo}</div>
            <div className="text-xs text-muted-foreground">{desc}</div>
            {riga}
          </div>
          <ChevronRight className="size-4 shrink-0 text-muted-foreground" />
        </CardContent>
      </Card>
    </a>
  )
}

function IntegrazionePage() {
  const [row, setRow] = React.useState<MenuRow>({ kind: "dati", n: 3 })
  const [pannello, setPannello] = React.useState(false)
  function demo(v: string) {
    setPannello(false)
    if (v === "normale") setRow({ kind: "dati", n: 3 })
    if (v === "uno") setRow({ kind: "dati", n: 1 })
    if (v === "zero") setRow({ kind: "dati", n: 0 })
    if (v === "caricamento") setRow({ kind: "caricamento" })
    if (v === "errore") setRow({ kind: "errore" })
    if (v === "pannello") { setRow({ kind: "dati", n: 3 }); setPannello(true) }
  }
  const rigaMenu = row.kind === "dati"
    ? <div className="mt-1 text-xs font-medium" data-block="riga-stato-menu">{menuStatus(row.n)}</div>
    : row.kind === "caricamento" ? <Skeleton className="mt-1 h-4 w-32" data-block="riga-stato-menu" aria-busy="true" /> : undefined
  return (
    <Shell themeSwitch adminInUserMenu menu={<MenuOtto />} topbar={<span className="text-sm font-medium">Area App</span>}>
      <OpenMobile open={pannello} />
      <div>
        <h1 className="text-xl font-semibold tracking-tight">Oggi</h1>
        <p className="text-sm text-muted-foreground">Situazione di oggi e accesso alle sezioni.</p>
      </div>
      <div className="grid gap-3 md:grid-cols-2 xl:grid-cols-3" data-block="schede-sezioni">
        <Scheda titolo="Prenotazioni" desc="Elenco, eccezioni giorno, impostazioni" icon={CalendarDays} riga={<div className="mt-1 text-xs font-medium">Oggi 18 coperti · prossima alle 19:30</div>} />
        <Scheda titolo="Menù" desc="Piatti, vini, bevande, menù fissi e altro" icon={UtensilsCrossed} riga={rigaMenu} />
        <Scheda titolo="Orari" desc="Ristorante, B&B, giorni di riposo, chiusure" icon={Clock} riga={<div className="mt-1 text-xs font-medium">Oggi: 12:00–15:00 e 19:00–23:00</div>} />
      </div>
      <div data-demo className="fixed bottom-2 right-2 z-50 rounded-md border bg-card px-1.5 py-0.5 text-[11px] text-muted-foreground shadow-xs">
        <label>Demo stato <select aria-label="Stato demo" className="bg-transparent text-foreground" defaultValue="normale" onChange={(e) => demo(e.target.value)}>
          <option value="normale">3 piatti terminati</option><option value="uno">1 piatto terminato</option><option value="zero">nessun piatto terminato</option>
          <option value="caricamento">riga in caricamento</option><option value="errore">errore di lettura (la riga non compare)</option><option value="pannello">pannello di navigazione aperto (telefono)</option>
        </select></label>
      </div>
    </Shell>
  )
}
export const integrazionePage = <IntegrazionePage />
