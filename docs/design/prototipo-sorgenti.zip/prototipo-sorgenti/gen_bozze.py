# Galleria di bozze «per decidere» della 6.6 (pagine con alternative). Non sono schermate definitive.
# Prima: esbuild + tailwind + page_build.build('__B__', '/tmp/bozze-tpl.html', 'Bozze 6.6', '🍷').
# Le bozze stanno in src/bozze.tsx (bozza(n): navigazione, Vini, Categorie) e in src/piatti.tsx (piattiBozza);
# main.tsx le seleziona con window.__B__ = 1..8 (vedi INFO).
src=open('gen_gallery.py').read().split('\nL=[')[0]
ns={}; exec(src,ns)
tpl=open('/tmp/bozze-tpl.html').read().replace('</head>','<style>[data-demo]{display:none!important}</style></head>',1)
INFO=[(1,"Piatti · elenco","Interruttore «Terminato», matita, occhio e cestino.",""),
 (2,"Piatti · elimina un piatto libero","Conferma «Eliminare {nome}?».",""),
 (3,"Piatti · elimina un piatto in uso","«Non si può eliminare», con l'elenco dei menù fissi.",""),
 (4,"Vini · elenco","Interruttore «Disponibile», matita e cestino.",""),
 (5,"Vini · elimina","Stessa conferma del piatto libero.",""),
 (6,"Navigazione a otto voci","Gruppo «Menù» con otto voci.",""),
 (7,"Vini · modulo","Cascata paese → regione → denominazione.",""),
 (8,"Menù fissi · categorie","Scheda «Categorie»: interruttore «Attiva» e matita.","")]
ns['gallery']('/mnt/user-data/outputs/bozze-6-6-schermate.html','Menù: bozze per decidere (sottofase 6.6)','Prototipo con i componenti reali e dati di esempio.',tpl,'window.__B__=1',INFO,['p','n'],'Dati di esempio.')
