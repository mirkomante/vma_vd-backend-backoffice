import * as React from "react"
import { Pencil, Trash2, Plus, CircleCheck, CircleAlert, ChevronDown, RefreshCw, Info } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { Switch } from "@/components/ui/switch"
import { Checkbox } from "@/components/ui/checkbox"
import { Badge } from "@/components/ui/badge"
import { Card, CardContent } from "@/components/ui/card"
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert"
import { Skeleton } from "@/components/ui/skeleton"
import { Spinner } from "@/components/ui/spinner"
import { Field, FieldDescription, FieldError, FieldGroup, FieldLabel, FieldLegend, FieldSet } from "@/components/ui/field"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Sheet, SheetContent, SheetDescription, SheetFooter, SheetHeader, SheetTitle } from "@/components/ui/sheet"
import { AlertDialog, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle } from "@/components/ui/alert-dialog"
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from "@/components/ui/collapsible"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Breadcrumb, BreadcrumbItem, BreadcrumbList, BreadcrumbPage, BreadcrumbSeparator, BreadcrumbLink } from "@/components/ui/breadcrumb"
import { SidebarGroup, SidebarGroupContent, SidebarGroupLabel, SidebarMenu, SidebarMenuButton, SidebarMenuItem } from "@/components/ui/sidebar"
import { useIsMobile } from "@/hooks/use-mobile"
import { Shell } from "./layouts"
import { UtensilsCrossed, Wine, CupSoda, Martini, BookOpen, ConciergeBell, CalendarHeart, Megaphone, Clock, CalendarDays, Settings } from "lucide-react"

/* ---------- navigazione a otto voci (D1) ---------- */
const GRUPPI: { label: string; voci: { label: string; icon: React.ComponentType<any> }[] }[] = [
  { label: "Menù", voci: [{ label: "Piatti", icon: UtensilsCrossed }, { label: "Vini", icon: Wine }, { label: "Bevande", icon: CupSoda }, { label: "Distillati", icon: Martini }, { label: "Menù fissi", icon: BookOpen }, { label: "Servizi", icon: ConciergeBell }, { label: "Giorni speciali", icon: CalendarHeart }, { label: "Messaggio globale", icon: Megaphone }] },
  { label: "Orari", voci: [{ label: "Orari", icon: Clock }] },
  { label: "Prenotazioni", voci: [{ label: "Elenco", icon: CalendarDays }, { label: "Eccezioni giorno", icon: CalendarDays }, { label: "Impostazioni", icon: Settings }] },
]
function MenuOtto({ active }: { active: string }) {
  return (
    <>
      {GRUPPI.map((g) => (
        <SidebarGroup key={g.label}>
          <SidebarGroupLabel>{g.label}</SidebarGroupLabel>
          <SidebarGroupContent>
            <SidebarMenu>
              {g.voci.map((v) => (
                <SidebarMenuItem key={v.label}>
                  <SidebarMenuButton render={<a href="#" />} isActive={g.label === "Menù" && v.label === active} tooltip={v.label}><v.icon /><span>{v.label}</span></SidebarMenuButton>
                </SidebarMenuItem>
              ))}
            </SidebarMenu>
          </SidebarGroupContent>
        </SidebarGroup>
      ))}
    </>
  )
}

/* ---------- dati di esempio (nel progetto: special-days e fixed-menus) ---------- */
const OGGI = "2026-10-15" // nel progetto: la data di oggi in Europe/Rome
type Scope = "day" | "lunch" | "dinner"
const SCOPE_LABEL: Record<Scope, string> = { day: "Giornata intera", lunch: "Solo pranzo", dinner: "Solo cena" }
const SCOPE_ITEMS = (Object.keys(SCOPE_LABEL) as Scope[]).map((v) => ({ value: v, label: SCOPE_LABEL[v] }))
type FM = { id: number; name: string; cat: string; specialOnly?: boolean; disabled?: boolean }
const MENUS: FM[] = [
  { id: 1, name: "Business lunch light", cat: "Business lunch" }, { id: 2, name: "Business lunch vegetariano", cat: "Business lunch" }, { id: 3, name: "Business lunch Vietnam", cat: "Business lunch" },
  { id: 4, name: "Degustazione classica", cat: "Degustazione" }, { id: 5, name: "Degustazione del mare", cat: "Degustazione" },
  { id: 6, name: "Menù di Capodanno", cat: "Degustazione", specialOnly: true }, { id: 7, name: "Menù di Natale", cat: "Degustazione", specialOnly: true },
  { id: 8, name: "Menù di Pasqua", cat: "Degustazione", specialOnly: true, disabled: true }, { id: 9, name: "Menù San Valentino", cat: "Degustazione", specialOnly: true },
]
const MENU_CATS = ["Business lunch", "Degustazione"]
type Day = { id: number; date: string; scope: Scope; menus: number[]; msg: string; msgEn: string; disabled: boolean }
const initialDays: Day[] = [
  { id: 1, date: "2026-10-15", scope: "lunch", menus: [3], msg: "Oggi cucina ridotta.", msgEn: "", disabled: false },
  { id: 2, date: "2026-12-25", scope: "day", menus: [7], msg: "", msgEn: "", disabled: false },
  { id: 3, date: "2026-12-31", scope: "dinner", menus: [6], msg: "Cena di Capodanno: prenotazione obbligatoria.", msgEn: "New Year's Eve dinner: booking required.", disabled: false },
  { id: 4, date: "2027-02-14", scope: "dinner", menus: [9, 5], msg: "", msgEn: "", disabled: false },
  { id: 5, date: "2026-04-06", scope: "lunch", menus: [8], msg: "", msgEn: "", disabled: true },
  { id: 6, date: "2026-02-14", scope: "dinner", menus: [9], msg: "", msgEn: "", disabled: false },
]
const menuName = (id: number) => MENUS.find((m) => m.id === id)!.name
const dataLunga = (iso: string) => new Intl.DateTimeFormat("it-IT", { weekday: "long", day: "numeric", month: "long", year: "numeric", timeZone: "UTC" }).format(new Date(`${iso}T12:00:00Z`))
const pl = (n: number, one: string, many: string) => (n === 1 ? `1 ${one}` : `${n} ${many}`)
const SERR = "Non è stato modificato nulla. Controlla la connessione e riprova; se il problema continua, avvisa l’amministratore."
// messaggio del server (lib/menu/validateSpecialDayOverlap): non si riscrive
const OVERLAP = "Esiste già un giorno speciale attivo per questa data e questo servizio. La giornata intera non può sovrapporsi a pranzo o cena, e viceversa."
const overlaps = (a: Scope, b: Scope) => a === "day" || b === "day" || a === b
type Form = Omit<Day, "id">
const emptyForm = (): Form => ({ date: "", scope: "dinner", menus: [], msg: "", msgEn: "", disabled: false })
let nextId = 100

function ScopeSelect({ value, onChange, invalid }: { value: string; onChange: (v: string) => void; invalid?: boolean }) {
  return (
    <Select items={SCOPE_ITEMS} value={value || null} onValueChange={(v) => onChange((v as string) ?? "")}>
      <SelectTrigger id="g-scope" data-component="Select" className="w-full" aria-invalid={invalid ? true : undefined}><SelectValue placeholder="Scegli" /></SelectTrigger>
      <SelectContent>{SCOPE_ITEMS.map((o) => <SelectItem key={o.value} value={o.value}>{o.label}</SelectItem>)}</SelectContent>
    </Select>
  )
}

function GiorniPage() {
  const narrow = useIsMobile()
  const [days, setDays] = React.useState<Day[]>(initialDays)
  const [selId, setSelId] = React.useState<number | null>(null)
  const [form, setForm] = React.useState<Form>(emptyForm())
  const [showErr, setShowErr] = React.useState(false)
  const [enOpen, setEnOpen] = React.useState(false)
  const [busy, setBusy] = React.useState(false)
  const [opError, setOpError] = React.useState<string | null>(null)
  const [notice, setNotice] = React.useState<{ kind: "ok" | "err"; title: string; text?: string } | null>(null)
  const [loadState, setLoadState] = React.useState<"ok" | "loading" | "error" | "empty">("ok")
  const [failNext, setFailNext] = React.useState(false)
  const [delTarget, setDelTarget] = React.useState<Day | null>(null)
  const [delBusy, setDelBusy] = React.useState(false)
  const [rebuildOpen, setRebuildOpen] = React.useState(false)
  const [rebuildBusy, setRebuildBusy] = React.useState(false)

  const patch = (id: number, p: Partial<Day>) => setDays((x) => x.map((d) => (d.id === id ? { ...d, ...p } : d)))
  const prossimi = days.filter((d) => d.date >= OGGI).sort((a, b) => a.date.localeCompare(b.date) || a.scope.localeCompare(b.scope))
  const passati = days.filter((d) => d.date < OGGI).sort((a, b) => b.date.localeCompare(a.date))
  async function toggle(d: Day) {
    setNotice(null); await new Promise((r) => setTimeout(r, 250))
    if (failNext) { setFailNext(false); setNotice({ kind: "err", title: "Operazione non riuscita", text: SERR }); return }
    patch(d.id, { disabled: !d.disabled }); setNotice({ kind: "ok", title: d.disabled ? "Giorno speciale attivato" : "Giorno speciale disattivato", text: "Per vederlo sul menù pubblico serve «Ricompila il menù pubblico»." })
  }
  function openEdit(d: Day) { const { id, ...rest } = d; setForm(rest); setEnOpen(!!d.msgEn); setShowErr(false); setOpError(null); setSelId(id) }
  function openNew() { setForm(emptyForm()); setEnOpen(false); setShowErr(false); setOpError(null); setSelId(-1) }
  const setF = <K extends keyof Form>(k: K, v: Form[K]) => setForm((f) => ({ ...f, [k]: v }))
  // controllo anticipato della sovrapposizione (il server la verifica comunque): vale solo per i giorni attivi
  const conflict = !form.disabled && form.date && form.scope && days.some((d) => d.id !== selId && !d.disabled && d.date === form.date && overlaps(d.scope, form.scope))
  const errs = {
    date: form.date ? null : "Scegli una data.",
    scope: form.scope ? (conflict ? OVERLAP : null) : "Scegli un ambito.",
    menus: form.menus.length ? null : "Scegli almeno un menù fisso.",
  }
  const hasErr = Object.values(errs).some(Boolean)
  const fe = (k: keyof typeof errs) => (showErr || (k === "scope" && conflict) ? errs[k] : null)
  async function save() {
    if (hasErr) { setShowErr(true); requestAnimationFrame(() => document.querySelector<HTMLElement>('[data-slot="sheet-content"] [aria-invalid="true"]')?.focus()); return }
    setBusy(true); setOpError(null); await new Promise((r) => setTimeout(r, 700)); setBusy(false)
    if (failNext) { setFailNext(false); setOpError("Operazione non riuscita. " + SERR); return }
    const isNew = selId === -1
    if (isNew) setDays((x) => [...x, { id: nextId++, ...form }]); else patch(selId!, { ...form })
    setSelId(null); setNotice({ kind: "ok", title: isNew ? "Giorno speciale aggiunto" : "Giorno speciale salvato", text: "Per vederlo sul menù pubblico serve «Ricompila il menù pubblico»." })
  }
  async function doDelete() {
    if (!delTarget) return
    setDelBusy(true); await new Promise((r) => setTimeout(r, 600)); setDelBusy(false)
    const id = delTarget.id; setDays((x) => x.filter((d) => d.id !== id)); setDelTarget(null)
    setNotice({ kind: "ok", title: "Giorno speciale eliminato", text: "Per toglierlo dal menù pubblico serve «Ricompila il menù pubblico»." })
  }
  async function rebuild() { setRebuildBusy(true); await new Promise((r) => setTimeout(r, 800)); setRebuildBusy(false); setRebuildOpen(false); setNotice({ kind: "ok", title: "Ricompilazione avviata", text: "Il menù pubblico si aggiorna tra alcuni minuti." }) }
  function demo(v: string) {
    setNotice(null); setLoadState("ok"); setFailNext(false); setDays(initialDays)
    if (v === "caricamento") setLoadState("loading"); if (v === "errore-caricamento") setLoadState("error"); if (v === "vuoto") setDays([]); if (v === "errore-azione") setFailNext(true)
  }
  const Actions = ({ d }: { d: Day }) => (
    <div className="flex items-center">
      <Button variant="ghost" size="icon" aria-label={`Modifica il giorno speciale di ${dataLunga(d.date)}`} data-component="Button" onClick={() => openEdit(d)}><Pencil /></Button>
      <Button variant="ghost" size="icon" aria-label={`Elimina il giorno speciale di ${dataLunga(d.date)}`} data-component="Button" onClick={() => setDelTarget(d)}><Trash2 /></Button>
    </div>
  )
  const Attivo = ({ d }: { d: Day }) => <Switch data-component="Switch" aria-label={`Attivo: ${dataLunga(d.date)}, ${SCOPE_LABEL[d.scope]}`} checked={!d.disabled} onCheckedChange={() => toggle(d)} />
  const menusText = (d: Day) => d.menus.map(menuName).join(", ")
  const Group = ({ titolo, rows, id }: { titolo: string; rows: Day[]; id: string }) => rows.length === 0 ? null : (
    <section className="flex flex-col gap-2" data-block={`gruppo-${id}`}>
      <h2 className="flex items-baseline gap-2 text-base font-semibold">{titolo} <span className="text-sm font-normal text-muted-foreground">{pl(rows.length, "giorno", "giorni")}</span></h2>
      <div className="hidden rounded-lg border md:block" data-block="elenco-tabella">
        <Table data-component="Table" className="table-fixed">
          <TableHeader><TableRow><TableHead className="w-64">Data</TableHead><TableHead className="w-36">Ambito</TableHead><TableHead>Menù fissi</TableHead><TableHead className="w-28">Attivo</TableHead><TableHead className="w-24"><span className="sr-only">Azioni</span></TableHead></TableRow></TableHeader>
          <TableBody>
            {rows.map((d) => (
              <TableRow key={d.id} className={d.disabled ? "text-muted-foreground" : ""}>
                <TableCell><div className="flex flex-wrap items-center gap-2"><span className="text-sm font-medium first-letter:uppercase">{dataLunga(d.date)}</span>{d.date === OGGI && <Badge data-component="Badge">Oggi</Badge>}{d.disabled && <Badge data-component="Badge" variant="outline">Disattivato</Badge>}</div>{d.msg && <div className="truncate text-xs text-muted-foreground">Messaggio: {d.msg}</div>}</TableCell>
                <TableCell className="text-sm">{SCOPE_LABEL[d.scope]}</TableCell>
                <TableCell className="truncate text-sm">{menusText(d)}</TableCell>
                <TableCell><Attivo d={d} /></TableCell>
                <TableCell className="text-right"><Actions d={d} /></TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </div>
      <div className="flex flex-col gap-2 md:hidden" data-block="elenco-schede">
        {rows.map((d) => (
          <Card key={d.id} size="sm" data-component="Card" className={d.disabled ? "text-muted-foreground" : ""}>
            <CardContent className="flex items-center gap-2">
              <div className="min-w-0 flex-1 py-1">
                <div className="flex flex-wrap items-center gap-x-2"><span className="text-sm font-medium first-letter:uppercase">{dataLunga(d.date)}</span>{d.date === OGGI && <Badge data-component="Badge">Oggi</Badge>}</div>
                <div className="truncate text-xs text-muted-foreground">{SCOPE_LABEL[d.scope]} · {menusText(d)}</div>
                {d.disabled && <Badge data-component="Badge" variant="outline" className="mt-0.5">Disattivato</Badge>}
              </div>
              <label className="flex flex-col items-center gap-1 text-[11px] text-muted-foreground"><Attivo d={d} />Attivo</label>
              <Actions d={d} />
            </CardContent>
          </Card>
        ))}
      </div>
    </section>
  )
  const past = form.date && form.date < OGGI

  return (
    <Shell themeSwitch adminInUserMenu menu={<MenuOtto active="Giorni speciali" />}
      topbar={<Breadcrumb><BreadcrumbList><BreadcrumbItem><BreadcrumbLink href="#">Menù</BreadcrumbLink></BreadcrumbItem><BreadcrumbSeparator /><BreadcrumbItem><BreadcrumbPage>Giorni speciali</BreadcrumbPage></BreadcrumbItem></BreadcrumbList></Breadcrumb>}>
      <div className="mx-auto flex w-full max-w-5xl flex-col gap-5" data-block="contenitore-elenco">
        <div className="flex flex-col gap-3 sm:flex-row sm:items-start sm:justify-between" data-block="intestazione-pagina">
          <div><h1 className="text-xl font-semibold tracking-tight">Giorni speciali</h1><p className="text-sm text-muted-foreground">Un giorno, o un solo servizio, con un menù che sostituisce l’offerta normale.</p></div>
          <div className="flex flex-col-reverse gap-2 sm:flex-row">
            <Button variant="outline" size="lg" data-component="Button" onClick={() => setRebuildOpen(true)}><RefreshCw data-icon="inline-start" /> Ricompila il menù pubblico</Button>
            <Button size="lg" data-component="Button" onClick={openNew}><Plus data-icon="inline-start" /> Nuovo giorno speciale</Button>
          </div>
        </div>
        {notice && <Alert role="status" data-component="Alert" variant={notice.kind === "err" ? "destructive" : "default"}>{notice.kind === "err" ? <CircleAlert /> : <CircleCheck />}<AlertTitle>{notice.title}</AlertTitle>{notice.text && <AlertDescription>{notice.text}</AlertDescription>}</Alert>}
        {loadState === "loading" && <div className="flex flex-col gap-2" aria-busy="true" data-block="caricamento">{[0, 1, 2].map((i) => <Skeleton key={i} className="h-16 w-full rounded-xl" />)}</div>}
        {loadState === "error" && <Alert variant="destructive" role="alert" data-component="Alert"><CircleAlert /><AlertTitle>Impossibile caricare i giorni speciali</AlertTitle><AlertDescription><p>Riprova tra qualche istante; se il problema continua, avvisa l’amministratore.</p><Button variant="outline" className="mt-3" data-component="Button" onClick={() => setLoadState("ok")}>Riprova</Button></AlertDescription></Alert>}
        {(loadState === "empty" || (loadState === "ok" && days.length === 0)) && <div className="flex flex-col items-start gap-3 rounded-lg border border-dashed p-6" data-block="vuoto"><p className="text-sm text-muted-foreground">Nessun giorno speciale.</p><Button variant="outline" data-component="Button" onClick={openNew}>Nuovo giorno speciale</Button></div>}
        {loadState === "ok" && days.length > 0 && (
          <div className="flex flex-col gap-6">
            {prossimi.length === 0 && <p className="text-sm text-muted-foreground" data-block="nessun-prossimo">Nessun giorno speciale in programma.</p>}
            <Group titolo="Prossimi" rows={prossimi} id="prossimi" />
            <Group titolo="Passati" rows={passati} id="passati" />
          </div>
        )}
      </div>

      {/* Modulo del giorno speciale */}
      <Sheet open={selId !== null} onOpenChange={(o) => { if (!o && !busy) setSelId(null) }}>
        <SheetContent side={narrow ? "bottom" : "right"} data-component="Sheet" data-state={selId === -1 ? "new" : "edit"}>
          <SheetHeader><SheetTitle>{selId === -1 ? "Nuovo giorno speciale" : "Modifica giorno speciale"}</SheetTitle><SheetDescription>{selId === -1 ? "Compare nel menù pubblico dopo la ricompilazione." : form.date ? dataLunga(form.date) : ""}</SheetDescription></SheetHeader>
          <FieldGroup className="px-4" data-block="modulo-giorno-speciale">
            {opError && <Alert variant="destructive" role="alert" data-component="Alert"><CircleAlert /><AlertTitle>Operazione non riuscita</AlertTitle><AlertDescription>{SERR}</AlertDescription></Alert>}
            <Alert data-component="Alert" role="note"><Info /><AlertDescription>Il giorno speciale sostituisce l’offerta normale (alla carta e menù fissi) per la data e l’ambito scelti.</AlertDescription></Alert>
            <FieldSet data-block="quando">
              <FieldLegend variant="label">Quando</FieldLegend>
              <Field data-invalid={fe("date") ? true : undefined}><FieldLabel htmlFor="g-date">Data</FieldLabel><Input id="g-date" type="date" value={form.date} aria-invalid={fe("date") ? true : undefined} onChange={(e) => setF("date", e.target.value)} />{fe("date") && <FieldError>{fe("date")}</FieldError>}{past && !fe("date") && <FieldDescription className="text-foreground">La data è passata: il giorno speciale non avrà effetto.</FieldDescription>}</Field>
              <Field data-invalid={fe("scope") ? true : undefined}><FieldLabel htmlFor="g-scope">Ambito</FieldLabel><ScopeSelect value={form.scope} onChange={(v) => setF("scope", v as Scope)} invalid={!!fe("scope")} />{fe("scope") ? <FieldError>{fe("scope")}</FieldError> : <FieldDescription>La giornata intera sostituisce pranzo e cena; pranzo o cena lasciano l’altro servizio sul menù normale.</FieldDescription>}</Field>
            </FieldSet>
            <FieldSet data-block="menu-fissi">
              <FieldLegend variant="label">Menù fissi</FieldLegend>
              {MENU_CATS.map((c) => (
                <FieldSet key={c}>
                  <FieldLegend variant="label" className="text-xs text-muted-foreground">{c}</FieldLegend>
                  {MENUS.filter((m) => m.cat === c).map((m) => (
                    <Field key={m.id} orientation="horizontal">
                      <Checkbox id={`g-m-${m.id}`} data-component="Checkbox" checked={form.menus.includes(m.id)} onCheckedChange={(ck) => setF("menus", ck === true ? [...form.menus, m.id] : form.menus.filter((x) => x !== m.id))} />
                      <FieldLabel htmlFor={`g-m-${m.id}`} className="min-h-11 flex-1 flex-wrap items-center gap-2 font-normal">{m.name}{m.specialOnly && <Badge data-component="Badge" variant="secondary">Solo giorni speciali</Badge>}{m.disabled && <Badge data-component="Badge" variant="outline">Disabilitato</Badge>}</FieldLabel>
                    </Field>
                  ))}
                </FieldSet>
              ))}
              {fe("menus") && <FieldError>{fe("menus")}</FieldError>}
            </FieldSet>
            <FieldSet data-block="messaggio">
              <FieldLegend variant="label">Messaggio</FieldLegend>
              <Field><FieldLabel htmlFor="g-msg">Messaggio sul giorno speciale</FieldLabel><Textarea id="g-msg" data-component="Textarea" value={form.msg} onChange={(e) => setF("msg", e.target.value)} /><FieldDescription>Facoltativo: un banner sul giorno speciale.</FieldDescription></Field>
              <Collapsible open={enOpen} onOpenChange={setEnOpen} className="rounded-lg border" data-block="traduzione-inglese">
                <CollapsibleTrigger render={<button type="button" className="flex min-h-11 w-full items-center gap-2 px-3 text-left text-sm font-medium" />}>Traduzione inglese <span className="font-normal text-muted-foreground">(facoltativa)</span><Badge data-component="Badge" variant="outline" className="ml-auto">{form.msgEn ? "Presente" : "Manca"}</Badge><ChevronDown className={`size-4 transition-transform ${enOpen ? "rotate-180" : ""}`} /></CollapsibleTrigger>
                <CollapsibleContent><div className="flex flex-col gap-4 border-t p-3"><Field><FieldLabel htmlFor="g-msg-en">Message</FieldLabel><Textarea id="g-msg-en" value={form.msgEn} onChange={(e) => setF("msgEn", e.target.value)} /><FieldDescription>Facoltativa. Se resta vuota, il menù mostra il testo italiano.</FieldDescription></Field></div></CollapsibleContent>
              </Collapsible>
            </FieldSet>
            <FieldSet data-block="disponibilita">
              <FieldLegend variant="label">Stato</FieldLegend>
              <Field orientation="horizontal"><div className="flex-1"><FieldLabel htmlFor="g-dis" className="min-h-11 items-center">Disattivato</FieldLabel><FieldDescription>Assente a tempo indefinito: il giorno speciale non si applica e non conta per la sovrapposizione.</FieldDescription></div><Switch id="g-dis" data-component="Switch" checked={form.disabled} onCheckedChange={(c) => setF("disabled", c === true)} /></Field>
            </FieldSet>
          </FieldGroup>
          <SheetFooter className="grid grid-cols-2"><Button size="lg" onClick={save} disabled={busy}>{busy && <Spinner data-icon="inline-start" />}{busy ? "Salvataggio…" : "Salva"}</Button><Button size="lg" variant="outline" disabled={busy} onClick={() => setSelId(null)}>Annulla</Button></SheetFooter>
        </SheetContent>
      </Sheet>

      {/* Elimina: nessuna relazione punta ai giorni speciali */}
      <AlertDialog open={delTarget !== null} onOpenChange={(o) => { if (!o && !delBusy) setDelTarget(null) }}>
        <AlertDialogContent data-component="AlertDialog" data-state="elimina">
          <AlertDialogHeader><AlertDialogTitle>Eliminare il giorno speciale di {delTarget ? dataLunga(delTarget.date) : ""}?</AlertDialogTitle><AlertDialogDescription>{delTarget ? `${SCOPE_LABEL[delTarget.scope]}. ` : ""}Non si può annullare.</AlertDialogDescription></AlertDialogHeader>
          <AlertDialogFooter><AlertDialogCancel disabled={delBusy}>Indietro</AlertDialogCancel><Button variant="destructive" data-component="Button" onClick={doDelete} disabled={delBusy}>{delBusy && <Spinner data-icon="inline-start" />}Elimina</Button></AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

      {/* Ricompila (componente condiviso con Piatti) */}
      <AlertDialog open={rebuildOpen} onOpenChange={(o) => !o && !rebuildBusy && setRebuildOpen(false)}>
        <AlertDialogContent data-component="AlertDialog" data-state="ricompila">
          <AlertDialogHeader><AlertDialogTitle>Ricompilare il menù pubblico?</AlertDialogTitle>
            <AlertDialogDescription>La pubblicazione richiede alcuni minuti. Serve per vedere piatti nuovi e modifiche ai contenuti, ai servizi, agli orari, alle chiusure e ai giorni speciali. «Terminato» e «disabilitato» valgono già.</AlertDialogDescription></AlertDialogHeader>
          <AlertDialogFooter><AlertDialogCancel disabled={rebuildBusy}>Indietro</AlertDialogCancel><Button data-component="Button" onClick={rebuild} disabled={rebuildBusy}>{rebuildBusy && <Spinner data-icon="inline-start" />}Ricompila</Button></AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

      <div data-demo className="fixed bottom-2 right-2 z-50 rounded-md border bg-card px-1.5 py-0.5 text-[11px] text-muted-foreground shadow-xs">
        <label>Demo stato <select aria-label="Stato demo" className="bg-transparent text-foreground" defaultValue="normale" onChange={(e) => demo(e.target.value)}>
          <option value="normale">normale (oggi: 15 ottobre 2026)</option><option value="caricamento">caricamento</option><option value="errore-caricamento">errore di caricamento</option><option value="vuoto">nessun giorno speciale</option><option value="errore-azione">errore all’azione successiva</option>
        </select></label>
      </div>
    </Shell>
  )
}
export const giorniPage = <GiorniPage />
