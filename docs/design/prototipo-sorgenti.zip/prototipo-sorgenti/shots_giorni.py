import sys, io, os
sys.path.insert(0,'/home/claude/mock')
from it_browser import *
from PIL import Image, ImageChops
OUT='/mnt/user-data/outputs/docs/design'; PK=f'{OUT}/schermate/giorni-speciali'
PROTO='file:///home/claude/mock/dist/giorni-speciali.html'; STATIC=f'file://{PK}/mockup.html'; HIDE="[data-demo]{display:none!important}"
os.makedirs(PK,exist_ok=True)
def save(png,name): Image.open(io.BytesIO(png)).convert('RGB').save(f'{PK}/{name}',optimize=True)
def pct(A,B):
    if A.size!=B.size: return ('dimensioni diverse',A.size,B.size)
    d=ImageChops.difference(A,B).convert('L').point(lambda v:255 if v>24 else 0); return round(100*d.histogram()[255]/(A.size[0]*A.size[1]),3)
with sync_playwright() as p:
    b=launch(p); errs=[]
    for sch in ('light','dark'):
        S=[]
        for url in (PROTO,STATIC):
            c=b.new_context(viewport={'width':1280,'height':900},locale='it-IT',color_scheme=sch); pg=c.new_page(); pg.goto(url); pg.add_style_tag(content=HIDE); pg.wait_for_timeout(1200)
            if sch=='dark' and url==STATIC: pg.evaluate("document.documentElement.classList.add('dark')"); pg.wait_for_timeout(300)
            S.append(Image.open(io.BytesIO(pg.screenshot(full_page=True))).convert('RGB')); c.close()
        print('fedeltà giorni-speciali',sch,'-> %',pct(*S))
    c=b.new_context(viewport={'width':1280,'height':900}); pg=c.new_page(); pg.goto(STATIC)
    print('annotazioni giorni-speciali:',pg.evaluate("({slot:document.querySelectorAll('[data-slot]').length,senza:[...document.querySelectorAll('[data-slot]')].filter(e=>!e.hasAttribute('data-component')).length,demo:document.querySelectorAll('[data-demo]').length,script:document.querySelectorAll('script').length})"))
    c.close()
    def page(w=390,h=844,touch=True,scheme='light'):
        kw=dict(viewport={'width':w,'height':h},locale='it-IT',color_scheme=scheme)
        if touch: kw.update(is_mobile=True,has_touch=True)
        c=b.new_context(**kw); pg=c.new_page(); pg.on('pageerror',lambda e:errs.append(str(e))); pg.goto(PROTO); pg.add_style_tag(content=HIDE); pg.wait_for_timeout(900); return c,pg
    def demo(pg,v): pg.evaluate(f"""(()=>{{const s=document.querySelector('select[aria-label="Stato demo"]');s.value='{v}';s.dispatchEvent(new Event('change',{{bubbles:true}}))}})()"""); pg.wait_for_timeout(500)
    def edit(pg): pg.locator('button[aria-label^="Modifica il giorno speciale di giovedì 31 dicembre 2026"]:visible').click(); pg.wait_for_timeout(800)
    def scroll_sheet(pg,y): pg.evaluate(f"document.querySelector('[data-slot=sheet-content]').scrollTo(0,{y})"); pg.wait_for_timeout(300)
    def to_block(pg,name): pg.evaluate(f"document.querySelector('[data-block={name}]').scrollIntoView({{block:'start'}})"); pg.wait_for_timeout(300)
    for tag,w,h,t in [('390',390,844,True),('1280',1280,900,False)]:
        for sch,it in [('light','chiaro'),('dark','scuro')]:
            c,pg=page(w,h,t,sch); save(pg.screenshot(full_page=True),f'{tag}-{it}.png'); c.close()
    def to_block(pg,name): pg.evaluate(f"document.querySelector('[data-block={name}]').scrollIntoView({{block:'start'}})"); pg.wait_for_timeout(300)
    def nuovo(pg): pg.get_by_role('button',name='Nuovo giorno speciale').first.click(); pg.wait_for_timeout(700)
    steps={}
    steps['390-modulo-chiaro.png']=edit
    steps['390-modulo-menu-chiaro.png']=lambda pg:(edit(pg),to_block(pg,'menu-fissi'))
    steps['390-modulo-inglese-aperto-chiaro.png']=lambda pg:(edit(pg),pg.get_by_role('button',name='Traduzione inglese').click(),pg.wait_for_timeout(300),to_block(pg,'messaggio'))
    steps['390-nuovo-chiaro.png']=nuovo
    steps['390-nuovo-errori-chiaro.png']=lambda pg:(nuovo(pg),pg.get_by_role('button',name='Salva',exact=True).click())
    steps['390-sovrapposizione-chiaro.png']=lambda pg:(nuovo(pg),pg.fill('#g-date','2027-02-14'),pg.wait_for_timeout(400),to_block(pg,'quando'))
    steps['390-data-passata-chiaro.png']=lambda pg:(nuovo(pg),pg.fill('#g-date','2026-01-10'),pg.wait_for_timeout(400),to_block(pg,'quando'))
    steps['390-attivazione-chiaro.png']=lambda pg:(pg.get_by_role('switch',name='Attivo: giovedì 31 dicembre 2026, Solo cena').click(),pg.wait_for_timeout(700))
    steps['390-elimina-chiaro.png']=lambda pg:(pg.locator('button[aria-label^="Elimina il giorno speciale di domenica 14 febbraio 2027"]:visible').click(),pg.wait_for_timeout(600))
    steps['390-eliminato-chiaro.png']=lambda pg:(pg.locator('button[aria-label^="Elimina il giorno speciale di domenica 14 febbraio 2027"]:visible').click(),pg.wait_for_timeout(500),pg.get_by_role('alertdialog').get_by_role('button',name='Elimina',exact=True).click(),pg.wait_for_timeout(1300))
    steps['390-caricamento-chiaro.png']=lambda pg:demo(pg,'caricamento')
    steps['390-errore-caricamento-chiaro.png']=lambda pg:demo(pg,'errore-caricamento')
    steps['390-vuoto-chiaro.png']=lambda pg:demo(pg,'vuoto')
    def errore_azione(pg):
        demo(pg,'errore-azione'); edit(pg); pg.get_by_role('button',name='Salva',exact=True).click(); pg.wait_for_timeout(1300)
    steps['390-errore-azione-chiaro.png']=errore_azione
    for name,fn in steps.items():
        c,pg=page(); fn(pg); pg.wait_for_timeout(600)
        if name in('390-attivazione-chiaro.png','390-eliminato-chiaro.png'): pg.evaluate("window.scrollTo(0,0)"); pg.wait_for_timeout(300)
        save(pg.screenshot(),name); c.close()
    c,pg=page(1280,900,False); pg.locator('button[aria-label^="Modifica il giorno speciale di giovedì 31 dicembre 2026"]:visible').click(); pg.wait_for_timeout(800); save(pg.screenshot(),'1280-modulo-chiaro.png'); c.close()
    print('errori pagina:',errs); b.close()
print(len([f for f in os.listdir(PK) if f.endswith('.png')]),'PNG')
